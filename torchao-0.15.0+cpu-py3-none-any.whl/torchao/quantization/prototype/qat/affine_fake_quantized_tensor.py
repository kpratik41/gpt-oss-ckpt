from torchao.quantization.qat.affine_fake_quantized_tensor import (
    _AffineFakeQuantizedTensor,
    _to_affine_fake_quantized,
)

__all__ = [
    "_AffineFakeQuantizedTensor",
    "_to_affine_fake_quantized",
]
