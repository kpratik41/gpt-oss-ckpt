from torchao.quantization.qat.fake_quantizer import (
    IntxFakeQuantizer as FakeQuantizer,
)

__all__ = [
    "FakeQuantizer",
]
