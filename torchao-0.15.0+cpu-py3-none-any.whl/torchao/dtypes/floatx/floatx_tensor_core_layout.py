# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD 3-Clause license found in the
# LICENSE file in the root directory of this source tree.

# Backward compatibility stub - imports from the new location
import warnings

warnings.warn(
    "Importing from torchao.dtypes.floatx.floatx_tensor_core_layout is deprecated. "
    "Please use 'from torchao.prototype.dtypes.floatx.floatx_tensor_core_layout import ...' instead. "
    "This import path will be removed in a future torchao release. "
    "Please check issue: https://github.com/pytorch/ao/issues/2752 for more details. ",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export all public symbols from the new location for backward compatibility
from torchao.prototype.dtypes.floatx.floatx_tensor_core_layout import (  # noqa: F401
    FloatxTensorCoreAQTTensorImpl,  # noqa: F401
    FloatxTensorCoreLayout,  # noqa: F401
    _linear_f16_bf16_act_floatx_weight_check,  # noqa: F401
    _linear_f16_bf16_act_floatx_weight_impl,  # noqa: F401
    _pack_tc_floatx,  # noqa: F401
    _pack_tc_fp6,  # noqa: F401
    from_scaled_tc_floatx,  # noqa: F401
    pack_tc_floatx,  # noqa: F401
    to_scaled_tc_floatx,  # noqa: F401
    unpack_tc_floatx,  # noqa: F401
)
