from .spinquant import apply_spinquant

__all__ = [
    "apply_spinquant",
]
