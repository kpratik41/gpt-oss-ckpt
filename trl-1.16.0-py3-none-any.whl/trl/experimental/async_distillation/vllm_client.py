# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import time

from accelerate.logging import get_logger

from ...import_utils import is_requests_available


if is_requests_available():
    import requests


logger = get_logger(__name__)


class VLLMClient:
    """Synchronous HTTP client for a vLLM server used by async distillation.

    Ported from [`~trl.experimental.async_grpo.vllm_client.VLLMClient`]. The student's server uses the full API
    (readiness, world size, pause/resume, weight-update endpoints) since [`WeightTransferClient`] streams updated
    weights to it; the teacher's server only ever needs [`wait_for_server_ready`], since the teacher is static and is
    otherwise queried directly over `/v1/completions` from the rollout worker's `aiohttp` session, not through this
    client.

    Args:
        server_url (`str`):
            Base URL of the vLLM server, e.g. `"http://localhost:8000"`.
        server_timeout (`float`, *optional*, defaults to `240.0`):
            Seconds to wait for the server to become reachable in [`wait_for_server_ready`].
    """

    def __init__(self, server_url: str, server_timeout: float = 240.0):
        if not is_requests_available():
            raise ImportError("requests is not installed. Please install it with `pip install requests`.")

        self.server_url = server_url.rstrip("/")
        self.server_timeout = server_timeout

    def wait_for_server_ready(self, poll_interval_s: float = 2.0) -> None:
        """Block until the server answers `/health`, or raise `TimeoutError` after `server_timeout` seconds."""
        logger.info(f"Waiting for vLLM server at {self.server_url} ...")
        start = time.time()
        while True:
            elapsed = time.time() - start
            try:
                response = requests.get(f"{self.server_url}/health", timeout=5)
                if response.status_code == 200:
                    logger.info(f"vLLM server ready after {elapsed:.1f}s")
                    return
            except (requests.ConnectionError, requests.Timeout, OSError):
                pass
            if elapsed >= self.server_timeout:
                raise TimeoutError(
                    f"Timed out after {self.server_timeout:.0f}s waiting for vLLM server at {self.server_url}. "
                    "Make sure the vLLM server is running and reachable. If the server needs more time to load the "
                    "model, increase `vllm_server_timeout` in your AsyncDistillationConfig."
                )
            if int(elapsed) % 10 < poll_interval_s:
                logger.info(f"Still waiting for vLLM server... ({elapsed:.0f}s)")
            time.sleep(poll_interval_s)

    def get_max_model_len(self) -> int:
        """Return the served model's `max_model_len` (the cap on prompt + completion tokens)."""
        response = requests.get(f"{self.server_url}/v1/models")
        response.raise_for_status()
        return response.json()["data"][0]["max_model_len"]

    def get_server_info(self) -> dict:
        """Return the server's resolved `vllm_config`, as reported by `/server_info`."""
        response = requests.get(f"{self.server_url}/server_info", params={"config_format": "json"})
        response.raise_for_status()
        return response.json()["vllm_config"]

    def load_lora_adapter(self, lora_name: str, lora_path: str, timeout: int = 1800) -> None:
        """Register a PEFT adapter directory under `lora_name`, making it selectable as a model name.

        Args:
            lora_name (`str`):
                Name to register the adapter under. Generation requests select it through their `model` field.
            lora_path (`str`):
                Directory holding `adapter_config.json` and the adapter weights. The server process reads it, so it
                must sit on a filesystem the server can see: vLLM has no in-memory adapter API.
        """
        response = requests.post(
            f"{self.server_url}/v1/load_lora_adapter",
            # `load_inplace` stays `False`: it makes the server re-read the adapter from disk on every request
            # (https://github.com/vllm-project/vllm/pull/41482). New policies get a new name instead.
            json={"lora_name": lora_name, "lora_path": lora_path, "load_inplace": False},
            timeout=timeout,
        )
        if response.status_code == 404:
            raise RuntimeError(
                f"The vLLM server at {self.server_url} does not expose `/v1/load_lora_adapter`. Restart it with "
                "`VLLM_ALLOW_RUNTIME_LORA_UPDATING=1` in its environment."
            )
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")

    def unload_lora_adapter(self, lora_name: str, timeout: int = 1800) -> None:
        """Remove a previously registered adapter. Missing names are not an error."""
        requests.post(f"{self.server_url}/v1/unload_lora_adapter", json={"lora_name": lora_name}, timeout=timeout)

    def get_world_size(self) -> int:
        """Return the vLLM server's inference world size (tensor/pipeline parallel processes)."""
        response = requests.get(f"{self.server_url}/get_world_size")
        return response.json()["world_size"]

    def pause(self, timeout: int = 1800) -> None:
        """Freeze in-flight requests and clear caches before replacing the model weights."""
        response = requests.post(f"{self.server_url}/pause", params={"mode": "keep"}, timeout=timeout)
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")

    def resume(self, timeout: int = 1800) -> None:
        """Resume generation after a weight update."""
        response = requests.post(f"{self.server_url}/resume", timeout=timeout)
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")

    def init_weight_transfer_engine(self, init_info: dict, timeout: int = 1800) -> None:
        """Initialise the server side of the NCCL weight-transfer group."""
        response = requests.post(
            f"{self.server_url}/init_weight_transfer_engine", json={"init_info": init_info}, timeout=timeout
        )
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")

    def start_weight_update(self, timeout: int = 1800) -> None:
        """Prepare the workers for a weight reload; must complete before any weights are sent."""
        response = requests.post(
            f"{self.server_url}/start_weight_update", json={"is_checkpoint_format": True}, timeout=timeout
        )
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")

    def update_weights(self, update_info: dict, timeout: int = 1800) -> None:
        """Drive the workers' blocking NCCL recv; returns once the server has received every chunk."""
        response = requests.post(
            f"{self.server_url}/update_weights", json={"update_info": update_info}, timeout=timeout
        )
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")

    def finish_weight_update(self, timeout: int = 1800) -> None:
        """Finalise the weight update on the server."""
        response = requests.post(f"{self.server_url}/finish_weight_update", timeout=timeout)
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code}, {response.text}")
