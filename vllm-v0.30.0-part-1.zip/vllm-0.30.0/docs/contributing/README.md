# Contributing to vLLM

Thank you for your interest in contributing to vLLM! Our community is open to everyone and welcomes all kinds of contributions, no matter how small or large. There are several ways you can contribute to the project:

- Identify and report any issues or bugs.
- Request or add support for a new model.
- Suggest or implement new features.
- Improve documentation or contribute a how-to guide.

We also believe in the power of community support; thus, answering queries, offering PR reviews, and assisting others are also highly regarded and beneficial contributions.

Finally, one of the most impactful ways to support us is by raising awareness about vLLM. Talk about it in your blog posts and highlight how it's driving your incredible projects. Express your support on social media if you're using vLLM, or simply offer your appreciation by starring our repository!

## Job Board

Unsure on where to start? Check out the following links for tasks to work on:

- [Good first issues](https://github.com/vllm-project/vllm/issues?q=is%3Aissue%20state%3Aopen%20label%3A%22good%20first%20issue%22)
    - [Selected onboarding tasks](https://github.com/orgs/vllm-project/projects/6)
- [New model requests](https://github.com/vllm-project/vllm/issues?q=is%3Aissue%20state%3Aopen%20label%3A%22new-model%22)
    - [Models with multi-modal capabilities](https://github.com/orgs/vllm-project/projects/10)

## License

See [LICENSE](../../LICENSE).

## Developing

The first step of contributing to vLLM is to clone the GitHub repository:

```bash
git clone https://github.com/vllm-project/vllm.git
cd vllm
```

Then, configure your Python virtual environment.

--8<-- "docs/getting_started/installation/python_env_setup.inc.md"

If you are only developing vLLM's Python code, install vLLM using:

```bash
VLLM_USE_PRECOMPILED=1 uv pip install -e .
```

To rebuild only the Rust frontend binary:

```bash
./build_rust.sh          # release build
./build_rust.sh --debug  # faster build for development
```

If you are developing vLLM's Python and CUDA/C++ code, install Pytorch first:

```bash
uv pip install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu129
```

Then install the necessary build dependencies from `requirements/build/cuda.txt`, skipping `torch` as it was installed in the previous step:

```bash
grep -v '^torch==' requirements/build/cuda.txt | uv pip install -r -
```

Finally install vLLM using:

```bash
uv pip install -e . --no-build-isolation
```

For more details about installing from source and installing for other hardware, check out the [installation instructions](../getting_started/installation/README.md) for your hardware and head to the "Build wheel from source" section.

For an optimized workflow when iterating on C++/CUDA kernels, see the [Incremental Compilation Workflow](./incremental_build.md) for recommendations.
For JIT kernel warmup conventions, see [JIT Kernel Warmup](./jit_kernel_warmup.md).

!!! tip
    vLLM is compatible with Python versions 3.10 to 3.13. However, vLLM's default [Dockerfile](../../docker/Dockerfile) ships with Python 3.12 and tests in CI (except `mypy`) are run with Python 3.12.

    Therefore, we recommend developing with Python 3.12 to minimise the chance of your local environment clashing with our CI environment.

### Linting

vLLM uses `pre-commit` to lint and format the codebase. See <https://pre-commit.com/#usage> if `pre-commit` is new to you. Setting up `pre-commit` is as easy as:

```bash
uv pip install pre-commit>=4.5.1
pre-commit install
```

vLLM's `pre-commit` hooks will now run automatically every time you commit.

!!! tip "Tips"
    You can manually run the `pre-commit` hooks using:

    ```bash
    pre-commit run     # runs on staged files
    pre-commit run -a  # runs on all files (short for --all-files)
    ```

    ---

    Some `pre-commit` hooks only run in CI. If you need to, you can run them locally with:

    ```bash
    pre-commit run --hook-stage manual mypy-3.11
    ```

### Documentation

MkDocs is a fast, simple and downright gorgeous static site generator that's geared towards building project documentation. Documentation source files are written in Markdown, and configured with a single YAML configuration file, [mkdocs.yaml](../../mkdocs.yaml).

Get started with:

```bash
uv pip install -r requirements/docs.txt
```

!!! tip
    Ensure that your Python version is compatible with the plugins
    (e.g., `mkdocs-awesome-nav` requires Python 3.10+)

MkDocs comes with a built-in dev-server that lets you preview your documentation as you work on it.
From the root of the repository, run the following. Note that by default, the dev-server will run on `127.0.0.1:8000`. Should you want to run the dev-server on a different port, use `-a` like this `mkdocs serve -a localhost:8090`.

```bash
mkdocs serve                           # with API ref (~10 minutes)
API_AUTONAV_EXCLUDE=vllm mkdocs serve  # API ref off (~15 seconds)
```

Once you see a `Serving on http://<address>:<port>/` line in the logs, the live preview is ready!
Open that address in your browser to see it — `http://127.0.0.1:8000/` by default, or whichever host/port you passed to `-a`.

For additional features and advanced configurations, refer to the:

- [MkDocs documentation](https://www.mkdocs.org/)
- [Material for MkDocs documentation](https://squidfunk.github.io/mkdocs-material/) (the MkDocs theme we use)

### Testing

vLLM uses `pytest` to test the codebase.

```bash
# Install the test dependencies used in CI (CUDA only)
uv pip install -r requirements/common.txt -r requirements/dev.txt --torch-backend=auto

# Install some common test dependencies (hardware agnostic)
uv pip install pytest pytest-asyncio

# Run all tests
pytest tests/

# Run tests for a single test file with detailed output
pytest -s -v tests/test_logger.py
```

!!! tip "Install python3-dev if Python.h is missing"
    If any of the above commands fails with `Python.h: No such file or directory`, install
    `python3-dev` with `sudo apt install python3-dev`.

!!! warning "Warnings"
    Currently, the repository is not fully checked by `mypy`.

    ---

    Currently, not all unit tests pass when run on CPU platforms. If you don't have access to a GPU
    platform to run unit tests locally, rely on the continuous integration system to run the tests for
    now.

## Issues

If you encounter a bug or have a feature request, please [search existing issues](https://github.com/vllm-project/vllm/issues?q=is%3Aissue) first to see if it has already been reported. If not, please [file a new issue](https://github.com/vllm-project/vllm/issues/new/choose), providing as much relevant information as possible.

!!! important
    If you discover a security vulnerability, please follow the instructions [here](../../SECURITY.md).

## Pull Requests & Code Reviews

Thank you for your contribution to vLLM! Before submitting the pull request,
please ensure the PR meets the following criteria. This helps vLLM maintain the
code quality and improve the efficiency of the review process.

### DCO and Signed-off-by

When contributing changes to this project, you must agree to the [DCO](../../DCO).
Commits must include a `Signed-off-by:` header which certifies agreement with
the terms of the DCO.

Using `-s` with `git commit` will automatically add this header.

!!! tip
    You can enable automatic sign-off via your IDE:

    - **PyCharm**: Click on the `Show Commit Options` icon to the right of the `Commit and Push...` button in the `Commit` window.
      It will bring up a `git` window where you can modify the `Author` and enable `Sign-off commit`.
    - **VSCode**: Open the [Settings editor](https://code.visualstudio.com/docs/configure/settings)
      and enable the `Git: Always Sign Off` (`git.alwaysSignOff`) field.

### AI Assisted Contributions

Before making an AI assisted contribution, you must:

1. **Be involved**: Do not submit "pure agent" PRs. The human submitter is responsible for reviewing all changed lines, validating behavior end-to-end, and running relevant tests.
2. **Ensure significance**: Avoid one-off "busywork" PRs (single typo, isolated style cleanup, one mutable default fix, etc.). Bundle mechanical cleanups into a clear, systematic scope.

When AI tools provide non-trivial assistance in generating or modifying code, you must:

1. **Review thoroughly**: You remain responsible for all code you submit. Review and understand AI-generated code with the same care as code you write manually.
2. **Disclose in PR**: Always mention when a pull request includes AI-generated code. Add a note in the PR description.
3. **Mark commits**: Add attribution using commit trailers such as `Co-authored-by:` (other projects use `Assisted-by:` or `Generated-by:`). For example:

   ```text
   Your commit message here

   Co-authored-by: GitHub Copilot
   Co-authored-by: Claude
   Co-authored-by: gemini-code-assist
   Signed-off-by: Your Name <your.email@example.com>
   ```

AI-assisted code must meet all quality standards: proper testing, documentation, adherence to style guides, and thorough review. Attribution helps reviewers evaluate contributions in context and maintains legal clarity for the project.

### PR Title and Classification

PR titles must start with one or more bracketed tags, followed by a space and a
concise description, for example, `[Bugfix][Scheduler] Fix priority handling`.
Any descriptive tag is accepted. The following well-known tags improve
consistency and discoverability; use one of them when it fits, or choose a more
specific tag.

**Type tags** describe the nature of the change:

- `[Bugfix]`, `[Feature]`, `[Perf]`, and `[Refactor]` for code changes.
- `[CI]` or `[CI/Build]`, `[Test]`, and `[Doc]` or `[Docs]` for project
  infrastructure, tests, and documentation.
- `[Misc]` when another type tag does not fit.

**Scope tags** identify the affected area:

- `[Model]`, `[Frontend]`, `[Rust Frontend]`, `[Core]`, and `[Kernel]` for major
  areas of the codebase.
- `[Model Runner V2]` or `[MRV2]`, `[Attention]`, `[Multimodal]`,
  `[Quantization]`, `[MoE]`, `[Spec Decode]`, `[LoRA]`, `[KV Connector]`, and
  `[KV Offload]` for frequently changed subsystems.
- `[ROCm]`, `[XPU]`, `[CPU]`, or `[Hardware][Vendor]` for hardware-specific
  changes. Replace `Vendor` with the vendor name, for example,
  `[Hardware][AMD]`.

Type and scope tags can be combined, and multiple tags from either category can
be stacked without spaces. For example, `[Bugfix][KV Offload] Fix block
accounting` or `[Perf][ROCm][Kernel] Optimize fused MoE`.

### Code Quality

The PR needs to meet the following code quality standards:

- We adhere to [Google Python style guide](https://google.github.io/styleguide/pyguide.html) and [Google C++ style guide](https://google.github.io/styleguide/cppguide.html).
- Pass all linter checks.
- The code needs to be well-documented to ensure future contributors can easily
  understand the code.
- Include sufficient tests to ensure the project stays correct and robust. This
  includes both unit tests and integration tests.
- Please add documentation to `docs/` if the PR modifies the user-facing behaviors of vLLM.
  It helps vLLM users understand and utilize the new features or changes.

### Adding or Changing Kernels

When actively developing or modifying kernels, using the [Incremental Compilation Workflow](./incremental_build.md) is highly recommended for faster build times.
Each custom kernel needs a schema and one or more implementations to be registered with PyTorch.

- Make sure custom ops are registered following PyTorch guidelines:
  [Custom C++ and CUDA Operators](https://pytorch.org/tutorials/advanced/cpp_custom_ops.html#cpp-custom-ops-tutorial)
  and [The Custom Operators Manual](https://docs.google.com/document/d/1_W62p8WJOQQUzPsJYa7s701JXt0qf2OfLub2sbkHOaU).
- Custom operations that return `Tensors` require meta-functions.
  Meta-functions should be implemented and registered in Python so that dynamic
  dims can be handled automatically. See above documents for a description of
  meta-functions.
- Use [torch.library.opcheck()](https://pytorch.org/docs/stable/library.html#torch.library.opcheck)
  to test the function registration and meta-function for any registered ops.
  See `tests/kernels` for examples.
- When changing the C++ signature of an existing op, the schema must be updated
  to reflect the changes.
- If a new custom type is needed, see the following document:
  [Custom Class Support in PT2](https://docs.google.com/document/d/18fBMPuOJ0fY5ZQ6YyrHUppw9FA332CpNtgB6SOIgyuA).

### Notes for Large Changes

Please keep the changes as concise as possible. For major architectural changes
(>500 LOC excluding kernel/data/config/test), we would expect a GitHub issue
(RFC) discussing the technical design and justification. Otherwise, we will tag
it with `rfc-required` and might not go through the PR.

### What to Expect for the Reviews

The goal of the vLLM team is to be a *transparent reviewing machine*. We would
like to make the review process transparent and efficient and make sure no
contributor feels confused or frustrated. However, the vLLM team is small, so we
need to prioritize some PRs over others. Here is what you can expect from the
review process:

- After the PR is submitted, the PR will be assigned to a reviewer. Every
  reviewer will pick up the PRs based on their expertise and availability.
- After the PR is assigned, the reviewer will provide status updates every 2-3
  days. If the PR is not reviewed within 7 days, please feel free to ping the
  reviewer or the vLLM team.
- After the review, the reviewer will put an `action-required` label on the PR
  if there are changes required. The contributor should address the comments and
  ping the reviewer to re-review the PR.
- Please respond to all comments within a reasonable time frame. If a comment
  isn't clear or you disagree with a suggestion, feel free to ask for
  clarification or discuss the suggestion.
- Note that not all CI checks will be executed due to limited computational
  resources. Reviewers with write access and configured trusted contributors
  can comment `/ci run` for upstream CI or `/amd-ci run` for AMD CI only when
  CI signals are needed before a PR is ready. After the PR is approved or has
  the `ready` label, the PR author can use `/ci run`, `/ci retry`, `/ci cancel`,
  or the corresponding `/amd-ci` variants. New commits do not start upstream
  CI automatically.
- Before creating a Buildkite build, `/ci run` and `/amd-ci run`, including
  `all` and `nightly`, check the requested PR commit against its target branch
  in the upstream repository. Your branch must contain every commit currently
  on that branch: **zero commits behind**. This also applies to PRs targeting
  release branches or another PR's branch.
- If the PR is behind, the bot reports the count without creating a new build.
  Merge or rebase onto the latest target branch, then rerun the command. If the
  target branch advances in the meantime, update your branch and try again.
- To run CI on an outdated branch at your own risk, append `--allow-stale` to
  any run command, for example `/ci run --allow-stale` or
  `/amd-ci run all --allow-stale`. The same authorization requirements apply.
  The bot reports the lag and warns that outdated CI configuration may cause
  failures. Before merging, merge or rebase onto the latest target branch and
  rerun CI without `--allow-stale` on the latest PR commit.
- Retrying or cancelling builds does not check branch freshness.
- These commands do not modify your branch or enforce merge requirements.
  Direct Buildkite launches are outside this workflow. No additional token is
  needed.

Maintainers must configure required Buildkite status checks on the latest PR
commit and enable GitHub's
[Require branches to be up to date before merging](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches#require-status-checks-before-merging)
protection on the relevant target branches to enforce the merge policy. Select
statuses that confirm the required tests completed, using Buildkite as their
expected source. An aggregate status that reports "passed and blocked" does not
by itself guarantee those tests ran; verify the pipeline's required and optional
blocked steps before choosing statuses or changing blocked-build reporting.
The CI command workflow does not configure these repository or pipeline settings.

### Pull Request Limits and Escalation

vLLM uses GitHub's [pull request limit](https://github.blog/open-source/maintainers/how-pull-request-limits-are-cutting-down-the-noise/)
for contributors without write access. The current cap is 6 open PRs. If this
blocks well-intentioned critical work, contact a committer to request bypass
list access.

If you need an expedited review for an important contribution, please email us
at:

<pr-review-request@vllm.ai>

Using a verifiable company or university email, include:

- your production or research use case
- the problem you encountered
- how your contribution addresses it

## Thank You

Finally, thank you for taking the time to read these guidelines and for your interest in contributing to vLLM.
All of your contributions help make vLLM a great tool and community for everyone!
