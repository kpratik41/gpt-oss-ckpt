# Results

## Old Dev Schema-Tool Model Comparison

This comparison covers the requested base/model artifacts on `outputs/old-dev-schema-tool.jsonl`. A two-panel plot is the clearest view here: execution accuracy and tool-call rate use different units, so grouped bars in separate panels avoid a misleading dual-axis chart.

![Gemma-4 model comparison](figures/gemma4_model_comparison_temp0_pass16_tools.svg)

Images can be added to this Markdown file with normal image links like the one above. The plot source is `figures/gemma4_model_comparison_temp0_pass16_tools.svg`, which is outside the gitignored `outputs/` tree.

### Artifact Inventory

| model | temp-0 inference artifact | pass@k artifact |
| --- | --- | --- |
| `E4B-it` | `outputs/training/beta_exp_0528/train-6601-schema-bare-tool/gemma-4-E4B-it/grpo_deepspeed_p15500_c8000_g16_t1p2_bs4_ga8_lr1e-6_inprocess_beta0p005_s0-40_beta0p001_s40-80_beta0_s80plus_olddev32_refinitfix_nods_20260527_204225/checkpoint-0/eval_summary.json` | `outputs/training/beta_exp_0528/train-6601-schema-bare-tool/gemma-4-E4B-it/grpo_deepspeed_p15500_c8000_g16_t1p2_bs4_ga8_lr1e-6_inprocess_beta0p005_s0-40_beta0p001_s40-80_beta0_s80plus_olddev32_refinitfix_nods_20260527_204225/checkpoint-0/maskfix_ckpt-0_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k/passk_summary.json` |
| `26B-A4B-it` | `outputs/google_gemma-4-26B-A4B-it/temp0_olddev_schema_tool_tp2_ctx43k/eval_summary.json` | `outputs/google_gemma-4-26B-A4B-it/passk16_olddev_schema_tool_temp1p2_tp2_ctx43p5k/passk_summary.json` |
| `31B-it` | `outputs/inference/dev/old-dev-schema-tool/google-gemma-4-31B-it/vllm_async_tp4_dp1_c16_ctx43k_p34k_o8k_r8_temp0/eval_summary.json` | `outputs/passk/gemma4_31b_old-dev-schema-tool_full1534_temp1p2_tp4_ctx45k/passk_summary.json` |

### Metric Summary

For pass@k, `tool calls / generation` is `total_tool_calls / (1534 * 16)`. For temp-0 inference it is `total_tool_calls / 1534`.

| model | temp-0 EX | pass@1 / candidate acc | pass@16 | temp-0 tool calls / generation | pass@k tool calls / generation | status |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `E4B-it` | `65.12%` | `63.64%` | `79.79%` | `1.306` | `1.303` | complete |
| `26B-A4B-it` | `69.23%` | `69.85%` | `77.77%` | `1.704` | `1.757` | complete |
| `31B-it` | `71.19%` | `68.68%` | `74.97%` | `1.269` | `2.208` | complete |

### Self-Consistency

| model | SC option 1 | SC option 2 | temp-0 EX | artifact |
| --- | ---: | ---: | ---: | --- |
| `26B-A4B-it` | `71.19%` (`1092 / 1534`) | `71.12%` (`1091 / 1534`) | `69.23%` | `outputs/google_gemma-4-26B-A4B-it/passk16_olddev_schema_tool_temp1p2_tp2_ctx43p5k/self_consistency/self_consistency_summary.json` |
| `31B-it` | `69.95%` (`1073 / 1534`) | `70.73%` (`1085 / 1534`) | `71.19%` | `outputs/passk/gemma4_31b_old-dev-schema-tool_full1534_temp1p2_tp4_ctx45k/self_consistency/self_consistency_summary.json` |

### Tool Call Counts

| model | mode | total tool calls | `sqlite_query` | `sqlite_peek` | `bm25_search_sqlite` | other / malformed |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `E4B-it` | temp-0 | `2003` | `1893` | `62` | `47` | `1` |
| `E4B-it` | pass@k | `31969` | `29965` | `1102` | `868` | `34` |
| `26B-A4B-it` | temp-0 | `2614` | `2331` | `221` | `62` | `0` |
| `26B-A4B-it` | pass@k | `43118` | `37509` | `4188` | `1418` | `3` |
| `31B-it` | temp-0 | `1947` | `1853` | `36` | `58` | `0` |
| `31B-it` | pass@k | `54185` | `51979` | `1123` | `1068` | `15` |

Notes: the 31B temp-0 summary did not include `generation_stats`, so those counts were derived from `prediction_details.jsonl`. The E4B checkpoint-0 pass@k `other / malformed` bucket is mostly rare malformed tool names such as `tool_name` and `sql_query`; the 26B pass@k bucket is `tool_name` plus one `sqlite_duplicate_query`; the 31B pass@k bucket is `tool_name` plus one `sqite_query`.

## Training Experiment Plot Index

The cross-experiment summary plot is `figures/training_experiment_summary.svg`. Per-experiment plots are stored under the matching `figures/` subfolders linked in each section below.

## Maskfix Checkpoint Pass@K: Old Dev Schema Tool

These runs evaluate checkpoints from the `maskfix` GRPO training run on `outputs/old-dev-schema-tool.jsonl`. Each checkpoint used 1 GPU, 16 sampled generations per example over all 1534 old-dev samples, and 24544 candidates per checkpoint.

### Figures

| plot | file |
| --- | --- |
| accuracy, SC, and entropy | `figures/entropy_collapse/checkpoint_accuracy_entropy_sc.svg` |
| sampling lift | `figures/entropy_collapse/sampling_lift.svg` |
| tool calls and failed predictions | `figures/entropy_collapse/tool_calls_and_failures.svg` |
| best checkpoint summary | `figures/entropy_collapse/best_checkpoint_summary.svg` |

### Run Metadata

| setting | value |
| --- | --- |
| documented date | `2026-05-27` |
| training run | `outputs/training/train-6601-schema-bare-tool/gemma-4-E4B-it/grpo_deepspeed_p15500_c8000_g16_t1p2_bs4_ga8_lr2e-6_e4b_bare_lr2e6_maskfix_20260526_044450` |
| wandb run | `https://wandb.ai/kpratik41/gemma4-31b-bird-gspo/runs/gstnzv5s` |
| base model | `google/gemma-4-E4B-it` |
| train file | `outputs/train-6601-schema-bare-tool.jsonl` |
| eval file during training | `outputs/dev-20251106-schema-bare-tool.jsonl` with `eval_limit=32` |
| trainer backend | `grpo` with DeepSpeed ZeRO-3 |
| training GPUs | `6` processes on CUDA devices `0,1,2,3,4,5` |
| rollout vLLM server | `google/gemma-4-E4B-it`, tensor parallel size `2`, CUDA devices `6,7`, max model length `24576` |
| train reward weights | `0.2,0.5,2.0,0.5,0.5,0.1,0.1` for format, execution, result, table_linking, column_linking, nonnull, length_penalty |
| beta | `0.0` |
| loss / reward scaling | `loss_type=dapo`, `scale_rewards=batch` |
| clipping epsilons | `epsilon=0.2`, `epsilon_high=0.28` |
| training batch settings | `per_device_train_batch_size=4`, `gradient_accumulation_steps=8`, `num_generations=16` |
| training optimizer settings | `learning_rate=2e-6`, `num_train_epochs=1`, `max_steps=-1` |
| DAPO dynamic sampling | enabled, `dynamic_sampling_reward_name=result_reward`, `dapo_oversample_factor=6`, `dapo_max_rounds=1`, `dynamic_sampling_min_std=1e-6` |
| tool rollouts | enabled, `max_tool_calling_iterations=8`, `reward_workers=4`, `exec_timeout_s=60` |
| training generation settings | `temperature=1.2`, `top_p=0.95`, `max_completion_length=8000`, `max_prompt_length=15500` |
| checkpoints summarized | `0`, `20`, `40`, `60`, `80`, `100`, `120` |
| input file | `outputs/old-dev-schema-tool.jsonl` |
| database dir | `/home/ec2-user/nl2sql-gspo-gemma4/databases/dev_databases` |
| difficulty file | `data/bird_dev_data/raw/dev_20251106.json` |
| examples | `1534` |
| generations per example | `16` |
| candidates per checkpoint | `24544` |
| temperature | `1.2` |
| top_p | `1.0` |
| max_new_tokens | `8000` |
| max_tool_rounds | `8` |
| vLLM tensor parallel size | `1` |
| GPUs per checkpoint run | `1` |
| vLLM max model length | `45000` from run naming `ctx45k` |
| vLLM async concurrency | `16` |
| model path template | training run path plus `checkpoint-{step}` |

Output folders:

| checkpoint | output folder |
| ---: | --- |
| 0 | `outputs/passk/maskfix_ckpt-0_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |
| 20 | `outputs/passk/maskfix_ckpt-20_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |
| 40 | `outputs/passk/maskfix_ckpt-40_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |
| 60 | `outputs/passk/maskfix_ckpt-60_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |
| 80 | `outputs/passk/maskfix_ckpt-80_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |
| 100 | `outputs/passk/maskfix_ckpt-100_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |
| 120 | `outputs/passk/maskfix_ckpt-120_old-dev-schema-tool_full1534_temp1p2_tp1_ctx45k` |

Each output folder contains `passk_summary.json`, `passk_summary.md`, `passk_candidates_raw.jsonl`, `passk_candidates.jsonl`, and `passk_per_example.jsonl`.

### Pass@K And Self-Consistency Results

The table uses estimated pass@k from `pass_at_k_estimated`; pass@1 is the same as candidate accuracy. Training entropy and grad norm come from saved `trainer_state.json` checkpoint metadata.

| checkpoint | pass@1 | pass@2 | pass@4 | pass@8 | pass@16 | SC option 1 | SC option 2 | temp0 acc | temp0 avg calls | pass@k avg calls/gen | correct candidates | candidate acc | train entropy | grad norm |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `63.64%` | `69.71%` | `73.79%` | `77.05%` | `79.79%` | `67.86%` | `67.99%` | `65.12%` | `1.306` | `1.303` | `15619 / 24544` | `63.64%` | `0.4026` | `0.005927` |
| 20 | `63.73%` | `70.13%` | `74.01%` | `76.89%` | `79.27%` | `68.77%` | `68.90%` | `65.97%` | `1.374` | `1.439` | `15641 / 24544` | `63.73%` | `0.2822` | `0.04908` |
| 40 | `62.04%` | `67.88%` | `71.52%` | `74.47%` | `76.92%` | `66.30%` | `66.43%` | `62.45%` | `4.211` | `3.947` | `15226 / 24544` | `62.04%` | `0.1049` | `0.1286` |
| 60 | `65.41%` | `70.09%` | `73.04%` | `75.25%` | `77.12%` | `68.58%` | `68.77%` | `66.82%` | `3.057` | `2.965` | `16054 / 24544` | `65.41%` | `0.1079` | `0.1908` |
| 80 | `64.85%` | `68.77%` | `71.69%` | `73.84%` | `75.42%` | `67.28%` | `67.28%` | `64.93%` | `2.877` | `2.871` | `15917 / 24544` | `64.85%` | `0.09862` | `0.2043` |
| 100 | `66.22%` | `70.13%` | `73.11%` | `75.40%` | `77.25%` | `67.80%` | `67.93%` | `66.17%` | `2.480` | `2.461` | `16253 / 24544` | `66.22%` | `0.1573` | `0.02835` |
| 120 | `65.40%` | `69.55%` | `72.80%` | `75.50%` | `77.84%` | `67.47%` | `67.80%` | `66.36%` | `2.590` | `2.588` | `16052 / 24544` | `65.40%` | `0.1665` | `0.0832` |
| 140 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.78%` | `2.640` | `n/a` | `n/a` | `n/a` | `0.1798` | `0.03216` |
| 160 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.71%` | `2.007` | `n/a` | `n/a` | `n/a` | `0.1530` | `0.08619` |
| 180 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `64.73%` | `2.602` | `n/a` | `n/a` | `n/a` | `0.07898` | `0.09490` |

### Training Reward Metrics

These are the training reward means from the same logged training steps as the checkpoint rows above. `temp0 acc` is repeated from the inference sweep as an evaluation reference, not as a training reward.

| checkpoint | temp0 acc | pred failed | learning rate | format reward | execution reward | result reward | table link reward | column link reward | nonnull reward | train reward |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `65.12%` | `26` | `0` | `0.9852` | `0.9644` | `0.7804` | `0.7804` | `0.8459` | `0.9462` | `5.303` |
| 20 | `65.97%` | `18` | `1.9925e-6` | `0.9826` | `0.9783` | `0.7769` | `0.8455` | `0.8364` | `0.9401` | `5.36` |
| 40 | `62.45%` | `108` | `1.91745e-6` | `0.9366` | `0.934` | `0.6997` | `0.8212` | `0.8103` | `0.9253` | `5.127` |
| 60 | `66.82%` | `32` | `1.8424e-6` | `0.9861` | `0.987` | `0.7569` | `0.8455` | `0.8208` | `0.9792` | `5.375` |
| 80 | `64.93%` | `72` | `1.76735e-6` | `0.9314` | `0.9288` | `0.7552` | `0.7648` | `0.781` | `0.9253` | `5.087` |
| 100 | `66.17%` | `33` | `1.69231e-6` | `0.9748` | `0.9774` | `0.7457` | `0.8438` | `0.8405` | `0.9705` | `5.353` |
| 120 | `66.36%` | `32` | `1.61726e-6` | `0.9766` | `0.9922` | `0.7205` | `0.8082` | `0.8571` | `0.9896` | `5.344` |
| 140 | `65.78%` | `34` | `1.54221e-6` | `0.9826` | `0.9835` | `0.7743` | `0.855` | `0.8461` | `0.9688` | `5.41` |
| 160 | `65.71%` | `26` | `1.46717e-6` | `0.8837` | `0.9844` | `0.7014` | `0.7648` | `0.8093` | `0.9696` | `5.112` |
| 180 | `64.73%` | `35` | `1.39212e-6` | `0.9731` | `0.9705` | `0.8273` | `0.8828` | `0.8358` | `0.9592` | `5.449` |

Entropy drops sharply from checkpoint `0` to `40`, then stays low with small rebounds at `100` and `120`. Accuracy does not improve monotonically: pass@1 bottoms at `40`, peaks at `100`, then gives some back at `120`; pass@16 is actually highest at `0` and remains below the starting point through `120`. This suggests the model is becoming less exploratory while the single-sample candidate accuracy gets a modest, noisy gain, and the marginal benefit from sampling is smaller after training.

Self-consistency was computed by executing the 16 sampled SQLs for each prompt and clustering them by execution result. Option 1 selects from the largest valid, non-empty execution-result cluster among the 16 sampled generations; ties are broken by the checkpoint's temperature-0 SQL when that SQL is also valid and non-empty. Option 2 adds the checkpoint's temperature-0 SQL as a 17th candidate before clustering, then selects from the largest valid, non-empty cluster. The full checkpoint sweep, `0` through `120` in increments of `20`, was rerun after patching the evaluator to never choose clusters whose SQL fails execution or executes to an empty result set.

Rows marked `n/a` do not have corresponding artifacts in this checkout. Pass@k/self-consistency artifacts are not present for checkpoints `140`, `160`, or `180`. Temp-0 eval summaries are present directly under checkpoints `140` and `160`; checkpoint `180` stores its temp-0 eval summary under `checkpoint-180/temp0_old-dev-schema-tool_full1534_vllm_async_tp1_ctx45k_p35k_o8k`. Self-consistency artifacts are in `outputs/analysis/maskfix_self_consistency`.

## Beta Schedule With Basic DAPO - 2026-05-28

Current E4B bare-tool GRPO/DAPO run with in-process beta scheduling. The run uses `beta=0.005` for steps `0-39`, `beta=0.001` for steps `40-79`, and `beta=0` from step `80` onward. DAPO uses `dynamic_sampling_reward_name=result_reward`, `dapo_oversample_factor=6`, `dapo_max_rounds=1`, `num_generations=16`, `per_device_train_batch_size=4`, `gradient_accumulation_steps=8`, and `learning_rate=1e-6`.

### Figures

| plot | file |
| --- | --- |
| accuracy, SC, and entropy | `figures/beta_schedule/checkpoint_accuracy_entropy_sc.svg` |
| sampling lift | `figures/beta_schedule/sampling_lift.svg` |
| tool calls and failed predictions | `figures/beta_schedule/tool_calls_and_failures.svg` |
| best checkpoint summary | `figures/beta_schedule/best_checkpoint_summary.svg` |

| setting | value |
| --- | --- |
| training run | `outputs/training/beta_exp_0528/train-6601-schema-bare-tool/gemma-4-E4B-it/grpo_deepspeed_p15500_c8000_g16_t1p2_bs4_ga8_lr1e-6_inprocess_beta0p005_s0-40_beta0p001_s40-80_beta0_s80plus_olddev32_refinitfix_nods_20260527_204225` |
| wandb run | `https://wandb.ai/kpratik41/gemma4-31b-bird-gspo/runs/kyh0txsp` |
| train file | `outputs/train-6601-schema-bare-tool.jsonl` |
| eval file during training | `outputs/old-dev-schema-bare-tool.jsonl` with `eval_limit=32`, `eval_steps=350` |
| reward weights | `0.2,0.5,2.0,0.5,0.5,0.1,0.1` for format, execution, result, table_linking, column_linking, nonnull, length_penalty |
| checkpoint rows | `0`, `10`, `20`, ..., `160` |

### Pass@K And Self-Consistency Results

Pass@k and self-consistency columns are filled where sampled checkpoint evaluation artifacts exist. Checkpoints without pass@k artifacts are marked `n/a`. Training entropy and grad norm come from the live training log at the corresponding logged step. Checkpoint `160` pass@k was run as four `tp=1` shards and then merged under `checkpoint-160/passk16_olddev_schema_tool_temp1p2_tp1_shards4_ctx43k/merged`.

| checkpoint | pass@1 | pass@2 | pass@4 | pass@8 | pass@16 | SC option 1 | SC option 2 | temp0 acc | temp0 avg calls | pass@k avg calls/gen | correct candidates | candidate acc | train entropy | grad norm |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `63.64%` | `69.71%` | `73.79%` | `77.05%` | `79.79%` | `67.99%` | `68.06%` | `65.12%` | `1.306` | `1.303` | `15619 / 24544` | `63.64%` | `0.4057` | `0.009281` |
| 10 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.45%` | `1.292` | `n/a` | `n/a` | `n/a` | `0.4092` | `0.00278` |
| 20 | `63.89%` | `69.97%` | `73.98%` | `77.07%` | `79.53%` | `69.04%` | `68.77%` | `65.65%` | `1.318` | `1.299` | `15680 / 24544` | `63.89%` | `0.3964` | `0.005587` |
| 30 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.91%` | `1.314` | `n/a` | `n/a` | `n/a` | `0.3584` | `0.01246` |
| 40 | `64.22%` | `70.42%` | `74.65%` | `77.83%` | `80.18%` | `68.71%` | `68.71%` | `65.25%` | `1.287` | `1.287` | `15761 / 24544` | `64.22%` | `0.2766` | `0.01284` |
| 50 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.91%` | `1.295` | `n/a` | `n/a` | `n/a` | `0.3696` | `0.01213` |
| 60 | `65.01%` | `70.92%` | `74.89%` | `77.87%` | `79.99%` | `69.17%` | `69.17%` | `65.58%` | `1.297` | `1.283` | `15957 / 24544` | `65.01%` | `0.1876` | `0.0144` |
| 70 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `66.82%` | `1.322` | `n/a` | `n/a` | `n/a` | `0.4164` | `0.005197` |
| 80 | `65.45%` | `71.09%` | `74.91%` | `77.65%` | `79.86%` | `69.17%` | `69.30%` | `65.45%` | `1.322` | `1.256` | `16064 / 24544` | `65.45%` | `0.3325` | `0.00641` |
| 90 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.78%` | `1.280` | `n/a` | `n/a` | `n/a` | `0.2575` | `0.04708` |
| 100 | `65.77%` | `71.15%` | `74.87%` | `77.55%` | `79.60%` | `69.10%` | `69.04%` | `66.17%` | `1.244` | `1.242` | `16143 / 24544` | `65.77%` | `0.3197` | `0.02186` |
| 110 | `66.17%` | `71.48%` | `75.27%` | `78.08%` | `80.18%` | `69.62%` | `70.01%` | `67.93%` | `1.290` | `1.252` | `16241 / 24544` | `66.17%` | `0.2894` | `0.01925` |
| 120 | `66.79%` | `71.86%` | `75.37%` | `78.00%` | `79.92%` | `70.86%` | `70.80%` | `67.21%` | `1.314` | `1.281` | `16392 / 24544` | `66.79%` | `0.2013` | `0.06403` |
| 130 | `66.95%` | `71.81%` | `75.19%` | `77.76%` | `79.79%` | `70.73%` | `70.73%` | `68.45%` | `1.355` | `1.295` | `16432 / 24544` | `66.95%` | `0.2862` | `0.04674` |
| 140 | `66.92%` | `71.70%` | `75.01%` | `77.52%` | `79.60%` | `70.34%` | `70.40%` | `67.86%` | `1.338` | `1.289` | `16426 / 24544` | `66.92%` | `0.08412` | `0.05487` |
| 150 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `67.54%` | `1.374` | `n/a` | `n/a` | `n/a` | `0.3102` | `0.02834` |
| 160 | `66.49%` | `71.32%` | `74.80%` | `77.50%` | `79.53%` | `70.21%` | `70.21%` | `67.80%` | `1.362` | `1.296` | `16319 / 24544` | `66.49%` | `0.2477` | `0.03434` |

### Training Reward Metrics

Training reward means come from the live training log. `temp0 acc` is copied from the full 1534-sample checkpoint eval artifacts.

| checkpoint | temp0 acc | pred failed | learning rate | beta | format reward | execution reward | result reward | table link reward | column link reward | nonnull reward | train reward |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `65.12%` | `26` | `5.882e-08` | `0.005` | `0.9852` | `0.9748` | `0.7812` | `0.7656` | `0.841` | `0.9592` | `5.307` |
| 10 | `65.45%` | `31` | `6.471e-07` | `0.005` | `0.9948` | `0.9957` | `0.6944` | `0.7925` | `0.8326` | `0.9818` | `5.292` |
| 20 | `65.65%` | `26` | `9.925e-07` | `0.005` | `0.9913` | `0.974` | `0.763` | `0.8698` | `0.8354` | `0.9479` | `5.381` |
| 30 | `65.91%` | `30` | `9.737e-07` | `0.005` | `0.9826` | `0.9818` | `0.7899` | `0.8394` | `0.8605` | `0.9583` | `5.413` |
| 40 | `65.25%` | `26` | `9.55e-07` | `0.001` | `0.9948` | `0.9965` | `0.7292` | `0.8446` | `0.8563` | `0.9835` | `5.405` |
| 50 | `65.91%` | `21` | `9.362e-07` | `0.001` | `0.9774` | `0.9757` | `0.7257` | `0.8368` | `0.8501` | `0.9679` | `5.334` |
| 60 | `65.58%` | `30` | `9.174e-07` | `0.001` | `0.9922` | `0.9844` | `0.75` | `0.8177` | `0.822` | `0.9705` | `5.337` |
| 70 | `66.82%` | `24` | `8.987e-07` | `0.001` | `0.9809` | `0.9688` | `0.7083` | `0.8325` | `0.8226` | `0.9531` | `5.266` |
| 80 | `65.45%` | `39` | `8.799e-07` | `0` | `0.9757` | `0.9792` | `0.7405` | `0.7951` | `0.8306` | `0.9627` | `5.284` |
| 90 | `65.78%` | `34` | `8.612e-07` | `0` | `0.9896` | `0.9896` | `0.7101` | `0.7951` | `0.7774` | `0.98` | `5.242` |
| 100 | `66.17%` | `39` | `8.424e-07` | `0` | `0.9948` | `0.9896` | `0.7335` | `0.8108` | `0.8442` | `0.9661` | `5.338` |
| 110 | `67.93%` | `29` | `8.236e-07` | `0` | `0.9931` | `0.9835` | `0.7604` | `0.9089` | `0.8885` | `0.9757` | `5.51` |
| 120 | `67.21%` | `35` | `8.049e-07` | `0` | `0.9991` | `0.9991` | `0.7179` | `0.8655` | `0.8581` | `0.9974` | `5.437` |
| 130 | `68.45%` | `28` | `7.861e-07` | `0` | `0.9922` | `0.9878` | `0.776` | `0.8776` | `0.831` | `0.9635` | `5.428` |
| 140 | `67.86%` | `37` | `7.674e-07` | `0` | `0.9974` | `0.9965` | `0.796` | `0.901` | `0.817` | `0.9965` | `5.504` |
| 150 | `67.54%` | `37` | `7.486e-07` | `0` | `0.9922` | `0.9922` | `0.7457` | `0.8576` | `0.8547` | `0.9792` | `5.422` |
| 160 | `67.80%` | `26` | `7.317e-07` | `0` | `0.9948` | `0.9931` | `0.7196` | `0.7995` | `0.8186` | `0.9748` | `5.3` |

### Candidate And Tool Stats

`total tool calls` and `avg calls / candidate` come from `passk_summary.json`. Per-tool counts are parsed from `passk_candidates_raw.jsonl`, so they reflect tool-call-looking names in the raw model text.

| checkpoint | examples | candidates | pred executed | pred failed | total tool calls | avg calls / candidate | `sqlite_query` | `sqlite_peek` | `bm25_search_sqlite` | total time |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `1534` | `24544` | `23370` | `1174` | `31969` | `1.303` | `29991` | `1102` | `868` | `5.44 h` |
| 20 | `1534` | `24544` | `23385` | `1159` | `35310` | `1.439` | `33036` | `1340` | `913` | `4.18 h` |
| 40 | `1534` | `24544` | `23130` | `1414` | `96882` | `3.947` | `80820` | `8673` | `7017` | `5.21 h` |
| 60 | `1534` | `24544` | `23969` | `575` | `72767` | `2.965` | `68081` | `2792` | `1883` | `5.30 h` |
| 80 | `1534` | `24544` | `23709` | `835` | `70463` | `2.871` | `65198` | `2923` | `2348` | `4.80 h` |
| 100 | `1534` | `24544` | `24195` | `349` | `60399` | `2.461` | `55448` | `2710` | `2238` | `4.74 h` |
| 120 | `1534` | `24544` | `24167` | `377` | `63513` | `2.588` | `57918` | `2657` | `2942` | `5.63 h` |

### Approx Runtime

These are approximate wall-clock runtimes from `timing_seconds`, with each checkpoint run using 1 GPU.

| checkpoint | generation | evaluation | total |
| ---: | ---: | ---: | ---: |
| 0 | `5.33 h` | `0.11 h` | `5.44 h` |
| 20 | `4.06 h` | `0.12 h` | `4.18 h` |
| 40 | `5.10 h` | `0.10 h` | `5.21 h` |
| 60 | `5.19 h` | `0.11 h` | `5.30 h` |
| 80 | `4.67 h` | `0.13 h` | `4.80 h` |
| 100 | `4.60 h` | `0.13 h` | `4.74 h` |
| 120 | `5.48 h` | `0.15 h` | `5.63 h` |

### Stop Reasons And Token Stats

| checkpoint | finished | max tool rounds | context length exceeded | max new tokens | avg completion tokens | max prompt tokens |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `24508` | `24` | `9` | `3` | `798.6` | `29692` |
| 20 | `24483` | `57` | `3` | `1` | `588.8` | `29692` |
| 40 | `23694` | `837` | `10` | `3` | `696.3` | `29692` |
| 60 | `24300` | `229` | `3` | `12` | `736.0` | `29692` |
| 80 | `23798` | `724` | `6` | `16` | `648.8` | `29692` |
| 100 | `24301` | `227` | `6` | `10` | `658.1` | `29692` |
| 120 | `24240` | `280` | `4` | `20` | `793.6` | `29692` |

## Beta schedule: Gemma-4-31b-it

Current 31B bare-tool GRPO/DAPO run with in-process beta scheduling. This run has two phases: the original launch used DAPO oversample factor `10`, then the run was restarted from the latest full checkpoint at global step `40` with the same output directory, reshuffled training data, DAPO oversample factor `16`, and a shorter beta schedule. Because resume uses trainer `global_step`, the beta schedule did not restart at local step `0`; the resumed run began at global step `40`, used `beta=0.001` through global step `64`, and switched to `beta=0` at global step `65`.

The output directory still contains `dapo10` in its name, but checkpoints `50+` come from the resumed `dapo16` phase. Checkpoint `0` rows use the logged step `1` values because there is no logged step `0` metrics row.

| setting | value |
| --- | --- |
| training run | `outputs/training/0530_beta_schedule_gemma-4-31b-it/training/train-6601-schema-bare-tool/gemma-4-31B-it/grpo_deepspeed_p15500_c8000_g16_t1p2_bs2_ga16_lr1e-6_inprocess_beta0p005_s0-40_beta0p001_s40-80_beta0_s80plus_olddev32_refinitfix_nods_dapo10_20260529_062557` |
| model | `google/gemma-4-31B-it`; full fine-tune, `31,273,086,512` trainable params |
| train file | `outputs/train-6601-schema-bare-tool.jsonl`; reshuffled in place before the restart, with backup `outputs/train-6601-schema-bare-tool.jsonl.pre_restart_shuffle_20260531_031008.bak` |
| eval file during training | `outputs/old-dev-schema-bare-tool.jsonl` with `eval_limit=32`, reward-only eval |
| original phase | launched `2026-05-29 06:26 UTC`; run name `train-6601-schema-bare-tool-31b-grpo-dapo-lr1e-6-inprocess-beta005-001-0-olddev32-refinitfix-nods-dapo10-20260529`; DAPO `K=10`; beta schedule `0:0.005,40:0.001,80:0` |
| resumed phase | launched `2026-05-31 03:12 UTC` from `latest-full-checkpoint` / `global_step40`; run name `train-6601-schema-bare-tool-31b-grpo-dapo-lr1e-6-inprocess-beta001-0-from40-65-olddev32-refinitfix-nods-dapo16-20260531`; DAPO `K=16`; beta schedule `40:0.001,65:0` |
| resume nuance | the process had reached roughly step `45`, but the latest full checkpoint was step `40`, so unsaved steps `41-45` were discarded |
| generation settings changed in launch | `temperature=1.2`, `top_p=0.95`, `num_generations=16`, `max_prompt_length=15500`, `max_completion_length=8000`, `max_tool_calling_iterations=8` |
| batch and optimization | `per_device_train_batch_size=2`, `gradient_accumulation_steps=16` from DeepSpeed, effective train prompts per optimizer step `192`, `learning_rate=1e-6` with warmup/decay as logged |
| DAPO criterion | `dynamic_sampling_reward_name=result_reward`, `dapo_max_rounds=1`, `dapo_min_std=1e-06`; original phase attempts `120` groups/step, resumed phase attempts `192` groups/step |
| reward weights | `0.2,0.5,2.0,0.5,0.5,0.1,0.1` for format, execution, result, table_linking, column_linking, nonnull, length_penalty |
| hardware split | train screen uses GPUs `0,1,2,3,4,5`; vLLM screen uses GPUs `6,7`, tensor parallel `2`, `max_model_len=24576`, `dtype=bfloat16` |
| checkpoint rows | `0`, `10`, `20`, ..., `90`; checkpoints `0-40` from original DAPO `10` phase, checkpoints `50-90` from resumed DAPO `16` phase |

### Pass@K And Self-Consistency Results

Pass@k and self-consistency columns are filled where sampled checkpoint evaluation artifacts exist. Checkpoints without pass@k artifacts are marked `n/a`. Temp-0 runs evaluate all `1534` old-dev tool-calling examples. Checkpoint `0` is the base-model copy; checkpoints `20`, `40`, and `80` use sampled checkpoint artifacts stored under their checkpoint folders.

| checkpoint | pass@1 | pass@2 | pass@4 | pass@8 | pass@16 | SC option 1 | SC option 2 | temp0 acc | temp0 avg calls | pass@k avg calls/gen | correct candidates | candidate acc | train entropy | grad norm |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `68.68%` | `70.87%` | `72.37%` | `73.73%` | `74.97%` | `69.95%` | `70.73%` | `71.19%` | `1.269` | `2.208` | `16858 / 24544` | `68.68%` | `0.1692` | `0.2674` |
| 10 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `71.19%` | `1.269` | `n/a` | `n/a` | `n/a` | `0.1661` | `1.806` |
| 20 | `71.41%` | `72.97%` | `74.18%` | `75.32%` | `76.47%` | `72.03%` | `72.03%` | `71.51%` | `1.244` | `1.240` | `17526 / 24544` | `71.41%` | `0.1645` | `0.2788` |
| 30 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `71.84%` | `1.207` | `n/a` | `n/a` | `n/a` | `0.0441` | `7.122` |
| 40 | `71.57%` | `72.48%` | `73.12%` | `73.68%` | `74.19%` | `72.03%` | `71.97%` | `71.45%` | `1.177` | `1.171` | `17566 / 24544` | `71.57%` | `0.08237` | `1.486` |
| 50 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `70.86%` | `1.140` | `n/a` | `n/a` | `n/a` | `0.03986` | `19.97` |
| 60 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `71.25%` | `1.150` | `n/a` | `n/a` | `n/a` | `0.03609` | `1.89` |
| 70 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `70.66%` | `1.153` | `n/a` | `n/a` | `n/a` | `0.07641` | `0.6561` |
| 80 | `71.76%` | `72.94%` | `73.82%` | `74.67%` | `75.62%` | `72.43%` | `72.43%` | `72.03%` | `1.160` | `1.166` | `17613 / 24544` | `71.76%` | `0.01757` | `0.02987` |
| 90 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `72.10%` | `1.172` | `n/a` | `n/a` | `n/a` | `0.06899` | `12.12` |

### Training Dynamics

Training entropy, grad norm, DAPO selection stats, and rewards come from the live training logs at each checkpoint interval. The pre-restart metric row for checkpoint `40` still reports `beta=0.005`; after resume, generation starts at global step `40` with `beta=0.001`, so checkpoint `50+` reflects the resumed schedule.

| checkpoint | phase | beta | learning rate | train entropy | grad norm | train reward | DAPO attempted | heterogeneous | kept | padded | fill rate | tool calls/gen | step time |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | pre-restart DAPO 10 | `0.005` | `5.88e-08` | `0.1692` | `0.2674` | `5.47` | `120` | `15` | `10` | `2` | `0.8333` | `1.486` | `4156` |
| 10 | pre-restart DAPO 10 | `0.005` | `5.88e-07` | `0.1661` | `1.806` | `5.386` | `120` | `14` | `10` | `2` | `0.8333` | `1.559` | `4026` |
| 20 | pre-restart DAPO 10 | `0.005` | `9.94e-07` | `0.1645` | `0.2788` | `5.395` | `120` | `13` | `9` | `3` | `0.75` | `1.494` | `3538` |
| 30 | pre-restart DAPO 10 | `0.005` | `9.76e-07` | `0.0441` | `7.122` | `5.511` | `120` | `5` | `5` | `7` | `0.4167` | `1.124` | `3135` |
| 40 | pre-restart DAPO 10 | `0.005` | `9.57e-07` | `0.08237` | `1.486` | `5.477` | `120` | `8` | `8` | `4` | `0.6667` | `1.333` | `2655` |
| 50 | resume DAPO 16 | `0.001` | `9.38e-07` | `0.03986` | `19.97` | `5.466` | `192` | `5` | `5` | `7` | `0.4167` | `1.153` | `2487` |
| 60 | resume DAPO 16 | `0.001` | `9.19e-07` | `0.03609` | `1.89` | `5.562` | `192` | `7` | `7` | `5` | `0.5833` | `1.246` | `3165` |
| 70 | resume DAPO 16 | `0` | `9.01e-07` | `0.07641` | `0.6561` | `5.455` | `192` | `6` | `6` | `6` | `0.5` | `1.25` | `4045` |
| 80 | resume DAPO 16 | `0` | `8.82e-07` | `0.01757` | `0.02987` | `5.516` | `192` | `1` | `1` | `11` | `0.08333` | `1.235` | `4462` |
| 90 | resume DAPO 16 | `0` | `8.63e-07` | `0.06899` | `12.12` | `5.453` | `192` | `10` | `8` | `4` | `0.6667` | `1.401` | `3403` |

### Training Reward Metrics

Training reward means come from the live training logs. `temp0 acc` and `pred failed` are copied from the full 1534-sample checkpoint eval artifacts.

| checkpoint | phase | temp0 acc | pred failed | beta | format reward | execution reward | result reward | table link reward | column link reward | nonnull reward | length penalty | train reward |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | pre-restart DAPO 10 | `71.19%` | `16` | `0.005` | `0.9781` | `0.9776` | `0.8245` | `0.8833` | `0.834` | `0.9766` | `-0.004486` | `5.47` |
| 10 | pre-restart DAPO 10 | `71.19%` | `18` | `0.005` | `0.9854` | `0.9807` | `0.749` | `0.8495` | `0.8446` | `0.9792` | `-0.002149` | `5.386` |
| 20 | pre-restart DAPO 10 | `71.51%` | `12` | `0.005` | `0.9734` | `0.9729` | `0.7641` | `0.8807` | `0.8308` | `0.9729` | `0` | `5.395` |
| 30 | pre-restart DAPO 10 | `71.84%` | `15` | `0.005` | `1` | `1` | `0.8068` | `0.8557` | `0.848` | `1` | `0` | `5.511` |
| 40 | pre-restart DAPO 10 | `71.45%` | `12` | `0.005` | `0.988` | `0.9885` | `0.8141` | `0.8521` | `0.8459` | `0.9885` | `0` | `5.477` |
| 50 | resume DAPO 16 | `70.86%` | `11` | `0.001` | `0.9997` | `0.9997` | `0.735` | `0.8757` | `0.8567` | `0.9997` | `0` | `5.466` |
| 60 | resume DAPO 16 | `71.25%` | `11` | `0.001` | `0.9948` | `0.9938` | `0.8034` | `0.9154` | `0.8612` | `0.9938` | `0` | `5.562` |
| 70 | resume DAPO 16 | `70.66%` | `12` | `0` | `0.9951` | `0.9909` | `0.7533` | `0.8698` | `0.8554` | `0.9906` | `0` | `5.455` |
| 80 | resume DAPO 16 | `72.03%` | `10` | `0` | `0.9922` | `0.9899` | `0.8089` | `0.889` | `0.8458` | `0.9899` | `0` | `5.516` |
| 90 | resume DAPO 16 | `72.10%` | `14` | `0` | `0.9873` | `0.986` | `0.806` | `0.8646` | `0.8245` | `0.9847` | `0` | `5.453` |

## Old Dev 1534 Inference Comparison: Gemma 4 31B vs E4B

These are single-generation async vLLM inference runs over all 1534 old-dev samples with `temperature=0.0`, `top_p=1.0`, `max_new_tokens=8000`, `max_tool_rounds=8`, `eval_workers=16`, and `vllm_async_concurrency=16`.

For `google/gemma-4-31B-it`, the two tool-format runs used tensor parallel size 4 with `vllm_max_model_len=43000`; the two consensus-format reruns used tensor parallel size 1 with `vllm_max_model_len=45000`. For `google/gemma-4-E4B-it`, all runs used tensor parallel size 1; `old-dev-schema-consensus` was rerun with `vllm_max_model_len=45000`.

| model | input | accuracy | correct / total | pred executed | pred failed | pred missing SQL | total time |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `gemma-4-31B-it` | `old-dev-schema-tool` | `71.19%` | `1092 / 1534` | `1518` | `16` | `16` | `33.2 min` |
| `gemma-4-31B-it` | `old-dev-schema-bare-tool` | `69.17%` | `1061 / 1534` | `1501` | `33` | `29` | `20.6 min` |
| `gemma-4-31B-it` | `old-dev-schema-consensus` | `66.49%` | `1020 / 1534` | `1425` | `109` | `109` | `372.9 min` |
| `gemma-4-31B-it` | `old-dev-schema-bare-consensus` | `64.02%` | `982 / 1534` | `1409` | `125` | `125` | `205.5 min` |
| `gemma-4-E4B-it` | `old-dev-schema-tool` | `64.86%` | `995 / 1534` | `1495` | `39` | `33` | `22.3 min` |
| `gemma-4-E4B-it` | `old-dev-schema-bare-tool` | `63.43%` | `973 / 1534` | `1499` | `35` | `26` | `15.5 min` |
| `gemma-4-E4B-it` | `old-dev-schema-consensus` | `64.60%` | `991 / 1534` | `1480` | `54` | `42` | `42.2 min` |
| `gemma-4-E4B-it` | `old-dev-schema-bare-consensus` | `61.67%` | `946 / 1534` | `1467` | `67` | `53` | `33.5 min` |

## Old Dev Pass@K Summary

These pass@k runs used `temperature=1.2`, `top_p=1.0`, `num_generations=16`, `max_new_tokens=8000`, `max_tool_rounds=8`, and async vLLM over all 1534 old-dev samples. Each full run generated `24544` candidates.

| model | input | samples | candidate acc / pass@1 | pass@8 | pass@16 | avg tool calls / candidate |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `gemma-4-31B-it` | `old-dev-schema-tool` | `1534` | `68.68%` | `73.73%` | `74.97%` | `2.21` |
| `gemma-4-31B-it` | `old-dev-schema-bare-tool` | `1534` | `66.17%` | `71.88%` | `73.14%` | `2.51` |
| `gemma-4-E4B-it` | `old-dev-schema-tool` | `1534` | `63.60%` | `76.84%` | `78.94%` | `1.30` |
| `gemma-4-E4B-it` | `old-dev-schema-bare-tool` | `1534` | `61.58%` | `74.81%` | `77.51%` | `1.34` |
| `gemma-4-E4B-it` | `old-dev-schema-consensus` | `1534` | `60.77%` | `76.45%` | `78.68%` | `2.40` |
| `gemma-4-E4B-it` | `old-dev-schema-bare-consensus` | `1534` | `58.66%` | `73.69%` | `76.34%` | `2.42` |

## Old Dev Tool Pass@K Full Runs: Gemma 4 31B, Async vLLM, Temperature 1.2

These two runs evaluate `google/gemma-4-31B-it` on the full old-dev split with 16 sampled tool-calling generations per example. The generation artifacts were scored by executing predicted SQL against the BIRD dev databases and comparing execution results with the gold SQL.

The first `old-dev-schema-tool` scoring pass initially produced an invalid all-zero summary because the relative `databases/dev_databases` path did not exist from this checkout. A `databases` symlink was added to the real database root, `/home/ec2-user/nl2sql-gspo-gemma4/databases`, and the run was re-scored from `passk_candidates_raw.jsonl` using the existing `scripts/run_passk_bird.py` post-generation scoring functions with `eval_workers=16`. The numbers below are the corrected summaries.

Result folders:

```text
outputs/passk/gemma4_31b_old-dev-schema-tool_full1534_temp1p2_tp4_ctx45k
outputs/passk/gemma4_31b_old-dev-schema-bare-tool_full1534_temp1p2_tp4_ctx45k
```

### Run Configuration

| setting | value |
| --- | --- |
| model | `google/gemma-4-31B-it` |
| input files | `outputs/old-dev-schema-tool.jsonl`, `outputs/old-dev-schema-bare-tool.jsonl` |
| database dir | `databases/dev_databases` via symlink to `/home/ec2-user/nl2sql-gspo-gemma4/databases/dev_databases` |
| difficulty file | `data/bird_dev_data/raw/dev_20251106.json` |
| examples | `1534` |
| generations per example | `16` |
| candidates per run | `24544` |
| temperature | `1.2` |
| top_p | `1.0` |
| max_prompt_length | `35000` |
| max_new_tokens | `8000` |
| max_tool_rounds | `8` |
| vLLM tensor parallel size | `4` |
| vLLM max model length | `45000` |
| vLLM GPU memory utilization | `0.90` |
| vLLM async concurrency | `16` |
| eval workers | `16` |

### Pass@K Results

| input | candidate acc / pass@1 | prefix pass@1 | estimated pass@8 | prefix pass@8 | estimated pass@16 | prefix pass@16 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `68.68%` | `68.58%` | `73.73%` | `73.60%` | `74.97%` | `74.97%` |
| `old-dev-schema-bare-tool` | `66.17%` | `66.62%` | `71.88%` | `72.16%` | `73.14%` | `73.14%` |

### Candidate And Execution Stats

| input | correct candidates | pred executed | pred failed | stop: finished | stop: max tool rounds | stop: max new tokens | total time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `16858 / 24544` | `24277` | `267` | `24413` | `104` | `27` | `43292.0s` |
| `old-dev-schema-bare-tool` | `16240 / 24544` | `24190` | `354` | `24349` | `169` | `26` | `42880.7s` |

### Tool Usage

| input | total tool calls | avg calls / candidate | `sqlite_query` | `sqlite_peek` | `bm25_search_sqlite` | other parsed names |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `54185` | `2.21` | `51979` | `1123` | `1068` | `15` |
| `old-dev-schema-bare-tool` | `61610` | `2.51` | `57825` | `2432` | `1319` | `35` |

### Tool Round Distribution

| tool rounds / candidate | `old-dev-schema-tool` | `old-dev-schema-bare-tool` |
| ---: | ---: | ---: |
| 0 | `6` | `4` |
| 1 | `1875` | `1637` |
| 2 | `17712` | `13522` |
| 3 | `3837` | `6725` |
| 4 | `726` | `1699` |
| 5 | `155` | `398` |
| 6 | `59` | `188` |
| 7 | `50` | `128` |
| 8 | `124` | `243` |

Compared with the E4B pass@k runs below, `gemma-4-31B-it` has much higher candidate accuracy, but much smaller gain from additional samples. On `old-dev-schema-tool`, E4B improves from `63.60%` pass@1 to `78.94%` pass@16, a `+15.35 pp` lift; 31B improves from `68.68%` to `74.97%`, a `+6.28 pp` lift. On the bare-tool data, E4B improves by `+15.93 pp`, while 31B improves by `+6.98 pp`.

A simple candidate-diversity check supports this: 31B produced fewer distinct SQL strings per example despite more tool calls. On `old-dev-schema-tool`, 31B averaged `3.37` unique SQL strings per 16 candidates, versus E4B at `6.31`. On `old-dev-schema-bare-tool`, 31B averaged `3.74`, versus E4B at `6.89`. The 31B model also had more examples where all 16 candidates were correct (`880` tool, `813` bare-tool), but more examples with zero correct candidates (`384` tool, `412` bare-tool) than E4B (`323` tool, `345` bare-tool). This pattern is consistent with higher single-sample accuracy but more correlated samples: when 31B knows the answer, it often repeats a correct family; when it misses, extra samples less often escape the same failure mode.

## Old Dev Gemma 4 E4B Inference: Async vLLM, Temperature 0.0, 1534 Samples

These runs evaluate one greedy/tool-calling generation per example over the full old-dev split. All four runs used `google/gemma-4-E4B-it`, async vLLM, `temperature=0.0`, `top_p=1.0`, `max_new_tokens=8000`, `max_tool_rounds=8`, `vllm_tensor_parallel_size=1`, and `vllm_async_concurrency=16`.

The `old-dev-schema-consensus` run initially failed at `vllm_max_model_len=43000` because the tool-loop prompt reached at least `43001` tokens. It was rerun successfully with `vllm_max_model_len=45000` while overwriting the original output folder.

Result folders:

```text
outputs/inference/dev/old-dev-schema-tool/google-gemma-4-E4B-it/vllm_async_tp1_dp1_c16_ctx43k_p34k_o8k_r8_temp0
outputs/inference/dev/old-dev-schema-bare-tool/google-gemma-4-E4B-it/vllm_async_tp1_dp1_c16_ctx43k_p34k_o8k_r8_temp0
outputs/inference/dev/old-dev-schema-consensus/google-gemma-4-E4B-it/vllm_async_tp1_dp1_c16_ctx43k_p34k_o8k_r8_temp0
outputs/inference/dev/old-dev-schema-bare-consensus/google-gemma-4-E4B-it/vllm_async_tp1_dp1_c16_ctx43k_p34k_o8k_r8_temp0
```

### Main Results

| input | accuracy | correct / total | pred executed | pred failed | pred missing SQL | total time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `64.86%` | `995 / 1534` | `1495` | `39` | `33` | `22.3 min` |
| `old-dev-schema-bare-tool` | `63.43%` | `973 / 1534` | `1499` | `35` | `26` | `15.5 min` |
| `old-dev-schema-consensus` | `64.60%` | `991 / 1534` | `1480` | `54` | `42` | `42.2 min` |
| `old-dev-schema-bare-consensus` | `61.67%` | `946 / 1534` | `1467` | `67` | `53` | `33.5 min` |

### By Difficulty

| input | simple | moderate | challenging |
| --- | ---: | ---: | ---: |
| `old-dev-schema-tool` | `64.07%` | `63.66%` | `70.13%` |
| `old-dev-schema-bare-tool` | `62.79%` | `63.21%` | `66.23%` |
| `old-dev-schema-consensus` | `63.26%` | `65.01%` | `68.83%` |
| `old-dev-schema-bare-consensus` | `60.47%` | `63.21%` | `63.20%` |

### Tool Usage

| input | avg calls / sample | `sqlite_query` | `sqlite_peek` | `bm25_search_sqlite` | `consensus_at_1` |
| --- | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `1.289` | `1866` | `68` | `45` | `0` |
| `old-dev-schema-bare-tool` | `1.332` | `1940` | `59` | `44` | `0` |
| `old-dev-schema-consensus` | `2.734` | `1631` | `191` | `77` | `2297` |
| `old-dev-schema-bare-consensus` | `2.779` | `1635` | `262` | `85` | `2288` |

### Stop Reasons

| input | finished | max tool rounds | max new tokens |
| --- | ---: | ---: | ---: |
| `old-dev-schema-tool` | `1523` | `10` | `1` |
| `old-dev-schema-bare-tool` | `1525` | `9` | `0` |
| `old-dev-schema-consensus` | `1508` | `20` | `6` |
| `old-dev-schema-bare-consensus` | `1504` | `19` | `11` |

## Old Dev Tool Pass@K Smoke Runs: Gemma 4 31B, Async vLLM, Temperature 1.2, 50 Samples

These two runs use the updated Gemma-native tool-loop stopping behavior in `scripts/run_inference_bird.py`: stop token ids for `<tool_call|>`, `<|tool_response>`, `<turn|>`, and `<eos>`, plus a defensive fallback that keeps only the first parsed tool call in an assistant turn before executing the tool. Each run evaluates the first 50 examples with 16 generations per example, for 800 candidates per run.

Result folders:

```text
outputs/passk/old-dev-schema-tool_stopids_limit50_temp1p2
outputs/passk/old-dev-schema-bare-tool_stopids_limit50_temp1p2
```

### Run Configuration

| setting | value |
| --- | --- |
| model | `google/gemma-4-31B-it` |
| examples | `50` |
| generations per example | `16` |
| total candidates per run | `800` |
| temperature | `1.2` |
| top_p | `1.0` |
| max_new_tokens | `8000` |
| max_tool_rounds | `8` |
| vLLM tensor parallel size | `4` |
| vLLM async concurrency | `16` |

### Pass@K

| run | pass@1 | pass@2 | pass@3 | pass@4 | pass@5 | pass@8 | pass@12 | pass@16 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `68.00%` | `69.80%` | `70.59%` | `71.09%` | `71.43%` | `71.90%` | `72.00%` | `72.00%` |
| `old-dev-schema-bare-tool` | `70.50%` | `72.72%` | `73.64%` | `74.20%` | `74.66%` | `75.80%` | `76.99%` | `78.00%` |

### Candidate And Tool Stats

| run | correct candidates | candidate accuracy | pred executed | pred failed | stop: finished | stop: max_tool_rounds | total tool calls | avg tool calls / generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `old-dev-schema-tool` | `544 / 800` | `68.00%` | `783` | `17` | `783` | `17` | `1105` | `1.381` |
| `old-dev-schema-bare-tool` | `564 / 800` | `70.50%` | `788` | `12` | `788` | `12` | `1099` | `1.374` |

### Tool Call Distribution

| run | `sqlite_query` | `sqlite_peek` | `bm25_search_sqlite` |
| --- | ---: | ---: | ---: |
| `old-dev-schema-tool` | `1046` | `38` | `21` |
| `old-dev-schema-bare-tool` | `1049` | `29` | `21` |

### Tool Round Distribution

| tool rounds / generation | `old-dev-schema-tool` | `old-dev-schema-bare-tool` |
| ---: | ---: | ---: |
| 1 | `679` | `666` |
| 2 | `65` | `78` |
| 3 | `23` | `21` |
| 4 | `8` | `11` |
| 5 | `1` | `7` |
| 6 | `1` | `0` |
| 7 | `0` | `1` |
| 8 | `23` | `16` |

### Tool-Loop Sanity Checks

| check | `old-dev-schema-tool` | `old-dev-schema-bare-tool` |
| --- | ---: | ---: |
| multiple tool calls before first tool response | `0` | `0` |
| multiple tool calls between inserted tool responses | `0` | `0` |
| continuation markers after call before response | `0` | `0` |
| tool calls without response | `0` | `0` |
| parse/tool error rows | `0` | `0` |
| `<|im_end|>` leaked into output | `0` | `0` |
| `<|turn|>` leaked into output | `0` | `0` |
| `<tool_call|>` / `<|tool_call>` leaked into output | `0` | `0` |
| `call:` count equals `<|tool_response>` count | `1105 = 1105` | `1099 = 1099` |

The generated transcripts show the desired tool workflow: one assistant tool call, executor-inserted tool response, then resumed model generation. This is strong output-level evidence that the hallucinated multi-tool-call-before-response issue is resolved for these runs. Direct vLLM finish/stop telemetry is not persisted in these outputs, so proving the exact raw vLLM stop reason would require adding explicit debug logging around `AsyncLLMEngine.generate`.

## BIRD Dev Schema-Tool Pass@K: Gemma 4 31B, Async vLLM, Temperature 0.8

Result folder:

```text
outputs/bird_dev_schema_tool_passk16_vllm_async_temp08_limit1534-0514
```

This run evaluated pass@k on the full BIRD dev set by sampling 16 independent tool-calling completions per example, executing each predicted SQL against the dev databases, and comparing execution results with the gold SQL.

### Run Configuration

| setting | value |
| --- | --- |
| model | `google/gemma-4-31B-it` |
| input file | `outputs/dev-20251106-schema-tool.jsonl` |
| database dir | `databases/dev_databases` |
| difficulty file | `data/bird_dev_data/raw/dev_20251106.json` |
| examples | `1534` |
| generations per example | `16` |
| total candidates | `24544` |
| temperature | `0.8` |
| top_p | `1.0` |
| max_new_tokens | `8000` |
| max_tool_rounds | `8` |
| vLLM tensor parallel size | `8` |
| vLLM async concurrency | `16` |

### Output Artifacts

| file | description |
| --- | --- |
| `passk_candidates_raw.jsonl` | raw generated candidates before SQL execution scoring |
| `passk_candidates.jsonl` | generated candidates with execution status, gold SQL, and correctness |
| `passk_per_example.jsonl` | per-question aggregate over the 16 candidates |
| `passk_summary.json` | machine-readable pass@k summary |
| `passk_summary.md` | human-readable pass@k summary |
| `passk_diagnostics.json` | detailed diagnostics over candidates, tool calls, tokens, and DBs |
| `passk_diagnostics.md` | compact diagnostics report |
| `all_wrong_analysis.jsonl` | per-example analysis for examples with zero correct candidates among 16 |
| `all_wrong_summary.md` | summary of the all-wrong examples |
| `idx*_candidates.jsonl` | extracted candidate subsets for selected failure-example IDs |

### Summary Metrics

| metric | value |
| --- | ---: |
| candidate accuracy | `69.76%` |
| correct candidates | `17121 / 24544` |
| estimated pass@1 | `69.76%` |
| prefix pass@1 | `70.21%` |
| estimated pass@16 | `75.68%` |
| prefix pass@16 | `75.68%` |
| examples with any correct candidate | `1161 / 1534` |
| examples with zero correct candidates | `373 / 1534` |
| examples with all 16 candidates correct | `919 / 1534` |
| predicted SQL executed | `24335 / 24544` |
| predicted SQL execution rate | `99.15%` |
| gold SQL executed | `24496 / 24544` |
| gold SQL execution rate | `99.80%` |
| total tool calls | `34663` |
| average tool calls per candidate | `1.41` |
| average tool rounds per candidate | `1.23` |

### Pass@K Table

| k | estimated pass@k | prefix pass@k |
| ---: | ---: | ---: |
| 1 | 69.76 | 70.21 |
| 2 | 72.07 | 72.43 |
| 3 | 73.00 | 73.27 |
| 4 | 73.55 | 73.60 |
| 5 | 73.93 | 73.73 |
| 6 | 74.23 | 74.12 |
| 7 | 74.47 | 74.38 |
| 8 | 74.67 | 74.51 |
| 9 | 74.84 | 74.64 |
| 10 | 75.00 | 74.84 |
| 11 | 75.14 | 74.97 |
| 12 | 75.27 | 75.16 |
| 13 | 75.38 | 75.36 |
| 14 | 75.49 | 75.49 |
| 15 | 75.59 | 75.62 |
| 16 | 75.68 | 75.68 |

### Candidate Execution And Stop Reasons

| item | count |
| --- | ---: |
| pred executed | `24335` |
| pred failed | `209` |
| gold executed | `24496` |
| gold failed | `48` |
| generation errors | `1` |
| stop: finished | `24303` |
| stop: max_tool_rounds | `213` |
| stop: max_new_tokens | `27` |
| stop: generation_error | `1` |

### Tool Usage

| metric | value |
| --- | ---: |
| total tool calls | `34663` |
| avg tool calls per candidate | `1.41` |
| total tool rounds | `30090` |
| avg tool rounds per candidate | `1.23` |
| per-example tool-call min | `16` |
| per-example tool-call p50 | `16` |
| per-example tool-call p90 | `34` |
| per-example tool-call p95 | `54` |
| per-example tool-call p99 | `113` |
| per-example tool-call max | `263` |

Most common tool orders:

| tool order | count |
| --- | ---: |
| `sqlite_query` | `21307` |
| `sqlite_query -> sqlite_query` | `1373` |
| `sqlite_query -> sqlite_query -> sqlite_query` | `269` |
| `sqlite_query -> bm25_search_sqlite -> sqlite_query` | `213` |
| `sqlite_query -> sqlite_query -> sqlite_query -> sqlite_query` | `140` |
| `sqlite_query -> bm25_search_sqlite -> sqlite_query -> sqlite_query` | `76` |
| `sqlite_query -> sqlite_peek -> sqlite_query` | `65` |
| `bm25_search_sqlite -> sqlite_query` | `59` |

### Token Statistics

| metric | prompt tokens | completion tokens |
| --- | ---: | ---: |
| min | `5878` | `0` |
| p50 | `13707` | `492` |
| p90 | `21067` | `1215` |
| p95 | `28920` | `1846` |
| p99 | `29172` | `3248` |
| max | `29464` | `8000` |
| mean | `14410.84` | `659.16` |

### Correct Candidates Per Example

| correct candidates among 16 | examples |
| ---: | ---: |
| 0 | `373` |
| 1 | `23` |
| 2 | `12` |
| 3 | `8` |
| 4 | `10` |
| 5 | `6` |
| 6 | `7` |
| 7 | `7` |
| 8 | `8` |
| 9 | `10` |
| 10 | `14` |
| 11 | `14` |
| 12 | `17` |
| 13 | `17` |
| 14 | `23` |
| 15 | `66` |
| 16 | `919` |

### DB-Level Diagnostics

| db_id | examples | candidate accuracy | pass@16 | pred execution rate | avg tool calls/candidate |
| --- | ---: | ---: | ---: | ---: | ---: |
| `card_games` | 191 | 68.52 | 75.39 | 98.85 | 1.63 |
| `codebase_community` | 186 | 78.66 | 86.56 | 98.89 | 1.56 |
| `formula_1` | 174 | 70.01 | 75.29 | 99.03 | 1.38 |
| `thrombosis_prediction` | 163 | 67.98 | 75.46 | 99.04 | 1.40 |
| `student_club` | 158 | 83.39 | 87.97 | 99.53 | 1.40 |
| `toxicology` | 145 | 64.96 | 70.34 | 99.40 | 1.20 |
| `european_football_2` | 129 | 75.00 | 82.17 | 99.61 | 1.16 |
| `superhero` | 129 | 89.63 | 92.25 | 99.85 | 1.37 |
| `financial` | 106 | 31.25 | 35.85 | 99.35 | 1.33 |
| `california_schools` | 89 | 45.58 | 51.69 | 98.46 | 1.78 |
| `debit_card_specializing` | 64 | 75.39 | 81.25 | 98.14 | 1.20 |

Lowest-performing DBs by pass@16 were `financial` at `35.85%` and `california_schools` at `51.69%`. Highest-performing DBs were `superhero` at `92.25%`, `student_club` at `87.97%`, and `codebase_community` at `86.56%`.

### Prediction Error Themes

Top predicted-SQL execution errors:

| error | count |
| --- | ---: |
| `near "I": syntax error` | `105` |
| `near ";": syntax error` | `16` |
| `interrupted` | `13` |
| `near "call": syntax error` | `9` |
| `no such column: T1.UserId` | `9` |
| `ORDER BY clause should come after UNION ALL not before` | `9` |
| `You can only execute one statement at a time.` | `7` |
| `near "in": syntax error` | `6` |
| `near "convertedManaCost": syntax error` | `6` |
| `no such column: lt` | `4` |

### All-Wrong Analysis

`all_wrong_summary.md` analyzes examples where none of the 16 sampled candidates were correct.

| label | count |
| --- | ---: |
| all-wrong examples | `373` |
| all_pred_sql_executed_but_wrong | `348` |
| low_diversity_repeated_wrong_sql | `133` |
| high_diversity_no_correct_sql | `120` |
| some_pred_sql_execution_failed | `25` |
| sql_syntax_or_transcript_extraction_error | `16` |
| hit_max_tool_rounds | `12` |
| hit_max_new_tokens | `4` |
| gold_sql_execution_failed | `3` |
| schema_column_error | `2` |
| generation_error | `1` |

All-wrong examples by DB:

| db_id | all-wrong examples |
| --- | ---: |
| `financial` | `68` |
| `card_games` | `47` |
| `california_schools` | `43` |
| `formula_1` | `43` |
| `toxicology` | `43` |
| `thrombosis_prediction` | `40` |
| `codebase_community` | `25` |
| `european_football_2` | `23` |
| `student_club` | `19` |
| `debit_card_specializing` | `12` |
| `superhero` | `10` |

The all-wrong analysis also wrote a filtered source file reference:

```text
outputs/dev-20251106-schema-373.jsonl
```

### Timing

| phase | seconds | approximate |
| --- | ---: | ---: |
| generation | `25421.76` | `7.06 h` |
| evaluation | `508.17` | `8.47 min` |
| total | `25932.12` | `7.20 h` |

### Notes

- `candidate_accuracy` treats every sampled candidate independently.
- `estimated pass@k` uses the standard combinatorial pass@k estimate from the 16 sampled candidates for each example.
- `prefix pass@k` checks whether at least one of the first `k` candidates by sample id was correct.
- At `k=16`, estimated and prefix pass@k match because both use all 16 candidates.
- This run used the full `schema-tool` dev file, not the `schema-bare-tool` file. The prompt-token distribution confirms much larger prompts: p50 prompt length was `13707` tokens and p95 was `28920` tokens.
- The gap between candidate accuracy (`69.76%`) and pass@16 (`75.68%`) shows about `5.93` points of recoverable headroom if a reranker or verifier can select the correct candidate from the sampled set.

## GRPO E4B Bare-Tool Checkpoint Sweep: Checkpoints 0-150

This sweep evaluates one async vLLM tool-calling generation per example over all 1534 old-dev samples for checkpoints `0, 10, ..., 150` from the GRPO E4B bare-tool training run.

Result root:

```text
outputs/training/train-6601-schema-bare-tool/gemma-4-E4B-it/grpo_deepspeed_p15500_c8000_g16_t1p2_bs4_ga8_lr2e-6_e4b_bare_lr2e6_20260524_130108
```

Each checkpoint folder contains `eval_summary.json`, `eval_summary.md`, `run_report.md`, `per_example_report.csv`, `eval_results.jsonl`, `prediction_details.jsonl`, and `predict_dev.json`.

### Run Configuration

| setting | value |
| --- | --- |
| base checkpoint-0 model | `google/gemma-4-E4B-it` |
| input file | `outputs/old-dev-schema-tool.jsonl` |
| examples | `1534` |
| inference backend | `vllm_async` |
| max prompt length | `35000` |
| max new tokens | `8000` |
| max tool rounds | `8` |
| eval workers | `16` |
| vLLM tensor parallel size | `1` |
| vLLM data parallel size | `1` |
| vLLM async concurrency | `16` |
| vLLM max model length | `48000` |

### Checkpoint Summary

| ckpt | correct | EX acc | finished | max rounds | tool calls | `sqlite_query` | `sqlite_peek` | `bm25_search_sqlite` | avg calls | avg toks | pred missing | pred failed | both exec | total sec |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `0` | `1003` | `65.38%` | `1526` | `8` | `2005` | `1899` | `65` | `41` | `1.307` | `710.0` | `22` | `25` | `1508` | `2644.8` |
| `10` | `996` | `64.93%` | `1528` | `6` | `2024` | `1918` | `58` | `48` | `1.319` | `732.8` | `18` | `22` | `1511` | `2117.6` |
| `20` | `985` | `64.21%` | `1522` | `12` | `2046` | `1920` | `78` | `48` | `1.334` | `735.1` | `26` | `31` | `1502` | `2047.6` |
| `30` | `995` | `64.86%` | `1526` | `7` | `2024` | `1939` | `56` | `29` | `1.319` | `732.2` | `22` | `27` | `1506` | `2137.4` |
| `40` | `1003` | `65.38%` | `1529` | `5` | `1991` | `1906` | `54` | `31` | `1.298` | `722.6` | `22` | `25` | `1508` | `2095.6` |
| `50` | `996` | `64.93%` | `1527` | `6` | `1995` | `1914` | `54` | `27` | `1.301` | `730.5` | `25` | `33` | `1500` | `2039.0` |
| `60` | `989` | `64.47%` | `1527` | `7` | `1995` | `1906` | `63` | `26` | `1.301` | `730.0` | `21` | `28` | `1505` | `2045.8` |
| `70` | `992` | `64.67%` | `1528` | `6` | `1979` | `1898` | `52` | `29` | `1.290` | `728.7` | `25` | `30` | `1503` | `2125.2` |
| `80` | `998` | `65.06%` | `1527` | `7` | `2039` | `1943` | `63` | `33` | `1.329` | `751.6` | `23` | `28` | `1505` | `2085.2` |
| `90` | `1007` | `65.65%` | `1531` | `3` | `1966` | `1893` | `56` | `17` | `1.282` | `741.8` | `19` | `24` | `1509` | `2061.7` |
| `100` | `1000` | `65.19%` | `1527` | `6` | `2013` | `1913` | `68` | `32` | `1.312` | `753.0` | `18` | `28` | `1505` | `2097.1` |
| `110` | `999` | `65.12%` | `1531` | `3` | `1958` | `1881` | `51` | `26` | `1.276` | `744.1` | `24` | `33` | `1500` | `2074.9` |
| `120` | `988` | `64.41%` | `1531` | `3` | `2005` | `1917` | `63` | `25` | `1.307` | `762.1` | `15` | `23` | `1510` | `2134.5` |
| `130` | `998` | `65.06%` | `1529` | `5` | `1989` | `1899` | `60` | `30` | `1.297` | `747.9` | `20` | `27` | `1506` | `2122.8` |
| `140` | `989` | `64.47%` | `1526` | `7` | `2019` | `1935` | `59` | `25` | `1.316` | `768.0` | `23` | `31` | `1502` | `2136.8` |
| `150` | `992` | `64.67%` | `1526` | `8` | `2004` | `1936` | `48` | `20` | `1.306` | `762.0` | `18` | `24` | `1509` | `2125.8` |

### Run Health

- No checkpoint run appears to have failed globally: every checkpoint generated all `1534` examples and had `0` filtered examples.
- Generation stop reasons were only `finished` and `max_tool_rounds`; no `max_new_tokens` or other stop reason appeared in these checkpoint summaries.
- `checkpoint-90` had the best overall EX accuracy at `65.65%` (`1007 / 1534`) and only `3` max-tool-round stops.
- `checkpoint-20` was the weakest checkpoint by accuracy at `64.21%` (`985 / 1534`), with the most tool calls (`2046`), most max-tool-round stops (`12`), and high predicted-SQL failure count (`31`).
- `checkpoint-120` had the best SQL extraction/execution health by missing predicted SQL (`15`) and both-SQL-executed count (`1510`), but its EX accuracy was only `64.41%`.
- `checkpoint-140` was the most verbose by average completion tokens (`768.0`) without an accuracy gain.
- `checkpoint-150` finished below checkpoint 0 overall: `64.67%` vs `65.38%`, despite higher average completion tokens (`762.0` vs `710.0`).

### Error Themes

The non-OK per-example statuses are dominated by predicted-SQL issues rather than generation-level run failures:

- `pred_error: empty sql` was the most common error at every checkpoint, ranging from `15` at checkpoint 120 to `26` at checkpoint 20.
- Other recurring predicted-SQL failures included missing columns or tables, syntax errors, and a few interrupted predicted-SQL executions.
- A recurring `gold_error: interrupted` appears once in every checkpoint run.

### Recommendation

Use `checkpoint-90` as the preferred checkpoint from this sweep. It has the best overall EX accuracy, strong run health, low max-tool-round count, and relatively low tool-call volume. The final checkpoint, `checkpoint-150`, is not better than checkpoint 0 or checkpoint 90 on overall EX accuracy.

## AER Hard-Prompt Entropy Run - 2026-05-28

Current E4B bare-tool GRPO/DAPO run with Adaptive Entropy Regularization (AER) enabled. This experiment follows the AER idea from [Revisiting Entropy Regularization: Adaptive Coefficient Unlocks Its Potential for LLM Reinforcement Learning](https://arxiv.org/abs/2510.10959): allocate stronger entropy pressure to harder prompt groups, anchor target entropy to the initial entropy, and update a global entropy coefficient dynamically.

| setting | value |
| --- | --- |
| training run | `outputs/training/train-6601-schema-bare-tool/gemma-4-E4B-it/aer_grpo_deepspeed_p15500_c8000_g16_t1p2_bs4_ga8_lr1e-6_20260527_234257` |
| wandb run | `https://wandb.ai/kpratik41/gemma4-31b-bird-gspo/runs/owdhmcij` |
| train log | `logs/train_20260527_234257.log` |
| train file | `outputs/train-6601-schema-bare-tool.jsonl` |
| eval mode | reward-only eval, `prompt_groups=6`, `generations=96` |
| model | `google/gemma-4-E4B-it` |
| loss / reward scaling | `loss_type=dapo`, `scale_rewards=batch`, `beta=0` |
| DAPO dynamic sampling | enabled, `dynamic_sampling_reward_name=result_reward`, `dapo_oversample_factor=4`, `dapo_max_rounds=1`, `num_generations=16` |
| AER settings | `rho=0.25`, `tau=0.7`, `eta=0.001`, `alpha_init=0.005`, `alpha_max=0.1`, `reward=result_reward` |
| AER implementation | sequence-level entropy bonus on hard groups; coefficient is `alpha * max(rho - group_accuracy, 0) / rho` |
| target entropy | `initial_entropy=0.362`, `target_entropy=0.2534` |
| checkpoint rows | `0`, `10`, ..., `100`; rows after `0` use the completed metric row at that global step |

AER adds a negative sequence-entropy term for hard prompt groups, so minimizing the loss encourages less overconfident next-token distributions on those groups. In this run, measured entropy stayed above the anchored target, so the controller decayed `alpha` to `0` by checkpoint `10`. Entropy-only padding groups were nonzero only at early train steps `1-3` with a total of `4` groups, so most of this run is effectively DAPO with the new mask plumbing rather than active entropy pressure.

### Figures

| plot | file |
| --- | --- |
| accuracy, SC, and entropy | `figures/aer/checkpoint_accuracy_entropy_sc.svg` |
| sampling lift | `figures/aer/sampling_lift.svg` |
| tool calls and failed predictions | `figures/aer/tool_calls_and_failures.svg` |
| best checkpoint summary | `figures/aer/best_checkpoint_summary.svg` |

### Pass@K And Self-Consistency Results

Pass@k and self-consistency columns are filled where sampled checkpoint evaluation artifacts exist. Checkpoints `10`, `30`, `50`, `70`, and `90` currently have temp-0 artifacts but no pass@k artifacts in this run folder. Training entropy and grad norm come from the live training log; checkpoint `100` uses the metric row emitted when the run reached `100/550`.

| checkpoint | pass@1 | pass@2 | pass@4 | pass@8 | pass@16 | SC option 1 | SC option 2 | temp0 acc | temp0 avg calls | pass@k avg calls/gen | correct candidates | candidate acc | train entropy | grad norm |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `63.64%` | `69.71%` | `73.79%` | `77.05%` | `79.79%` | `67.99%` | `68.06%` | `65.12%` | `1.306` | `1.303` | `15619 / 24544` | `63.64%` | `0.3661` | `0.04755` |
| 10 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `64.41%` | `1.311` | `n/a` | `n/a` | `n/a` | `0.3692` | `0.03323` |
| 20 | `63.15%` | `69.75%` | `74.18%` | `77.58%` | `80.18%` | `67.99%` | `68.19%` | `65.71%` | `1.332` | `1.344` | `15500 / 24544` | `63.15%` | `0.3659` | `0.001106` |
| 30 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `65.12%` | `1.332` | `n/a` | `n/a` | `n/a` | `0.4527` | `0.002961` |
| 40 | `63.32%` | `69.72%` | `73.78%` | `76.76%` | `79.07%` | `68.25%` | `68.38%` | `66.23%` | `1.317` | `1.371` | `15541 / 24544` | `63.32%` | `0.3889` | `0.003334` |
| 50 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `66.36%` | `1.303` | `n/a` | `n/a` | `n/a` | `0.4218` | `0.005332` |
| 60 | `63.22%` | `69.64%` | `73.79%` | `76.95%` | `79.40%` | `68.06%` | `68.38%` | `65.06%` | `1.329` | `1.392` | `15517 / 24544` | `63.22%` | `0.4064` | `0.003557` |
| 70 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `66.30%` | `1.336` | `n/a` | `n/a` | `n/a` | `0.4022` | `0.001301` |
| 80 | `63.62%` | `69.86%` | `73.92%` | `76.91%` | `79.20%` | `68.25%` | `68.25%` | `65.84%` | `1.316` | `1.370` | `15615 / 24544` | `63.62%` | `0.388` | `0.01097` |
| 90 | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `n/a` | `66.23%` | `1.323` | `n/a` | `n/a` | `n/a` | `0.4538` | `0.007232` |
| 100 | `63.97%` | `70.19%` | `74.23%` | `77.39%` | `80.12%` | `69.17%` | `69.10%` | `67.01%` | `1.329` | `1.355` | `15701 / 24544` | `63.97%` | `0.5388` | `0.00192` |

### Training Reward Metrics

Training reward means come from the completed metric rows in the same log. `aer alpha`, `aer loss`, and `entropy-only groups` are included to show whether AER was actively applying entropy pressure at each checkpoint row.

| checkpoint | temp0 acc | pred failed | learning rate | format reward | execution reward | result reward | table link reward | column link reward | nonnull reward | train reward | aer alpha | aer loss | entropy-only groups |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | `65.12%` | `26` | `0` | `0.9883` | `0.9609` | `0.7305` | `0.7318` | `0.8509` | `0.9466` | `5.209` | `0.004` | `0` | `0` |
| 10 | `64.41%` | `23` | `8.127e-07` | `0.9909` | `0.9805` | `0.6875` | `0.7695` | `0.8154` | `0.9661` | `5.21` | `0` | `0` | `0` |
| 20 | `65.71%` | `29` | `9.962e-07` | `0.9805` | `0.9674` | `0.6641` | `0.7526` | `0.7772` | `0.9648` | `5.106` | `0` | `0` | `0` |
| 30 | `65.12%` | `28` | `9.775e-07` | `0.9922` | `0.9714` | `0.7057` | `0.8112` | `0.8775` | `0.9492` | `5.307` | `0` | `0` | `0` |
| 40 | `66.23%` | `36` | `9.587e-07` | `0.987` | `0.9635` | `0.7669` | `0.7773` | `0.8583` | `0.9544` | `5.308` | `0` | `0` | `0` |
| 50 | `66.36%` | `29` | `9.4e-07` | `0.9935` | `0.9857` | `0.6901` | `0.8906` | `0.8316` | `0.9831` | `5.375` | `0` | `0` | `0` |
| 60 | `65.06%` | `32` | `9.212e-07` | `0.9922` | `0.9779` | `0.6367` | `0.7005` | `0.7508` | `0.9674` | `5.026` | `0` | `0` | `0` |
| 70 | `66.30%` | `30` | `9.024e-07` | `0.9857` | `0.9857` | `0.75` | `0.8802` | `0.8173` | `0.9818` | `5.401` | `0` | `0` | `0` |
| 80 | `65.84%` | `29` | `8.837e-07` | `0.9935` | `0.987` | `0.7591` | `0.8633` | `0.849` | `0.9831` | `5.435` | `0` | `0` | `0` |
| 90 | `66.23%` | `35` | `8.649e-07` | `0.9974` | `0.9974` | `0.7682` | `0.793` | `0.8376` | `0.9896` | `5.383` | `0` | `0` | `0` |
| 100 | `67.01%` | `38` | `8.462e-07` | `0.9896` | `0.9648` | `0.6576` | `0.8945` | `0.8483` | `0.9375` | `5.292` | `0` | `0` | `0` |

# BIRD Dev 4B pass@8 Results

All runs below use `google/gemma-4-E4B-it` with async vLLM, tensor parallel size `1`, `8` process shards, tool-calling prompts, column meanings, and schema statistics. Self-consistency (SC) uses only the pass@k candidates and does not include temperature-0 inference.

## Summary

| Run | Temp | Few-shot examples | Async concurrency | pass@1 | pass@8 | SC EX |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| No few-shot | 0.8 | 0 | 16 | 64.20% | 74.25% | 67.41% |
| 3-shot | 0.8 | 3 | 16 | 65.88% | 76.79% | 68.19% |
| 5-shot | 0.8 | 5 | 16 | 65.69% | 77.57% | 68.32% |
| 5-shot | 1.2 | 5 | 8 | 64.47% | 77.71% | 69.10% |

Best SC result so far:

```text
5-shot, temp 1.2: 69.10% EX (1060/1534)
```

## Interpretation

The `temp=1.2` 5-shot run reduced single-sample accuracy but improved the final SC result. Compared with the `temp=0.8` 5-shot run:

```text
pass@1: 65.69% -> 64.47%  (-1.21)
pass@8: 77.57% -> 77.71%  (+0.13)
SC EX:  68.32% -> 69.10%  (+0.78, 1048/1534 -> 1060/1534)
```

This suggests the higher temperature produced noisier individual samples but enough useful diversity for result-set majority voting to improve.

One caveat: the `temp=1.2` run had more failed candidate executions:

```text
temp 0.8, 5-shot: 329 failed candidate executions
temp 1.2, 5-shot: 575 failed candidate executions
```

Also note that the older `temp=0.8` comparison runs used async concurrency `16`, while the `temp=1.2` run used the newer default async concurrency `8`.

## Run Paths

| Run | Path |
| --- | --- |
| No few-shot, temp 0.8 | `outputs/passk/bird_dev-schema-tool-nofewshot/gemma-4-E4B-it/pass8_async_tp1_shards8_20260607_214813` |
| 3-shot, temp 0.8 | `outputs/passk/bird_dev-schema-tool-fewshot3/gemma-4-E4B-it/pass8_async_tp1_shards8_20260607_222550` |
| 5-shot, temp 0.8 | `outputs/passk/bird_dev-schema-tool-fewshot/gemma-4-E4B-it/pass8_async_tp1_shards8_20260607_201748` |
| 5-shot, temp 1.2 | `outputs/passk/bird_dev-schema-tool-fewshot5/gemma-4-E4B-it/pass8_async_tp1_shards8_temp1p2_20260608_034643` |

## Detailed Metrics

| Run | Candidate accuracy | Failed candidate executions | Valid SC vote examples | No-vote examples | Stop reasons |
| --- | ---: | ---: | ---: | ---: | --- |
| No few-shot, temp 0.8 | 64.20% | 347 | 1531 | 3 | `finished=12232`, `max_tool_rounds=38`, `context_length_exceeded=2` |
| 3-shot, temp 0.8 | 65.88% | 320 | 1531 | 3 | `finished=12239`, `max_tool_rounds=28`, `context_length_exceeded=4`, `max_new_tokens=1` |
| 5-shot, temp 0.8 | 65.69% | 329 | 1530 | 4 | `finished=12235`, `max_tool_rounds=35`, `context_length_exceeded=1`, `max_new_tokens=1` |
| 5-shot, temp 1.2 | 64.47% | 575 | 1530 | 4 | `finished=12253`, `max_tool_rounds=11`, `context_length_exceeded=8` |


# Training-Data Pass@16: Base Gemma 4 31B, Async vLLM, Temperature 1.2

Pass@16 over the **full BIRD training file** using the untrained base model
`google/gemma-4-31B-it`. The purpose is to measure how many training prompts are
intrinsically *heterogeneous* under 16 samples — i.e. how much learning signal
the training set can offer DAPO dynamic sampling before any RL has been applied.

Because `outputs/` is gitignored, the full distribution is reproduced inline
below so it survives independently of the artifact tree.

## Run Configuration

| setting | value |
| --- | --- |
| model | `google/gemma-4-31B-it` (base, resolved from the local HF cache) |
| input file | `outputs/train-6601-schema-bare-tool.jsonl` |
| database dir | `databases/train_databases` (69 DBs) |
| difficulty file | none applicable; BIRD train has no difficulty labels, all rows report `unknown` |
| examples | `6601` |
| generations per example | `16` |
| total candidates | `105616` |
| inference backend | `vllm_async` |
| temperature / top_p | `1.2` / `1.0` |
| max_prompt_length / max_new_tokens | `30000` / `8000` |
| max_tool_rounds | `8` |
| vLLM tensor parallel size | `1` |
| shards | `8` (one per GPU, `0`..`7`) |
| vLLM max model length | `43000` |
| vLLM async concurrency | `16` per shard (128 in flight across the node) |
| launcher | `scripts/run_passk16_train6601.sh` (detached in screen `passk16base`) |
| output root | `outputs/passk/train6601_bare_tool_gemma4-31b-it_temp1p2_tp1_shards8` |
| prompts filtered as over-length | `0` |

Wall clock `2026-07-31T23:58:49Z -> 2026-08-01T04:55:13Z` = **4 h 56 min**. The
`timing_seconds` field in `passk_summary.json` reports `generation=129155 s`,
which is the **sum across the eight concurrent shards**, not wall clock.

Throughput note: this `tp=1 x 8 shards` layout sustained about `6.4` candidates/s.
An earlier `tp=2 x 4 shards` layout on the same input sustained about `9.0`
candidates/s, so tensor-parallel-2 with fewer shards is the better throughput
configuration for this workload despite having half the in-flight requests.

## Summary Metrics

| metric | value |
| --- | ---: |
| candidate accuracy / pass@1 | `76.78%` |
| correct candidates | `81095 / 105616` |
| estimated pass@2 | `78.39%` |
| estimated pass@4 | `79.61%` |
| estimated pass@8 | `80.58%` |
| estimated pass@16 | `81.32%` |
| examples with at least one correct candidate | `5368 / 6601` |
| examples with zero correct candidates | `1233 / 6601` |
| gold SQL executed | `105584 / 105616` (`99.97%`) |

With `n = k = 16`, `pass@16` is by construction the fraction of examples with at
least one correct candidate, so `5368 / 6601 = 81.32%`. Sampling lift from
`pass@1` to `pass@16` is `+4.54 pp`.

## Correct-Candidate Distribution

| correct out of 16 | examples | share | cumulative |
| ---: | ---: | ---: | ---: |
| 0 | `1233` | `18.68%` | `18.68%` |
| 1 | `65` | `0.98%` | `19.66%` |
| 2 | `48` | `0.73%` | `20.39%` |
| 3 | `38` | `0.58%` | `20.97%` |
| 4 | `26` | `0.39%` | `21.36%` |
| 5 | `45` | `0.68%` | `22.04%` |
| 6 | `33` | `0.50%` | `22.54%` |
| 7 | `24` | `0.36%` | `22.91%` |
| 8 | `22` | `0.33%` | `23.24%` |
| 9 | `37` | `0.56%` | `23.80%` |
| 10 | `31` | `0.47%` | `24.27%` |
| 11 | `27` | `0.41%` | `24.68%` |
| 12 | `36` | `0.55%` | `25.22%` |
| 13 | `46` | `0.70%` | `25.92%` |
| 14 | `50` | `0.76%` | `26.68%` |
| 15 | `161` | `2.44%` | `29.12%` |
| 16 | `4679` | `70.88%` | `100.00%` |

### DAPO Buckets

| bucket | examples | share |
| --- | ---: | ---: |
| all-wrong (`0/16`) | `1233` | `18.68%` |
| heterogeneous (`1-15/16`) | `689` | `10.44%` |
| all-correct (`16/16`) | `4679` | `70.88%` |

The distribution is strongly **U-shaped**: `89.6%` of training prompts sit at one
of the two extremes and yield zero intra-group reward variance. Only `10.44%` of
prompts produce a group that DAPO dynamic sampling would keep, so even for the
untrained base policy roughly **1 in 10 sampled groups carries a gradient**.
Within the heterogeneous band the mass is skewed toward the top (`15/16` alone is
`161` examples), so evenly-split groups are rarer still.

This is an upper bound on the learning signal available from this training file
at `num_generations=16`: it is a property of the data and the base policy, before
any entropy loss from RL. It explains why `--dapo_oversample_factor` has to be
large to fill even a handful of group slots per optimizer step.

### Sampling Diversity

| metric | value |
| --- | ---: |
| mean distinct SQL strings per 16 candidates | `3.47` |
| examples where all 16 candidates are byte-identical | `1632` (`24.72%`) |

`3.47` distinct SQL per 16 samples is consistent with the `3.37` measured for
base `gemma-4-31B-it` on the old-dev tool split (see "Old Dev Tool Pass@K Full
Runs"), so base-model sampling diversity is stable across the train and dev
splits.

### Databases With The Most Heterogeneity

| db_id | examples | heterogeneous | rate |
| --- | ---: | ---: | ---: |
| `music_tracker` | `31` | `15` | `48.4%` |
| `citeseer` | `14` | `4` | `28.6%` |
| `superstore` | `82` | `21` | `25.6%` |
| `legislator` | `128` | `29` | `22.7%` |
| `sales` | `77` | `16` | `20.8%` |

## Output Artifacts

Under `outputs/passk/train6601_bare_tool_gemma4-31b-it_temp1p2_tp1_shards8`:

| file | description |
| --- | --- |
| `passk16_distribution.json` | run config, pass@k, full 0-16 distribution, DAPO buckets, diversity |
| `passk16_distribution.csv` | 0-16 distribution with counts, share, cumulative share |
| `passk16_distribution_by_db.csv` | per-database all-wrong / heterogeneous / all-correct counts |
| `merged/passk_summary.json` / `.md` | merged pass@k summary across the eight shards |
| `merged/passk_per_example.jsonl` | per-example `num_correct`, `pass_at_k`, `first_correct_sample_id` |
| `merged/passk_candidates.jsonl` | all 105616 candidates with execution status and correctness |
| `shard-0000N-of-00008/` | per-shard artifacts before merge |
| `shard0.log` .. `shard7.log`, `run_passk16.log` | run logs |

Reproduce with:

```bash
bash scripts/run_passk16_train6601.sh
```
