# BIRD Dev Execution Accuracy Summary

## Run Configuration

- inference_backend: `vllm`
- model_name_or_path: `google/gemma-4-31b-it`
- input_file: `outputs/old-dev-schema-unpatched.jsonl`
- database_dir: `databases/dev_databases`
- diff_json_path: `data/bird_dev_data/raw/dev_20251106.json`
- num_examples: `-1`
- loaded_rows: `1534`
- max_prompt_length: `34000`
- max_new_tokens: `8000`
- max_tool_rounds: `8`
- eval_timeout: `60.0`
- eval_workers: `16`
- vllm_tensor_parallel_size: `2`
- vllm_data_parallel_size: `1`
- vllm_async_concurrency: `8`
- vllm_gpu_memory_utilization: `0.9`
- vllm_max_model_len: `43500`

## Timing

- generation_seconds: `10820.41`
- evaluation_seconds: `132.03`
- total_seconds: `10952.79`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 596 | 860 | 69.30 |
| moderate | 300 | 443 | 67.72 |
| challenging | 173 | 231 | 74.89 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 116 | 191 | 60.73 |
| codebase_community | 132 | 186 | 70.97 |
| formula_1 | 110 | 174 | 63.22 |
| thrombosis_prediction | 92 | 163 | 56.44 |
| student_club | 134 | 158 | 84.81 |
| toxicology | 99 | 145 | 68.28 |
| european_football_2 | 93 | 129 | 72.09 |
| superhero | 115 | 129 | 89.15 |
| financial | 76 | 106 | 71.70 |
| california_schools | 60 | 89 | 67.42 |
| debit_card_specializing | 42 | 64 | 65.62 |

Overall EX Accuracy: 69.69% (1069/1534)

## Execution Stats

- pred_sql_extracted: 1534
- pred_sql_missing: 0
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1525
- pred_sql_execution_failed: 9
- gold_sql_executed: 1532
- gold_sql_execution_failed: 2
- both_sql_executed: 1523
