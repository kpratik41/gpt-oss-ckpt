# BIRD Dev Execution Accuracy Summary

## Run Configuration

- inference_backend: `vllm_async`
- model_name_or_path: `outputs/ckpt-70-20260507`
- input_file: `outputs/old-dev-schema-tool-unpatched.jsonl`
- database_dir: `/home/ubuntu/consensus/nl2sql-gspo-gemma4/databases/dev_databases`
- diff_json_path: `data/bird_dev_data/raw/dev_20251106.json`
- num_examples: `-1`
- loaded_rows: `1534`
- max_prompt_length: `34000`
- max_new_tokens: `8000`
- max_tool_rounds: `8`
- eval_timeout: `60.0`
- eval_workers: `16`
- vllm_tensor_parallel_size: `2`
- vllm_data_parallel_size: `1`
- vllm_async_concurrency: `8`
- vllm_gpu_memory_utilization: `0.9`
- vllm_max_model_len: `43500`

## Timing

- generation_seconds: `4911.22`
- evaluation_seconds: `79.67`
- total_seconds: `4992.50`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 607 | 860 | 70.58 |
| moderate | 315 | 443 | 71.11 |
| challenging | 178 | 231 | 77.06 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 124 | 191 | 64.92 |
| codebase_community | 136 | 186 | 73.12 |
| formula_1 | 115 | 174 | 66.09 |
| thrombosis_prediction | 97 | 163 | 59.51 |
| student_club | 133 | 158 | 84.18 |
| toxicology | 99 | 145 | 68.28 |
| european_football_2 | 93 | 129 | 72.09 |
| superhero | 115 | 129 | 89.15 |
| financial | 78 | 106 | 73.58 |
| california_schools | 63 | 89 | 70.79 |
| debit_card_specializing | 47 | 64 | 73.44 |

Overall EX Accuracy: 71.71% (1100/1534)

## Execution Stats

- pred_sql_extracted: 1534
- pred_sql_missing: 0
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1520
- pred_sql_execution_failed: 14
- gold_sql_executed: 1533
- gold_sql_execution_failed: 1
- both_sql_executed: 1519
