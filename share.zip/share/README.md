# BIRD EX Accuracy Share Bundle

This folder contains BIRD-format prediction files for all six inference runs, plus self-consistency outputs where available.

Use the `*_predict_dev.json` files for BIRD EX accuracy. Each file is a JSON object:

```text
question_idx -> SQL<TAB>----- bird -----<TAB>db_id
```

Direct inference runs:

- `01_gemma4_it_non_tool_predict_dev.json`
- `02_gemma4_it_tool_predict_dev.json`
- `03_ckpt70_non_tool_predict_dev.json`
- `04_ckpt70_tool_predict_dev.json`
- `05_ckpt90_non_tool_predict_dev.json`
- `06_ckpt90_tool_predict_dev.json`

Self-consistency prediction files, generated from selected final `pred_sql`:

- `07_ckpt90_tool_sc_passk16_majority_vote_predict_dev.json`
- `08_ckpt90_tool_sc_passk16_temp0_tiebreak_only_predict_dev.json`
- `09_ckpt90_tool_sc_passk16_temp0_always_17th_predict_dev.json`

For traceability, `*_prediction_details.jsonl`, `*_selected_results.jsonl`, and summary markdown files are included alongside the BIRD-ready prediction files.

See `manifest.json` for source paths, row counts, and SC selection-rule notes.
