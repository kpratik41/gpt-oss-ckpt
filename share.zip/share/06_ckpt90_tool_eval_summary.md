# BIRD Dev Execution Accuracy Summary

## Run Configuration

- inference_backend: `vllm`
- model_name_or_path: `outputs/0530_beta_schedule_gemma-4-31b-it/checkpoint-90`
- input_file: `outputs/old-dev-schema-tool-unpatched.jsonl`
- database_dir: `/home/ubuntu/consensus/nl2sql-gspo-gemma4/databases/dev_databases`
- diff_json_path: `data/bird_dev_data/raw/dev_20251106.json`
- num_examples: `-1`
- loaded_rows: `1534`
- max_prompt_length: `34000`
- max_new_tokens: `8000`
- max_tool_rounds: `8`
- eval_timeout: `60.0`
- eval_workers: `16`
- vllm_tensor_parallel_size: `2`
- vllm_data_parallel_size: `2`
- vllm_async_concurrency: `8`
- vllm_gpu_memory_utilization: `0.9`
- vllm_max_model_len: `43500`

## Timing

- generation_seconds: `5891.12`
- evaluation_seconds: `75.91`
- total_seconds: `5968.63`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 633 | 860 | 73.60 |
| moderate | 323 | 443 | 72.91 |
| challenging | 174 | 231 | 75.32 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 125 | 191 | 65.45 |
| codebase_community | 138 | 186 | 74.19 |
| formula_1 | 117 | 174 | 67.24 |
| thrombosis_prediction | 111 | 163 | 68.10 |
| student_club | 134 | 158 | 84.81 |
| toxicology | 104 | 145 | 71.72 |
| european_football_2 | 97 | 129 | 75.19 |
| superhero | 119 | 129 | 92.25 |
| financial | 81 | 106 | 76.42 |
| california_schools | 58 | 89 | 65.17 |
| debit_card_specializing | 46 | 64 | 71.88 |

Overall EX Accuracy: 73.66% (1130/1534)

## Execution Stats

- pred_sql_extracted: 1534
- pred_sql_missing: 0
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1520
- pred_sql_execution_failed: 14
- gold_sql_executed: 1532
- gold_sql_execution_failed: 2
- both_sql_executed: 1518
