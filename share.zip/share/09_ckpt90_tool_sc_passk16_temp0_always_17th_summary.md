# BIRD Self-Consistency Summary

## Source

- passk_dir: `outputs/0530_beta_schedule_gemma-4-31b-it/checkpoint-90/passk_old-dev-schema-tool-unpatched_temp1p2_k16_async_tp2_shards4_p34k_o8k_m43500`
- temp0_dir: `outputs/infer_20260603_2230_ckpt90_old-dev-schema-tool-unpatched_vllm_tp2_shards2_p34k_o8k_m43500_dbrestored`
- mode: `always_17th`
- selection_rule: `majority vote over 16 sampled candidates plus temp0 as a 17th vote when temp0 is executable non-empty`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 636 | 860 | 73.95 |
| moderate | 327 | 443 | 73.81 |
| challenging | 174 | 231 | 75.32 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 128 | 191 | 67.02 |
| codebase_community | 139 | 186 | 74.73 |
| formula_1 | 119 | 174 | 68.39 |
| thrombosis_prediction | 111 | 163 | 68.10 |
| student_club | 134 | 158 | 84.81 |
| toxicology | 105 | 145 | 72.41 |
| european_football_2 | 96 | 129 | 74.42 |
| superhero | 119 | 129 | 92.25 |
| financial | 81 | 106 | 76.42 |
| california_schools | 59 | 89 | 66.29 |
| debit_card_specializing | 46 | 64 | 71.88 |

Overall EX Accuracy: 74.12% (1137/1534)

## Execution Stats

- pred_sql_extracted: 1533
- pred_sql_missing: 1
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1532
- pred_sql_execution_failed: 2
- gold_sql_executed: 1533
- gold_sql_execution_failed: 1
- both_sql_executed: 1531

## Self-Consistency Stats

- examples_with_valid_vote: 1533
- examples_without_valid_vote: 1
- ignored_empty_results: 104
- selected_vote_count_total: 25287
- temp0_valid_nonempty: 1516
- temp0_used: 1499
- num_generations: 16
- source_temp0_dir: outputs/infer_20260603_2230_ckpt90_old-dev-schema-tool-unpatched_vllm_tp2_shards2_p34k_o8k_m43500_dbrestored
- source_passk_dir: outputs/0530_beta_schedule_gemma-4-31b-it/checkpoint-90/passk_old-dev-schema-tool-unpatched_temp1p2_k16_async_tp2_shards4_p34k_o8k_m43500
- mode: always_17th
- selection_rule: majority vote over 16 sampled candidates plus temp0 as a 17th vote when temp0 is executable non-empty
