# BIRD Dev Execution Accuracy Summary

## Run Configuration

- inference_backend: `vllm`
- model_name_or_path: `outputs/ckpt-70-20260507`
- input_file: `outputs/old-dev-schema-unpatched.jsonl`
- database_dir: `/home/ubuntu/consensus/nl2sql-gspo-gemma4/databases/dev_databases`
- diff_json_path: `data/bird_dev_data/raw/dev_20251106.json`
- num_examples: `-1`
- loaded_rows: `1534`
- max_prompt_length: `34000`
- max_new_tokens: `8000`
- max_tool_rounds: `8`
- eval_timeout: `60.0`
- eval_workers: `16`
- vllm_tensor_parallel_size: `2`
- vllm_data_parallel_size: `1`
- vllm_async_concurrency: `8`
- vllm_gpu_memory_utilization: `0.9`
- vllm_max_model_len: `43500`

## Timing

- generation_seconds: `7012.53`
- evaluation_seconds: `133.61`
- total_seconds: `7146.49`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 610 | 860 | 70.93 |
| moderate | 312 | 443 | 70.43 |
| challenging | 176 | 231 | 76.19 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 116 | 191 | 60.73 |
| codebase_community | 138 | 186 | 74.19 |
| formula_1 | 115 | 174 | 66.09 |
| thrombosis_prediction | 95 | 163 | 58.28 |
| student_club | 138 | 158 | 87.34 |
| toxicology | 100 | 145 | 68.97 |
| european_football_2 | 93 | 129 | 72.09 |
| superhero | 119 | 129 | 92.25 |
| financial | 79 | 106 | 74.53 |
| california_schools | 60 | 89 | 67.42 |
| debit_card_specializing | 45 | 64 | 70.31 |

Overall EX Accuracy: 71.58% (1098/1534)

## Execution Stats

- pred_sql_extracted: 1534
- pred_sql_missing: 0
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1532
- pred_sql_execution_failed: 2
- gold_sql_executed: 1531
- gold_sql_execution_failed: 3
- both_sql_executed: 1529
