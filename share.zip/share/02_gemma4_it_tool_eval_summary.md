# BIRD Dev Execution Accuracy Summary

## Run Configuration

- inference_backend: `vllm_async`
- model_name_or_path: `google/gemma-4-31b-it`
- input_file: `outputs/old-dev-schema-tool-unpatched.jsonl`
- database_dir: `databases/dev_databases`
- diff_json_path: `data/bird_dev_data/raw/dev_20251106.json`
- num_examples: `-1`
- loaded_rows: `1534`
- max_prompt_length: `34000`
- max_new_tokens: `8000`
- max_tool_rounds: `8`
- eval_timeout: `60.0`
- eval_workers: `16`
- vllm_tensor_parallel_size: `2`
- vllm_data_parallel_size: `1`
- vllm_async_concurrency: `8`
- vllm_gpu_memory_utilization: `0.9`
- vllm_max_model_len: `43500`

## Timing

- generation_seconds: `9164.19`
- evaluation_seconds: `134.46`
- total_seconds: `9300.26`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 590 | 860 | 68.60 |
| moderate | 297 | 443 | 67.04 |
| challenging | 175 | 231 | 75.76 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 115 | 191 | 60.21 |
| codebase_community | 129 | 186 | 69.35 |
| formula_1 | 108 | 174 | 62.07 |
| thrombosis_prediction | 95 | 163 | 58.28 |
| student_club | 132 | 158 | 83.54 |
| toxicology | 97 | 145 | 66.90 |
| european_football_2 | 94 | 129 | 72.87 |
| superhero | 110 | 129 | 85.27 |
| financial | 76 | 106 | 71.70 |
| california_schools | 60 | 89 | 67.42 |
| debit_card_specializing | 46 | 64 | 71.88 |

Overall EX Accuracy: 69.23% (1062/1534)

## Execution Stats

- pred_sql_extracted: 1534
- pred_sql_missing: 0
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1526
- pred_sql_execution_failed: 8
- gold_sql_executed: 1532
- gold_sql_execution_failed: 2
- both_sql_executed: 1524
