# BIRD Dev Execution Accuracy Summary

## Run Configuration

- inference_backend: `vllm`
- model_name_or_path: `outputs/0530_beta_schedule_gemma-4-31b-it/checkpoint-90`
- input_file: `outputs/old-dev-schema-unpatched.jsonl`
- database_dir: `/home/ubuntu/consensus/nl2sql-gspo-gemma4/databases/dev_databases`
- diff_json_path: `data/bird_dev_data/raw/dev_20251106.json`
- num_examples: `-1`
- loaded_rows: `1534`
- max_prompt_length: `34000`
- max_new_tokens: `8000`
- max_tool_rounds: `8`
- eval_timeout: `60.0`
- eval_workers: `16`
- vllm_tensor_parallel_size: `2`
- vllm_data_parallel_size: `2`
- vllm_async_concurrency: `8`
- vllm_gpu_memory_utilization: `0.9`
- vllm_max_model_len: `43500`

## Timing

- generation_seconds: `3489.04`
- evaluation_seconds: `131.53`
- total_seconds: `3620.92`

## By Difficulty

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| simple | 604 | 860 | 70.23 |
| moderate | 305 | 443 | 68.85 |
| challenging | 167 | 231 | 72.29 |

## By Database

| Group | Correct | Count | Accuracy |
| --- | ---: | ---: | ---: |
| card_games | 118 | 191 | 61.78 |
| codebase_community | 116 | 186 | 62.37 |
| formula_1 | 113 | 174 | 64.94 |
| thrombosis_prediction | 103 | 163 | 63.19 |
| student_club | 133 | 158 | 84.18 |
| toxicology | 99 | 145 | 68.28 |
| european_football_2 | 94 | 129 | 72.87 |
| superhero | 119 | 129 | 92.25 |
| financial | 81 | 106 | 76.42 |
| california_schools | 58 | 89 | 65.17 |
| debit_card_specializing | 42 | 64 | 65.62 |

Overall EX Accuracy: 70.14% (1076/1534)

## Execution Stats

- pred_sql_extracted: 1534
- pred_sql_missing: 0
- gold_sql_extracted: 1534
- gold_sql_missing: 0
- pred_sql_executed: 1528
- pred_sql_execution_failed: 6
- gold_sql_executed: 1532
- gold_sql_execution_failed: 2
- both_sql_executed: 1526
