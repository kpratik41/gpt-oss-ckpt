#include "marlin.cuh"

#include <torch/csrc/stable/accelerator.h>
#include <torch/csrc/stable/library.h>
#include <torch/csrc/stable/ops.h>
#include <torch/csrc/stable/tensor.h>
#include <torch/headeronly/core/ScalarType.h>
#include <torch/headeronly/util/Exception.h>

#include "libtorch_stable/torch_utils.h"

namespace marlin {

template <int const num_threads, int const num_bits, bool is_a_8bit>
__global__ void gptq_marlin_repack_kernel(
    uint32_t const* __restrict__ b_q_weight_ptr, uint32_t* __restrict__ out_ptr,
    int size_k, int size_n) {
  constexpr int pack_factor = 32 / num_bits;

  constexpr int target_tile_n_size = tile_n_size / (is_a_8bit ? 2 : 1);
  constexpr int target_tile_k_size = tile_k_size * (is_a_8bit ? 2 : 1);
  int k_tiles = size_k / target_tile_k_size;
  int n_tiles = size_n / target_tile_n_size;
  int block_k_tiles = div_ceil(k_tiles, gridDim.x);

  auto start_k_tile = blockIdx.x * block_k_tiles;
  if (start_k_tile >= k_tiles) {
    return;
  }

  int finish_k_tile = min(start_k_tile + block_k_tiles, k_tiles);

  // Wait until the next thread tile has been loaded to shared memory.
  auto wait_for_stage = [&]() {
    // We only have `stages - 2` active fetches since we are double buffering
    // and can only issue the next fetch when it is guaranteed that the previous
    // shared memory load is fully complete (as it may otherwise be
    // overwritten).
    cp_async_wait<repack_stages - 2>();
    __syncthreads();
  };

  extern __shared__ int4 sh[];

  int4* sh_pipe_ptr = sh;

  constexpr int tile_ints = target_tile_k_size / pack_factor;

  constexpr int stage_n_threads = target_tile_n_size / 4;
  constexpr int stage_k_threads = tile_ints;
  constexpr int stage_size = stage_k_threads * stage_n_threads;

  auto fetch_to_shared = [&](int pipe, int k_tile_id, int n_tile_id) {
    if (n_tile_id >= n_tiles) {
      cp_async_fence();
      return;
    }

    int first_n = n_tile_id * target_tile_n_size;

    int4* sh_ptr = sh_pipe_ptr + stage_size * pipe;

    if (threadIdx.x < stage_size) {
      auto k_id = threadIdx.x / stage_n_threads;
      auto n_id = threadIdx.x % stage_n_threads;

      int first_k = k_tile_id * target_tile_k_size;
      int first_k_packed = first_k / pack_factor;

      cp_async4(&sh_ptr[k_id * stage_n_threads + n_id],
                reinterpret_cast<int4 const*>(
                    &(b_q_weight_ptr[(first_k_packed + k_id) * size_n +
                                     first_n + (n_id * 4)])));
    }

    cp_async_fence();
  };

  auto repack_tile = [&](int pipe, int k_tile_id, int n_tile_id) {
    if (n_tile_id >= n_tiles) {
      return;
    }

    auto warp_id = threadIdx.x / 32;
    auto th_id = threadIdx.x % 32;

    if (warp_id >= 4) {
      return;
    }

    int tc_col = th_id / 4;
    int tc_row = (th_id % 4) * (is_a_8bit ? 4 : 2);

    constexpr int tc_offsets[4] = {0, 1, 8, 9};

    int cur_n = (warp_id / (is_a_8bit ? 2 : 1)) * 16 + tc_col;

    constexpr int sh_stride = target_tile_n_size;
    constexpr uint32_t mask = (1 << num_bits) - 1;

    int4* sh_stage_ptr = sh_pipe_ptr + stage_size * pipe;
    uint32_t* sh_stage_int_ptr = reinterpret_cast<uint32_t*>(sh_stage_ptr);

    uint32_t vals[8];

    uint32_t b1_vals[tile_ints];
    uint32_t b2_vals[tile_ints];

#pragma unroll
    for (int i = 0; i < tile_ints; i++) {
      if constexpr (is_a_8bit) {
        b1_vals[i] =
            sh_stage_int_ptr[cur_n + sh_stride * i + (warp_id % 2) * 8];
      } else {
        b1_vals[i] = sh_stage_int_ptr[cur_n + sh_stride * i];
        b2_vals[i] = sh_stage_int_ptr[cur_n + 8 + sh_stride * i];
      }
    }

#pragma unroll
    for (int i = 0; i < 4; i++) {
      int cur_elem = tc_row + (is_a_8bit ? i : tc_offsets[i]);
      int cur_int = cur_elem / pack_factor;
      int cur_pos = cur_elem % pack_factor;

      vals[i] = (b1_vals[cur_int] >> (cur_pos * num_bits)) & mask;
      if constexpr (is_a_8bit)
        vals[4 + i] =
            (b1_vals[cur_int + tile_ints / 2] >> (cur_pos * num_bits)) & mask;
      else
        vals[4 + i] = (b2_vals[cur_int] >> (cur_pos * num_bits)) & mask;
    }

    constexpr int tile_size =
        target_tile_k_size * target_tile_n_size / pack_factor;
    int out_offset = (k_tile_id * n_tiles + n_tile_id) * tile_size;

    // Result of:
    // https://github.com/NVIDIA/FasterTransformer/blob/main/src/fastertransformer/cutlass_extensions/include/cutlass_extensions/interleaved_numeric_conversion.h
    if constexpr (!is_a_8bit && num_bits == 4) {
      int pack_idx[8] = {0, 2, 4, 6, 1, 3, 5, 7};

      uint32_t res = 0;
#pragma unroll
      for (int i = 0; i < 8; i++) {
        res |= vals[pack_idx[i]] << (i * 4);
      }

      out_ptr[out_offset + th_id * 4 + warp_id] = res;

    } else if constexpr (is_a_8bit && num_bits == 4) {
      int pack_idx[8] = {0, 4, 1, 5, 2, 6, 3, 7};

      uint32_t res = 0;
#pragma unroll
      for (int i = 0; i < 8; i++) {
        res |= vals[pack_idx[i]] << (i * 4);
      }

      out_ptr[out_offset + th_id * 4 + warp_id] = res;

    } else {
      constexpr int pack_idx[4] = {0, 2, 1, 3};

      uint32_t res1 = 0;
      uint32_t res2 = 0;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int ii = is_a_8bit ? i : pack_idx[i];
        res1 |= vals[ii] << (i * 8);
        res2 |= vals[4 + ii] << (i * 8);
      }

      out_ptr[out_offset + th_id * 8 + (warp_id * 2) + 0] = res1;
      out_ptr[out_offset + th_id * 8 + (warp_id * 2) + 1] = res2;
    }
  };

  auto start_pipes = [&](int k_tile_id, int n_tile_id) {
#pragma unroll
    for (int pipe = 0; pipe < repack_stages - 1; pipe++) {
      fetch_to_shared(pipe, k_tile_id, n_tile_id + pipe);
    }

    wait_for_stage();
  };
#pragma unroll
  for (int k_tile_id = start_k_tile; k_tile_id < finish_k_tile; k_tile_id++) {
    int n_tile_id = 0;

    start_pipes(k_tile_id, n_tile_id);

    while (n_tile_id < n_tiles) {
#pragma unroll
      for (int pipe = 0; pipe < repack_stages; pipe++) {
        fetch_to_shared((pipe + repack_stages - 1) % repack_stages, k_tile_id,
                        n_tile_id + pipe + repack_stages - 1);
        repack_tile(pipe, k_tile_id, n_tile_id + pipe);
        wait_for_stage();
      }
      n_tile_id += repack_stages;
    }
  }
}

}  // namespace marlin

#define CALL_IF(NUM_BITS, IS_A_8BIT)                                        \
  else if (num_bits == NUM_BITS && is_a_8bit == IS_A_8BIT) {                \
    cudaFuncSetAttribute(                                                   \
        marlin::gptq_marlin_repack_kernel<marlin::repack_threads, NUM_BITS, \
                                          IS_A_8BIT>,                       \
        cudaFuncAttributeMaxDynamicSharedMemorySize, max_shared_mem);       \
    marlin::gptq_marlin_repack_kernel<marlin::repack_threads, NUM_BITS,     \
                                      IS_A_8BIT>                            \
        <<<blocks, marlin::repack_threads, max_shared_mem, stream>>>(       \
            b_q_weight_ptr, out_ptr, size_k, size_n);                       \
  }

torch::stable::Tensor gptq_marlin_repack(torch::stable::Tensor& b_q_weight,
                                         int64_t size_k, int64_t size_n,
                                         int64_t num_bits, bool is_a_8bit) {
  // Verify compatibility with marlin tile of 16x64
  STD_TORCH_CHECK(size_k % marlin::tile_k_size == 0, "size_k = ", size_k,
                  " is not divisible by tile_k_size = ", marlin::tile_k_size);
  STD_TORCH_CHECK(size_n % marlin::tile_n_size == 0, "size_n = ", size_n,
                  " is not divisible by tile_n_size = ", marlin::tile_n_size);

  STD_TORCH_CHECK(num_bits == 4 || num_bits == 8,
                  "num_bits must be 4 or 8. Got = ", num_bits);
  int const pack_factor = 32 / num_bits;

  // Verify B
  STD_TORCH_CHECK((size_k / pack_factor) == b_q_weight.size(0),
                  "Shape mismatch: b_q_weight.size(0) = ", b_q_weight.size(0),
                  ", size_k = ", size_k, ", pack_factor = ", pack_factor);
  STD_TORCH_CHECK(b_q_weight.size(1) == size_n,
                  "b_q_weight.size(1) = ", b_q_weight.size(1),
                  " is not size_n = ", size_n);

  // Verify device and strides
  STD_TORCH_CHECK(b_q_weight.is_cuda(), "b_q_weight is not on GPU");
  STD_TORCH_CHECK(b_q_weight.is_contiguous(), "b_q_weight is not contiguous");
  STD_TORCH_CHECK(
      b_q_weight.scalar_type() == torch::headeronly::ScalarType::Int,
      "b_q_weight type is not kInt");

  const int32_t device_index = b_q_weight.get_device_index();
  torch::stable::accelerator::DeviceGuard device_guard(device_index);
  const cudaStream_t stream = get_current_cuda_stream(device_index);

  // Alloc buffers
  torch::stable::Tensor out = torch::stable::empty(
      {size_k / marlin::tile_size, size_n * marlin::tile_size / pack_factor},
      b_q_weight.scalar_type(), std::nullopt, b_q_weight.device());

  // Get ptrs
  uint32_t const* b_q_weight_ptr =
      reinterpret_cast<uint32_t const*>(b_q_weight.const_data_ptr());
  uint32_t* out_ptr = reinterpret_cast<uint32_t*>(out.mutable_data_ptr());

  int blocks;
  cudaDeviceGetAttribute(&blocks, cudaDevAttrMultiProcessorCount, device_index);

  int max_shared_mem = 0;
  cudaDeviceGetAttribute(&max_shared_mem,
                         cudaDevAttrMaxSharedMemoryPerBlockOptin, device_index);
  STD_TORCH_CHECK(max_shared_mem > 0);

  if (false) {
  }
  CALL_IF(4, false)
  CALL_IF(8, false)

  CALL_IF(4, true)
  CALL_IF(8, true)

  else {
    STD_TORCH_CHECK(false, "Unsupported repack config: num_bits = ", num_bits,
                    ", is_a_8bit = ", is_a_8bit);
  }

  return out;
}

STABLE_TORCH_LIBRARY_IMPL(_C, CUDA, m) {
  m.impl("gptq_marlin_repack", TORCH_BOX(&gptq_marlin_repack));
}
