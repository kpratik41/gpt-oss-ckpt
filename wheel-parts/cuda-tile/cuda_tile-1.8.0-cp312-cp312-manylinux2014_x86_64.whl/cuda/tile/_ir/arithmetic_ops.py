# SPDX-FileCopyrightText: Copyright (c) <2026> NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# SPDX-License-Identifier: Apache-2.0


# This file contains implementations of arithmetic operations that work on generic
# TensorLikeTy inputs. Please avoid any cutile-specific logic outside of generate_bytecode()
# methods.


import operator
from dataclasses import dataclass
from typing import Sequence, Any, Callable
from typing_extensions import override

from cuda.tile import _datatype as datatype
from cuda.tile._datatype import DType, bool_, is_integral, is_boolean, \
    get_signedness, is_float, is_signed
from cuda.tile._cext import _binary_arithmetic_tensorlike, _binary_wrapping_arithmetic_tensorlike, \
    _comparison_tensorlike, _binary_bitwise_tensorlike, _bitwise_shift_tensorlike, \
    _tensorlike_negative, _tensorlike_positive, _tensorlike_invert, _divmod_tensorlike, \
    _tile_reshape, _tensorlike_astype, _dtype_constructor
from cuda.tile._exception import TileTypeError
from cuda.tile._numeric_semantics import RoundingMode
from cuda.tile._ir.core_ops import loosely_typed_const, strictly_typed_const, \
    comparison_operator_impl, build_tuple, sym2var
from cuda.tile._ir.ir import operand, Operation, Var, add_operation, Builder, attribute
from cuda.tile._ir.op_impl import ImplRegistry, ensure_scalar
from cuda.tile._ir.ops_utils import is_shape_broadcastable_to, promote_types, \
    get_dtype, get_default_rounding_mode, rounding_mode_to_bytecode, reraise_tile_exception, \
    check_rd_and_ftz, BINOP_REGISTRY, UNARYOP_REGISTRY
from cuda.tile._ir.type import TensorLikeTy, TileTy, LooselyTypedScalar, Type, var2sym
from cuda.tile._ir2bytecode import BytecodeContext, convert_dtype, typeid
import cuda.tile._bytecode as bc


_registry = ImplRegistry()
impl = _registry.impl


def arithmetic_impl_registry() -> ImplRegistry:
    return _registry


def binop_propagate_constant(fn: str, x: Any, y: Any, type: Type | None) -> Var:
    impl = BINOP_REGISTRY[fn].impl
    with reraise_tile_exception():
        res = impl(x, y)

    if type is None:
        return loosely_typed_const(res)
    else:
        return strictly_typed_const(res, type)


@dataclass(eq=False)
class TileReshape(Operation, opcode="tile_reshape"):
    x: Var = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        x_value = ctx.get_value(self.x)
        res_type_id = ctx.typeid_of(self.result_var)
        return bc.encode_ReshapeOp(ctx.builder, res_type_id, x_value)

    @override
    def generate_llvm(self, ctx):
        x_shape = self.x.get_type().tensor_shape()
        res_shape = self.result_var.get_type().tensor_shape()
        x = ctx.value(self.x)
        if x_shape == res_shape:
            return x

        zero = ctx.builder.constants.integer_constant(0, ctx.builder.type_table.I32)
        if x_shape == () and res_shape == (1,):
            vec = ctx.builder.constants.poison(ctx.typeof(self.result_var))
            return ctx.builder.insert_element(vec, x, zero)
        elif x_shape == (1,) and res_shape == ():
            return ctx.builder.extract_element(x, zero)
        else:
            raise NotImplementedError(f"reshape not implemented for {x_shape} -> {res_shape}")


# Does not validate the shape, hence the name "Raw"
def reshape_raw(x: Var[TensorLikeTy], new_shape: Sequence[int]) -> Var:
    x_ty = x.get_type()
    if tuple(new_shape) == x_ty.tensor_shape():
        return x
    res_type = x.ctx.typing_hooks.get_tensor_like_type(x_ty.tensor_dtype(), tuple(new_shape))
    return add_operation(TileReshape, res_type, x=x)


def reshape(x: Var[TensorLikeTy], new_shape: Sequence[int]) -> Var[TileTy]:
    return sym2var(_tile_reshape(var2sym(x), tuple(new_shape)))


@dataclass(eq=False)
class TileBroadcast(Operation, opcode="tile_broadcast"):
    x: Var = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        x_value = ctx.get_value(self.x)
        res_typeid = ctx.typeid_of(self.result_var)
        return bc.encode_BroadcastOp(ctx.builder, res_typeid, x_value)

    @override
    def generate_llvm(self, ctx):
        x_shape = self.x.get_type().tensor_shape()
        res_shape = self.result_var.get_type().tensor_shape()
        x = ctx.value(self.x)
        if x_shape == res_shape:
            return x

        if x_shape == ():
            zero = ctx.builder.constants.integer_constant(0, ctx.builder.type_table.I32)
            vec = ctx.builder.constants.poison(ctx.typeof(self.result_var))
            x = ctx.builder.insert_element(vec, x, zero)
            x_shape = (1,)

        assert x_shape == (1,)
        assert len(res_shape) == 1
        return ctx.builder.shuffle_vector(x, x, (0,) * res_shape[0])


def broadcast_to(x: Var[TensorLikeTy], shape: Sequence[int]) -> Var[TensorLikeTy]:
    x_ty = x.get_type()
    old_shape = x_ty.tensor_shape()

    if not is_shape_broadcastable_to(old_shape, shape):
        raise TileTypeError(f"Shape {old_shape} is not broadcastable to {tuple(shape)}")

    if len(shape) > len(old_shape):
        extra_ones = (1,) * (len(shape) - len(old_shape))
        old_shape = extra_ones + old_shape
        x = reshape_raw(x, old_shape)

    if old_shape == shape:
        return x
    else:
        result_ty = x.ctx.typing_hooks.get_tensor_like_type(x_ty.tensor_dtype(), shape)
        return add_operation(TileBroadcast, result_ty, x=x)


@dataclass(eq=False)
class TileAsType(Operation, opcode="tile_astype"):
    x: Var[TensorLikeTy] = operand()
    rounding_mode: RoundingMode | None = attribute(default=None)

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        value = ctx.get_value(self.x)

        return convert_dtype(ctx, value, ctx.typeof(self.x), ctx.typeof(self.result_var),
                             rounding_mode=self.rounding_mode)

    @override
    def rewrite_before_llvm_gen(self):
        from_type = self.x.get_type()
        to_type = self.result_var.get_type()
        from_dtype = from_type.tensor_dtype()
        to_dtype = to_type.tensor_dtype()

        # float16 <-> bfloat32 via an intermediate float32
        if (from_dtype in (datatype.float16, datatype.bfloat16)
                and to_dtype in (datatype.float16, datatype.bfloat16)):
            f32_value = astype(self.x, datatype.float32)
            return astype(f32_value, to_dtype, rounding_mode=self.rounding_mode)

        return NotImplemented

    @override
    def generate_llvm(self, ctx):
        from cuda.lang._llvm_bitcode import Cast
        from cuda.lang._passes.ir2llvm import DIRECTLY_SUPPORTED_FLOATS

        value = ctx.value(self.x)
        from_type = self.x.get_type()
        to_type = self.result_var.get_type()

        assert from_type.tensor_shape() == to_type.tensor_shape()
        from_dtype = from_type.tensor_dtype()
        to_dtype = to_type.tensor_dtype()
        assert datatype.is_numeric(from_dtype)
        assert datatype.is_numeric(to_dtype)
        if from_dtype == to_dtype:
            return value

        res_ty = ctx.type(to_type, storage=False)

        # Handle integer-to-integer and boolean-to-integer first
        if ((is_integral(from_dtype) or is_boolean(from_dtype))
                and is_integral(to_dtype)):
            actual_src_width = 1 if is_boolean(from_dtype) else from_dtype.bitwidth
            if actual_src_width == to_dtype.bitwidth:
                return value
            elif actual_src_width > to_dtype.bitwidth:
                return ctx.builder.cast(res_ty, Cast.TRUNC, value)
            elif datatype.is_signed(from_dtype):
                return ctx.builder.cast(res_ty, Cast.SEXT, value)
            else:
                return ctx.builder.cast(res_ty, Cast.ZEXT, value)

        # Integer/float to boolean
        if is_boolean(to_dtype):
            from cuda.lang._llvm_bitcode import CmpPredicate
            zero = ctx.constant(0, from_type)
            predicate = (CmpPredicate.FCMP_UNE if from_dtype in DIRECTLY_SUPPORTED_FLOATS
                         else CmpPredicate.ICMP_NE)
            return ctx.builder.cmp(predicate, value, zero)

        if self.rounding_mode is not None:
            raise NotImplementedError("Non-default rounding mode is not supported")

        # Direct float-to-float
        if from_dtype in DIRECTLY_SUPPORTED_FLOATS and to_dtype in DIRECTLY_SUPPORTED_FLOATS:
            if from_dtype.bitwidth > to_dtype.bitwidth:
                return ctx.builder.cast(res_ty, Cast.FPTRUNC, value)
            elif from_dtype.bitwidth < to_dtype.bitwidth:
                return ctx.builder.cast(res_ty, Cast.FPEXT, value)

        # Direct float to integer
        if from_dtype in DIRECTLY_SUPPORTED_FLOATS and is_integral(to_dtype):
            cast = Cast.FPTOSI if datatype.is_signed(to_dtype) else Cast.FPTOUI
            return ctx.builder.cast(res_ty, cast, value)

        # Int/bool to direct float
        if ((is_integral(from_dtype) or is_boolean(from_dtype))
                and to_dtype in DIRECTLY_SUPPORTED_FLOATS):
            cast = Cast.SITOFP if datatype.is_signed(from_dtype) else Cast.UITOFP
            return ctx.builder.cast(res_ty, cast, value)

        raise NotImplementedError(f"Unsupported type conversion"
                                  f" from {from_dtype} to {to_dtype}")


def add_astype_operation(x: Var[TensorLikeTy], dtype: DType,
                         rounding_mode: RoundingMode | None = None):
    x_ty = x.get_type()
    result_ty = x.ctx.typing_hooks.get_tensor_like_type(dtype, x_ty.tensor_shape())
    return add_operation(TileAsType, result_ty, x=x, rounding_mode=rounding_mode)


def astype(x: Var[TensorLikeTy], dtype: DType, *,
           rounding_mode: RoundingMode | None = None) -> Var[TensorLikeTy]:
    if x.get_type().tensor_dtype() == dtype:
        return x
    use_tile = _is_tile_dtype_result(x, dtype)
    return sym2var(_tensorlike_astype(var2sym(x), dtype, rounding_mode, use_tile))


# Unlike astype(), always returns a strictly typed value
def dtype_constructor(new_dtype: DType, x: Var) -> Var[TensorLikeTy]:
    use_tile = _is_tile_dtype_result(x, new_dtype)
    return sym2var(_dtype_constructor(var2sym(x), new_dtype, use_tile))


# Whether a scalar of `dtype` is represented as a 0-d tile, as opposed to a cuda.lang scalar
def _is_tile_dtype_result(x: Var, dtype: DType) -> bool:
    return isinstance(x.ctx.typing_hooks.get_tensor_like_type(dtype, ()), TileTy)


@impl(bool)
def bool_constructor_impl(x: Var) -> Var:
    if x.is_constant():
        return loosely_typed_const(bool(x.get_constant()))

    x = ensure_scalar(x, datatype.is_numeric)
    return astype(x, bool_)


def promote_and_broadcast_to(x: Var, ty: TensorLikeTy) -> Var[TensorLikeTy]:
    return broadcast_to(astype(x, ty.tensor_dtype()), ty.tensor_shape())


# Does not do broadcasting or type promotion, hence the name "Raw"
@dataclass(eq=False)
class RawComparisonOperation(Operation, opcode="raw_cmp"):
    fn: str = attribute()
    lhs: Var[TensorLikeTy] = operand()
    rhs: Var[TensorLikeTy] = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext):
        from .._ir2bytecode import encode_comparison
        lhs = ctx.get_value(self.lhs)
        rhs = ctx.get_value(self.rhs)
        dtype = self.lhs.get_type().tensor_dtype()
        result_typeid = ctx.typeid_of(self.result_var)
        return encode_comparison(ctx.builder, self.fn, lhs, rhs, dtype, result_typeid)

    @override
    def generate_llvm(self, ctx):
        def is_uint_or_bool(dtype: datatype.DType) -> bool:
            return (is_integral(dtype) and not is_signed(dtype)) or is_boolean(dtype)

        from cuda.lang._llvm_bitcode import CmpPredicate as P
        from cuda.lang._passes.ir2llvm import DIRECTLY_SUPPORTED_FLOATS

        ty = self.lhs.get_type()
        dtype = ty.tensor_dtype()
        match self.fn:
            case "eq" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_OEQ
            case "eq" if is_integral(dtype) or is_boolean(dtype): pred = P.ICMP_EQ

            case "ne" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_ONE
            case "ne" if is_integral(dtype) or is_boolean(dtype): pred = P.ICMP_NE

            case "ge" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_OGE
            case "ge" if is_integral(dtype) and is_signed(dtype): pred = P.ICMP_SGE
            case "ge" if is_uint_or_bool(dtype): pred = P.ICMP_UGE

            case "gt" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_OGT
            case "gt" if is_integral(dtype) and is_signed(dtype): pred = P.ICMP_SGT
            case "gt" if is_uint_or_bool(dtype): pred = P.ICMP_UGT

            case "ge" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_OGE
            case "ge" if is_integral(dtype) and is_signed(dtype): pred = P.ICMP_SGE
            case "ge" if is_uint_or_bool(dtype): pred = P.ICMP_UGE

            case "lt" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_OLT
            case "lt" if is_integral(dtype) and is_signed(dtype): pred = P.ICMP_SLT
            case "lt" if is_uint_or_bool(dtype): pred = P.ICMP_ULT

            case "le" if dtype in DIRECTLY_SUPPORTED_FLOATS: pred = P.FCMP_OLE
            case "le" if is_integral(dtype) and is_signed(dtype): pred = P.ICMP_SLE
            case "le" if is_uint_or_bool(dtype): pred = P.ICMP_ULE

            case _:
                raise NotImplementedError(f"Missing comparison implementation for {self.fn}[{ty}]")

        return ctx.builder.cmp(pred, ctx.value(self.lhs), ctx.value(self.rhs))


def compare_tensorlike_raw(fn: str,
                           x: Var[TensorLikeTy],
                           y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    ty = x.get_type()
    assert ty == y.get_type()
    res_ty = x.ctx.typing_hooks.get_tensor_like_type(bool_, ty.tensor_shape())
    return add_operation(RawComparisonOperation, res_ty, fn=fn, lhs=x, rhs=y)


def compare_tensorlike(fn: str, x: Var[TensorLikeTy], y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    return sym2var(_comparison_tensorlike(fn, var2sym(x), var2sym(y)))


@comparison_operator_impl(_registry, TensorLikeTy, TensorLikeTy)
def comparison_tensorlike_impl(fn: str, symbol: str,
                               x: Var[TensorLikeTy], y: Var[TensorLikeTy]) -> Var:
    return compare_tensorlike(fn, x, y)


# Does not do broadcasting or type promotion, hence the name "Raw"
@dataclass(eq=False)
class RawBinaryBitwiseOperation(Operation, opcode="raw_binary_bitwise"):
    fn: str = attribute()
    lhs: Var = operand()
    rhs: Var = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext):
        res_typeid = ctx.typeid_of(self.result_var)
        lhs = ctx.get_value(self.lhs)
        rhs = ctx.get_value(self.rhs)
        match self.fn:
            case "and_": return bc.encode_AndIOp(ctx.builder, res_typeid, lhs, rhs)
            case "or_": return bc.encode_OrIOp(ctx.builder, res_typeid, lhs, rhs)
            case "xor": return bc.encode_XOrIOp(ctx.builder, res_typeid, lhs, rhs)
            case _:
                raise NotImplementedError(f"Missing binary bitwise implementation for {self.fn}")

    @override
    def generate_llvm(self, ctx):
        from cuda.lang._llvm_bitcode import Binop
        match self.fn:
            case "and_": op = Binop.AND
            case "or_": op = Binop.OR
            case "xor": op = Binop.XOR
            case _:
                raise NotImplementedError(f"Missing bitwise binary implementation for {self.fn}")
        return ctx.builder.binop(op, ctx.value(self.lhs), ctx.value(self.rhs))


def binary_bitwise_tensorlike_raw(fn: str,
                                  x: Var[TensorLikeTy],
                                  y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    ty = x.get_type()
    assert ty == y.get_type()
    return add_operation(RawBinaryBitwiseOperation, ty, fn=fn, lhs=x, rhs=y)


def binary_bitwise_tensorlike(fn: str,
                              x: Var[TensorLikeTy],
                              y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    return sym2var(_binary_bitwise_tensorlike(fn, var2sym(x), var2sym(y)))


@impl(operator.and_, fixed_args=["and_"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.or_, fixed_args=["or_"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.xor, fixed_args=["xor"], overload=(TensorLikeTy, TensorLikeTy))
def _binary_bitwise_tensorlike_impl(fn: str,
                                    x: Var[TensorLikeTy],
                                    y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    return binary_bitwise_tensorlike(fn, x, y)


# Does not do broadcasting or type promotion, hence the name "Raw"
@dataclass(eq=False)
class RawBitwiseShiftOperation(Operation, opcode="raw_bitwise_shift"):
    fn: str = attribute()
    lhs: Var[TensorLikeTy] = operand()
    rhs: Var[TensorLikeTy] = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        res_ty = self.result_var.get_type()
        res_type_id = typeid(ctx.type_table, res_ty)
        lhs = ctx.get_value(self.lhs)
        rhs = ctx.get_value(self.rhs)
        match self.fn:
            case "lshift":
                return bc.encode_ShLIOp(ctx.builder, res_type_id, lhs, rhs, bc.IntegerOverflow.NONE)
            case "rshift":
                return bc.encode_ShRIOp(ctx.builder, res_type_id, lhs, rhs,
                                        get_signedness(get_dtype(res_ty)))
            case _: raise NotImplementedError()

    @override
    def generate_llvm(self, ctx):
        from cuda.lang._llvm_bitcode import Binop
        ty = self.lhs.get_type()
        dtype = ty.tensor_dtype()
        match self.fn:
            case "lshift": op = Binop.SHL
            case "rshift" if is_signed(dtype): op = Binop.ASHR
            case "rshift" if not is_signed(dtype): op = Binop.LSHR
            case _:
                raise NotImplementedError(f"Missing bit shift implementation for {self.fn}[{ty}]")
        return ctx.builder.binop(op, ctx.value(self.lhs), ctx.value(self.rhs))


def bitwise_shift_tensorlike_raw(fn: str,
                                 x: Var[TensorLikeTy],
                                 y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    ty = x.get_type()
    assert ty == y.get_type()
    return add_operation(RawBitwiseShiftOperation, ty, fn=fn, lhs=x, rhs=y)


def bitwise_shift_tensorlike(fn: str,
                             x: Var[TensorLikeTy],
                             y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    return sym2var(_bitwise_shift_tensorlike(fn, var2sym(x), var2sym(y)))


@impl(operator.lshift, fixed_args=["lshift"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.rshift, fixed_args=["rshift"], overload=(TensorLikeTy, TensorLikeTy))
def _bitwise_shift_tensorlike_impl(fn: str, x: Var[TensorLikeTy], y: Var[TensorLikeTy]):
    return bitwise_shift_tensorlike(fn, x, y)


# Does not do broadcasting or type promotion, hence the name "Raw"
@dataclass(eq=False)
class RawBinaryArithmeticOperation(Operation, opcode="raw_binary_arith"):
    fn: str = attribute()
    rounding_mode: RoundingMode | None = attribute(default=None)
    flush_to_zero: bool = attribute(default=False)
    propagate_nan: bool = attribute(default=False)
    lhs: Var[TensorLikeTy] = operand()
    rhs: Var[TensorLikeTy] = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        result_ty = self.result_var.get_type()
        dtype = get_dtype(result_ty)
        kind = "float" if is_float(dtype) else "int"
        res_typeid = typeid(ctx.type_table, result_ty)
        rm = self.rounding_mode if self.rounding_mode is not None else get_default_rounding_mode()
        rounding_mode = rounding_mode_to_bytecode[rm]
        lhs = ctx.get_value(self.lhs)
        rhs = ctx.get_value(self.rhs)

        match self.fn, kind:
            case "add", "int":
                return bc.encode_AddIOp(ctx.builder, res_typeid, lhs, rhs,
                                        overflow=bc.IntegerOverflow.NONE)
            case "add", "float":
                return bc.encode_AddFOp(ctx.builder, res_typeid, lhs, rhs,
                                        rounding_mode=rounding_mode,
                                        flush_to_zero=self.flush_to_zero)
            case "sub", "int":
                return bc.encode_SubIOp(ctx.builder, res_typeid, lhs, rhs,
                                        overflow=bc.IntegerOverflow.NONE)
            case "sub", "float":
                return bc.encode_SubFOp(ctx.builder, res_typeid, lhs, rhs,
                                        rounding_mode=rounding_mode,
                                        flush_to_zero=self.flush_to_zero)
            case "mul", "int":
                return bc.encode_MulIOp(ctx.builder, res_typeid, lhs, rhs,
                                        overflow=bc.IntegerOverflow.NONE)
            case "mul", "float":
                return bc.encode_MulFOp(ctx.builder, res_typeid, lhs, rhs,
                                        rounding_mode=rounding_mode,
                                        flush_to_zero=self.flush_to_zero)
            case "floordiv", "int":
                return bc.encode_DivIOp(ctx.builder, res_typeid, lhs, rhs,
                                        signedness=get_signedness(dtype),
                                        rounding=bc.RoundingMode.NEGATIVE_INF)
            case "floordiv", "float":
                quotient = bc.encode_DivFOp(ctx.builder, res_typeid, lhs, rhs,
                                            rounding_mode=rounding_mode,
                                            flush_to_zero=self.flush_to_zero)
                return bc.encode_FloorOp(ctx.builder, res_typeid, quotient)
            case "cdiv", "int":
                return bc.encode_DivIOp(ctx.builder, res_typeid, lhs, rhs,
                                        signedness=get_signedness(dtype),
                                        rounding=bc.RoundingMode.POSITIVE_INF)
            case "truediv", "float":
                return bc.encode_DivFOp(ctx.builder, res_typeid, lhs, rhs,
                                        rounding_mode=rounding_mode,
                                        flush_to_zero=self.flush_to_zero)
            case "pow", "float":
                return bc.encode_FPowFOp(ctx.builder, res_typeid, lhs, rhs)
            case "atan2", "float":
                return bc.encode_Atan2Op(ctx.builder, res_typeid, lhs, rhs)
            case "min", "int":
                return bc.encode_MinIOp(ctx.builder, res_typeid, lhs, rhs,
                                        signedness=get_signedness(dtype))
            case "min", "float":
                return bc.encode_MinFOp(ctx.builder, res_typeid, lhs, rhs,
                                        propagate_nan=self.propagate_nan,
                                        flush_to_zero=self.flush_to_zero)
            case "max", "int":
                return bc.encode_MaxIOp(ctx.builder, res_typeid, lhs, rhs,
                                        signedness=get_signedness(dtype))
            case "max", "float":
                return bc.encode_MaxFOp(ctx.builder, res_typeid, lhs, rhs,
                                        propagate_nan=self.propagate_nan,
                                        flush_to_zero=self.flush_to_zero)
            case "c_mod", "float":
                # C-style modulo
                return bc.encode_RemFOp(ctx.builder, res_typeid, lhs, rhs)
            case "c_mod", "int":
                # C-style modulo
                return bc.encode_RemIOp(ctx.builder, res_typeid, lhs, rhs,
                                        signedness=get_signedness(dtype))
            case _:
                raise NotImplementedError(f"Missing binary arithmetic implementation"
                                          f" for {self.fn}, {kind}")

    @override
    def rewrite_before_llvm_gen(self):
        ty = self.result_var.get_type()
        dtype = ty.tensor_dtype()
        match self.fn:
            case "floordiv" | "cdiv" if is_integral(dtype) and datatype.is_signed(dtype):
                # q = SDIV(lhs, rhs)
                # p = q * rhs
                # if p != lhs & (lhs < 0) ==/!= (rhs < 0)  # depending on cdiv/floordiv
                #    result = q +/- 1  # depending on cdiv/floordiv
                # else:
                #    result = q
                q = binary_arithmetic_tensorlike_raw("truncdiv", self.lhs, self.rhs)
                p = binary_arithmetic_tensorlike_raw("mul", q, self.rhs)
                ne = compare_tensorlike_raw("ne", self.lhs, p)
                zero = strictly_typed_const(0, ty)
                lhs_neg = compare_tensorlike_raw("lt", self.lhs, zero)
                rhs_neg = compare_tensorlike_raw("lt", self.rhs, zero)
                cmp, correction = (("ne", -1), ("eq", 1))[("floordiv", "cdiv").index(self.fn)]
                need_correction = compare_tensorlike_raw(cmp, lhs_neg, rhs_neg)
                cond = binary_bitwise_tensorlike_raw("and_", ne, need_correction)
                correction_const = strictly_typed_const(correction, ty)
                q_minus_one = binary_arithmetic_tensorlike_raw("add", q, correction_const)
                return where_raw(cond, q_minus_one, q)
            case "floordiv" if datatype.is_float(dtype):
                tmp = binary_arithmetic_tensorlike_raw("truediv", self.lhs, self.rhs)
                return unary_raw("floor", tmp)
            case "cdiv" if is_integral(dtype) and not datatype.is_signed(dtype):
                # 0 if lhs == 0 else floordiv(lhs - 1, m) + 1
                zero = strictly_typed_const(0, ty)
                is_zero = compare_tensorlike_raw("eq", self.lhs, zero)
                one = strictly_typed_const(1, ty)
                lhs_minus_one = binary_arithmetic_tensorlike_raw("sub", self.lhs, one)
                q = binary_arithmetic_tensorlike_raw("floordiv", lhs_minus_one, self.rhs)
                res = binary_arithmetic_tensorlike_raw("add", q, one)
                return where_raw(is_zero, zero, res)
            case _:
                return NotImplemented

    @override
    def generate_llvm(self, ctx):
        from cuda.lang._llvm_bitcode import Binop
        simple = self.rounding_mode is None and not self.flush_to_zero
        if not simple:
            raise NotImplementedError()
        ty = self.result_var.get_type()
        dtype = ty.tensor_dtype()
        match self.fn:
            case "add": op = Binop.ADD
            case "sub": op = Binop.SUB
            case "mul": op = Binop.MUL
            case "truncdiv" if is_integral(dtype) and is_signed(dtype): op = Binop.SDIV
            case "floordiv" if is_integral(dtype) and not is_signed(dtype): op = Binop.UDIV
            case "truediv" if datatype.is_float(dtype): op = Binop.SDIV
            case "c_mod" if is_signed(dtype): op = Binop.SREM
            case "c_mod" if not is_signed(dtype): op = Binop.UREM
            case "xor": op = Binop.XOR
            case "or_": op = Binop.OR
            case "and_": op = Binop.AND
            case _:
                raise NotImplementedError(
                    f"Missing binary arithmetic implementation for"
                    f" {self.fn}[{ty}, {self.rounding_mode}, ftz={self.flush_to_zero}]")
        return ctx.builder.binop(op, ctx.value(self.lhs), ctx.value(self.rhs))


def binary_arithmetic_tensorlike_raw(fn: str, x: Var[TensorLikeTy], y: Var[TensorLikeTy],
                                     rounding_mode: RoundingMode | None = None,
                                     flush_to_zero: bool = False,
                                     propagate_nan: bool = False) -> Var[TensorLikeTy]:
    ty = x.get_type()
    assert ty == y.get_type(), f"{ty} != {y.get_type()}"
    # FIXME: remove cutile-specific check
    check_rd_and_ftz(fn, rounding_mode, flush_to_zero, ty.tensor_dtype())
    return add_operation(RawBinaryArithmeticOperation, ty, fn=fn, lhs=x, rhs=y,
                         rounding_mode=rounding_mode, flush_to_zero=flush_to_zero,
                         propagate_nan=propagate_nan)


def binary_arithmetic_tensorlike(fn: str, x: Var[TensorLikeTy], y: Var[TensorLikeTy],
                                 rounding_mode: RoundingMode | None = None,
                                 flush_to_zero: bool = False,
                                 propagate_nan: bool = False) -> Var[TensorLikeTy]:
    res = _binary_arithmetic_tensorlike(fn, var2sym(x), var2sym(y),
                                        rounding_mode, flush_to_zero, propagate_nan)
    return sym2var(res)


def binary_wrapping_arithmetic_tensorlike(fn: str, x: Var[TensorLikeTy],
                                          y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    res = _binary_wrapping_arithmetic_tensorlike(fn, var2sym(x), var2sym(y), True)
    return sym2var(res)


@dataclass(eq=False)
class RawFPowIOperation(Operation, opcode="raw_fpowi"):
    base: Var[TensorLikeTy] = operand()
    exponent: Var[TensorLikeTy] = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        res_typeid = ctx.typeid_of(self.result_var)
        base = ctx.get_value(self.base)
        exponent = ctx.get_value(self.exponent)
        return bc.encode_FPowIOp(ctx.builder, res_typeid, base, exponent)


def _fpowi_exponent_dtype(dtype: DType) -> DType | None:
    if not is_integral(dtype):
        return None
    info = datatype.IntegerInfo(dtype)
    for candidate in (datatype.int8, datatype.int16, datatype.int32):
        cinfo = datatype.IntegerInfo(candidate)
        if cinfo.min <= info.min and info.max <= cinfo.max:
            return candidate
    return None


# Raises a non-constant float `base` to an integer `exponent` power. Does not do broadcasting:
# the exponent must have the same shape as the base. Uses the FPowI operation if the target
# supports it and the exponent fits in int32, and falls back to a regular power otherwise.
def fpowi(base: Var[TensorLikeTy], exponent: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    exp_dtype = _fpowi_exponent_dtype(exponent.get_type().tensor_dtype())
    # tileiras_version is None when not targeting TileIR (e.g., in cuda.lang)
    tileiras_version = Builder.get_current().ir_ctx.tileiras_version
    if exp_dtype is not None \
            and (tileiras_version is None or tileiras_version >= bc.BytecodeVersion.V_13_4):
        exponent = astype(exponent, exp_dtype)
        return add_operation(RawFPowIOperation, base.get_type(), base=base, exponent=exponent)
    exponent = astype(exponent, base.get_type().tensor_dtype())
    return binary_arithmetic_tensorlike_raw("pow", base, exponent)


@impl(operator.add, fixed_args=["add"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.sub, fixed_args=["sub"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.mul, fixed_args=["mul"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.mod, fixed_args=["mod"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.pow, fixed_args=["pow"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.floordiv, fixed_args=["floordiv"], overload=(TensorLikeTy, TensorLikeTy))
@impl(operator.truediv, fixed_args=["truediv"], overload=(TensorLikeTy, TensorLikeTy))
@impl(min, fixed_args=["min"], overload=(TensorLikeTy, TensorLikeTy))
@impl(max, fixed_args=["max"], overload=(TensorLikeTy, TensorLikeTy))
def _binary_arithmetic_tensorlike_impl(fn: str, x: Var[TensorLikeTy], y: Var[TensorLikeTy]):
    return binary_arithmetic_tensorlike(fn, x, y)


def mod_tensorlike_raw(x: Var[TensorLikeTy], y: Var[TensorLikeTy]):
    # TileIR rem follows the C behavior while Python's mod behavior differs.
    # So we generate the C-style mod first and then apply a correction.
    value = binary_arithmetic_tensorlike_raw("c_mod", x, y)

    # If the sign of `value` does not match the sign of `y`, apply a correction.
    zero = strictly_typed_const(0, value.get_type())
    value_sign = compare_tensorlike("lt", value, zero)
    y_sign = compare_tensorlike("lt", y, zero)

    sign_mismatch = binary_bitwise_tensorlike("xor", value_sign, y_sign)
    if is_float(value.get_type().tensor_dtype()):
        # need_fix = value_sign ^ y_sign
        # The zero case is handled below, and NaN stays NaN after the correction.
        fixed_value = binary_arithmetic_tensorlike("add", value, y)
        result = where(sign_mismatch, fixed_value, value)

        # A zero float result takes the sign of `y`, e.g. 4.0 % -2.0 == -0.0
        negative_zero = strictly_typed_const(-0.0, value.get_type())
        signed_zero = where(y_sign, negative_zero, zero)
        value_is_zero = compare_tensorlike("eq", value, zero)
        result = where(value_is_zero, signed_zero, result)
    else:
        # need_fix = (value_sign ^ y_sign) & (value != 0)
        value_not_zero = compare_tensorlike("ne", value, zero)
        need_fix = binary_bitwise_tensorlike("and_", sign_mismatch, value_not_zero)
        fixed_value = binary_arithmetic_tensorlike("add", value, y)
        result = where(need_fix, fixed_value, value)
    return result


def divmod_tensorlike(x: Var[TensorLikeTy], y: Var[TensorLikeTy]):
    q, r = _divmod_tensorlike(var2sym(x), var2sym(y))
    return build_tuple((sym2var(q), sym2var(r)))


@impl(divmod, overload=(TensorLikeTy, TensorLikeTy))
def _divmod_tensorlike_impl(x: Var[TensorLikeTy], y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    return divmod_tensorlike(x, y)


# Does not support broadcasting or type promotion
@dataclass(eq=False)
class RawWhereOperation(Operation, opcode="raw_where"):
    cond: Var = operand()
    x: Var = operand()
    y: Var = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        res_typeid = ctx.typeid_of(self.result_var)
        cond = ctx.get_value(self.cond)
        x = ctx.get_value(self.x)
        y = ctx.get_value(self.y)
        return bc.encode_SelectOp(ctx.builder, res_typeid, cond, x, y)

    @override
    def generate_llvm(self, ctx):
        return ctx.builder.select(ctx.value(self.cond), ctx.value(self.x), ctx.value(self.y))


def where_raw(cond: Var[TensorLikeTy],
              x: Var[TensorLikeTy],
              y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    ty = x.get_type()
    assert ty == y.get_type()
    return add_operation(RawWhereOperation, ty, cond=cond, x=x, y=y)


def where(cond: Var[TensorLikeTy],
          x: Var[TensorLikeTy],
          y: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    cond_ty = cond.get_loose_type()
    x_ty = x.get_loose_type()
    y_ty = y.get_loose_type()

    typing_hooks = cond.ctx.typing_hooks

    xy_ty = promote_types(x_ty, y_ty, typing_hooks)
    dtype = xy_ty.tensor_dtype()

    cond_like_ty = typing_hooks.get_tensor_like_type(dtype, cond_ty.tensor_shape())
    res_ty = promote_types(cond_like_ty, xy_ty, typing_hooks)

    result_shaped_bool = typing_hooks.get_tensor_like_type(bool_, res_ty.tensor_shape())

    cond = promote_and_broadcast_to(cond, result_shaped_bool)
    x = promote_and_broadcast_to(x, res_ty)
    y = promote_and_broadcast_to(y, res_ty)
    return where_raw(cond, x, y)


@dataclass(eq=False)
class Unary(Operation, opcode="unaryop"):
    fn: str = attribute()
    rounding_mode: RoundingMode | None = attribute(default=None)
    flush_to_zero: bool = attribute(default=False)
    operand: Var = operand()

    @override
    def generate_bytecode(self, ctx: BytecodeContext) -> bc.Value:
        x = ctx.get_value(self.operand)
        rm = (self.rounding_mode if self.rounding_mode is not None
              else get_default_rounding_mode(self.fn))
        rounding_mode = rounding_mode_to_bytecode[rm]
        flush_to_zero = self.flush_to_zero
        input_type = ctx.typeof(self.operand)
        input_dtype = get_dtype(input_type)
        flt = is_float(input_dtype)
        res_type_id = ctx.typeid_of(self.result_var)

        match self.fn, flt:
            case "abs", True: return bc.encode_AbsFOp(ctx.builder, res_type_id, x)
            case "abs", False: return bc.encode_AbsIOp(ctx.builder, res_type_id, x)
            case "neg", True: return bc.encode_NegFOp(ctx.builder, res_type_id, x)
            case "neg", False: return bc.encode_NegIOp(ctx.builder, res_type_id, x,
                                                       bc.IntegerOverflow.NONE)
            case "exp", True: return bc.encode_ExpOp(ctx.builder, res_type_id, x,
                                                     rounding_mode=rounding_mode)
            case "exp2", True: return bc.encode_Exp2Op(ctx.builder, res_type_id, x,
                                                       flush_to_zero=flush_to_zero)
            case "sin", True: return bc.encode_SinOp(ctx.builder, res_type_id, x)
            case "cos", True: return bc.encode_CosOp(ctx.builder, res_type_id, x)
            case "sinh", True: return bc.encode_SinHOp(ctx.builder, res_type_id, x)
            case "cosh", True: return bc.encode_CosHOp(ctx.builder, res_type_id, x)
            case "tan", True: return bc.encode_TanOp(ctx.builder, res_type_id, x)
            case "tanh", True: return bc.encode_TanHOp(ctx.builder, res_type_id, x,
                                                       rounding_mode=rounding_mode)
            case "log", True: return bc.encode_LogOp(ctx.builder, res_type_id, x)
            case "log2", True: return bc.encode_Log2Op(ctx.builder, res_type_id, x)
            case "sqrt", True: return bc.encode_SqrtOp(ctx.builder, res_type_id, x,
                                                       rounding_mode=rounding_mode,
                                                       flush_to_zero=flush_to_zero)
            case "rsqrt", True: return bc.encode_RsqrtOp(ctx.builder, res_type_id, x,
                                                         flush_to_zero=flush_to_zero)
            case "floor", True: return bc.encode_FloorOp(ctx.builder, res_type_id, x)
            case "ceil", True: return bc.encode_CeilOp(ctx.builder, res_type_id, x)
            case "invert" | "bitwise_not", False:
                # ~tx == tx ^ ~0
                all_ones = (-1 if datatype.is_signed(input_dtype)
                            else ~(-1 << input_dtype.bitwidth))
                all_ones_tile = ctx.constant(all_ones, input_type)
                return bc.encode_XOrIOp(ctx.builder, res_type_id, x, all_ones_tile)
            case _:
                raise NotImplementedError(f"Missing implementation for unary op: {self.fn}")

    @override
    def rewrite_before_llvm_gen(self):
        x = self.operand
        input_ty = x.get_type()
        input_dtype = input_ty.tensor_dtype()
        match self.fn:
            case "neg" if is_integral(input_dtype):
                zero = strictly_typed_const(0, input_ty)
                return binary_arithmetic_tensorlike_raw("sub", zero, x)
            case _:
                return NotImplemented

    @override
    def generate_llvm(self, ctx):
        from cuda.lang._passes.ir2llvm import DIRECTLY_SUPPORTED_FLOATS
        from cuda.lang._llvm_bitcode import Unop
        input_dtype = self.operand.get_type().tensor_dtype()
        x = ctx.value(self.operand)
        match self.fn:
            case "neg" if input_dtype in DIRECTLY_SUPPORTED_FLOATS:
                return ctx.builder.unop(Unop.FNEG, x)
            case _:
                raise NotImplementedError(f"Missing implementation for unary op: {self.fn}")


def _unary_promote_to_int(x):
    return astype(x, datatype.default_int_type)


def _unary_promote_to_float(x):
    return astype(x, datatype.default_float_type)


def _unary_preserve(x):
    return x


@dataclass
class UnaryBehavior:
    bool_handler: Callable[[Var], Var] | None
    int_handler: Callable[[Var], Var] | None
    float_handler: Callable[[Var], Var] | None


def _unary_propagate_constant(fn: str, arg: Any) -> Any:
    impl = UNARYOP_REGISTRY[fn].impl
    with reraise_tile_exception():
        return impl(arg)


def unary_raw(fn: str, x: Var[TensorLikeTy],
              rounding_mode: RoundingMode | None = None, flush_to_zero: bool = False):
    return add_operation(Unary, x.get_type(), fn=fn, operand=x,
                         rounding_mode=rounding_mode, flush_to_zero=flush_to_zero)


def unary(fn: str, behavior: UnaryBehavior, x: Var[TensorLikeTy],
          rounding_mode: RoundingMode | None = None, flush_to_zero: bool = False) -> Var:
    x_type = x.get_loose_type()
    if isinstance(x_type, LooselyTypedScalar):
        res = _unary_propagate_constant(fn, x_type.value)
        return loosely_typed_const(res)

    input_dtype = x_type.tensor_dtype()
    if is_boolean(input_dtype):
        if behavior.bool_handler is None:
            raise TileTypeError("Boolean inputs are not supported")
        x = behavior.bool_handler(x)
    elif is_integral(input_dtype):
        if behavior.int_handler is None:
            raise TileTypeError("Integer inputs are not supported")
        x = behavior.int_handler(x)
    elif is_float(input_dtype):
        if behavior.float_handler is None:
            raise TileTypeError("Float inputs are not supported")
        x = behavior.float_handler(x)
    else:
        raise TileTypeError(f"Unexpected input dtype {input_dtype}")

    ty = x.get_type()
    if x.is_constant():
        res = _unary_propagate_constant(fn, x.get_constant())
        return strictly_typed_const(res, ty)

    # FIXME: remove cutile-specific check
    check_rd_and_ftz(fn, rounding_mode, flush_to_zero, ty.tensor_dtype())
    return unary_raw(fn, x, rounding_mode=rounding_mode, flush_to_zero=flush_to_zero)


UNARY_FLOAT = UnaryBehavior(_unary_promote_to_float, _unary_promote_to_float, _unary_preserve)
UNARY_STRICT_FLOAT = UnaryBehavior(None, None, _unary_preserve)
UNARY_INT_FLOAT = UnaryBehavior(_unary_promote_to_int, _unary_preserve, _unary_preserve)
UNARY_BOOL_INT = UnaryBehavior(_unary_preserve, _unary_preserve, None)
UNARY_ANYTHING = UnaryBehavior(_unary_preserve, _unary_preserve, _unary_preserve)


def invert_tensorlike(x: Var[TensorLikeTy]):
    return sym2var(_tensorlike_invert(var2sym(x), True))


@impl(operator.invert, overload=(TensorLikeTy,))
def _invert_tensorlike_impl(x: Var) -> Var:
    return invert_tensorlike(x)


@impl(operator.neg, overload=(TensorLikeTy,))
def _neg_tensorlike_impl(x: Var) -> Var:
    return sym2var(_tensorlike_negative(var2sym(x), True))


@impl(operator.not_, overload=(TensorLikeTy,))
def logical_not_impl(x: Var[TensorLikeTy]) -> Var[TensorLikeTy]:
    ty = x.get_loose_type()
    if isinstance(ty, LooselyTypedScalar):
        return loosely_typed_const(not ty.value)

    x = astype(x, datatype.bool_)
    if x.is_constant():
        return strictly_typed_const(not x.get_constant(), x.get_type())

    return add_operation(Unary, x.get_type(), fn="invert", operand=x)


@impl(operator.pos, overload=(TensorLikeTy,))
def pos_impl(x: Var[TensorLikeTy]):
    return sym2var(_tensorlike_positive(var2sym(x), True))
