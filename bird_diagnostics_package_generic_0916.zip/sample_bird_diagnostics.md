# BIRD Evaluation Output Diagnostics

This report contains aggregate diagnostics only. It intentionally omits SQL strings, DB ids, questions, schemas, result rows, and database-derived values.

## Run: bird_test_sft_rl

- run_root: `outputs/bird_test_sft_rl`
- candidate_source: `outputs/bird_test_sft_rl/passk/passk_candidates.jsonl`
- expected_questions: `5`
- expected_generations: `16`

### Final Prediction File

- entries: `5`
- missing_vs_expected: `0`
- malformed_bird_format: `0`
- empty_sql_entries: `0` (0.00%)

### Candidate Generation And Execution

- candidate slot coverage: 80/80 (100.00%)
- SQL extracted: 76/80 (95.00%)
- candidate SQL executed: 74/80 (92.50%)
- missing candidate slots: `0`
- duplicate idx/sample keys: `0`
- candidates per question histogram: `{'16': 5}`
- stop reason counts: `{'finished': 80}`
- candidate pred error categories: `{'none': 74, 'empty_sql': 4, 'sqlite_no_such_column': 2}`
- status counts: `{'pred_ok': 74, 'pred_error_empty_sql': 4, 'pred_error_sqlite_no_such_column': 2}`
- tool rounds: avg=1.450, median=1.000, p90=2.000, p95=3.050, min=0.000, max=5.000, n=80
- tool calls: avg=1.450, median=1.000, p90=2.000, p95=3.050, min=0.000, max=5.000, n=80
- tool round histogram: `{'1': 52, '2': 19, '3': 3, '4': 3, '0': 2, '5': 1}`
- tool call histogram: `{'1': 52, '2': 19, '3': 3, '4': 3, '0': 2, '5': 1}`
- candidates with tool-error marker: `16` (20.00%)
- tool-error marker categories: `{'other': 20, 'generation_or_runtime_error': 1}`
- completion tokens: avg=1148.838, median=900.500, p90=2005.800, p95=2417.900, min=454.000, max=3627.000, n=80
- prompt tokens: avg=18281.400, median=18276.000, p90=18459.000, p95=18459.000, min=18156.000, max=18459.000, n=80

### Self-Consistency Voting

- selected SQL executed: 5/5 (100.00%)
- examples without valid vote: 0/5 (0.00%)
- selected vote count histogram: `{'16': 3, '12': 2}`
- valid vote candidates histogram: `{'16': 3, '13': 2}`
- full consensus at expected k: `3` (60.00%)
- all expected candidates valid: `3` (60.00%)
- selected-vote confidence: avg=0.969, median=1.000, p90=1.000, p95=1.000, min=0.923, max=1.000, n=5
- selected pred error categories: `{'none': 5}`

### Timing

- exact_per_question_latency_available: `False`
- note: The submitted code does not persist per-question wall-clock latency. Only aggregate timing from passk_summary.json/pipeline.log can be reported.
- passk_timing_seconds: `{'generation': 487.406626701355, 'evaluation': 0.29343557357788086, 'total': 487.7195224761963}`
- passk_total_seconds_per_question: `97.544`
- generation_seconds_per_candidate: `6.093`
- candidate_eval_seconds_per_candidate: `0.004`

## Run: bird_test_rl_only

- run_root: `outputs/bird_test_rl_only`
- candidate_source: `outputs/bird_test_rl_only/passk/passk_candidates.jsonl`
- expected_questions: `5`
- expected_generations: `16`

### Final Prediction File

- entries: `5`
- missing_vs_expected: `0`
- malformed_bird_format: `0`
- empty_sql_entries: `0` (0.00%)

### Candidate Generation And Execution

- candidate slot coverage: 80/80 (100.00%)
- SQL extracted: 78/80 (97.50%)
- candidate SQL executed: 76/80 (95.00%)
- missing candidate slots: `0`
- duplicate idx/sample keys: `0`
- candidates per question histogram: `{'16': 5}`
- stop reason counts: `{'finished': 80}`
- candidate pred error categories: `{'none': 76, 'empty_sql': 2, 'sqlite_no_such_column': 2}`
- status counts: `{'pred_ok': 76, 'pred_error_empty_sql': 2, 'pred_error_sqlite_no_such_column': 2}`
- tool rounds: avg=1.462, median=1.000, p90=2.000, p95=3.000, min=0.000, max=4.000, n=80
- tool calls: avg=1.462, median=1.000, p90=2.000, p95=3.000, min=0.000, max=4.000, n=80
- tool round histogram: `{'1': 47, '2': 26, '4': 3, '0': 2, '3': 2}`
- tool call histogram: `{'1': 47, '2': 26, '4': 3, '0': 2, '3': 2}`
- candidates with tool-error marker: `13` (16.25%)
- tool-error marker categories: `{'other': 17, 'generation_or_runtime_error': 1}`
- completion tokens: avg=1166.188, median=971.000, p90=1920.100, p95=2461.650, min=436.000, max=3372.000, n=80
- prompt tokens: avg=18281.400, median=18276.000, p90=18459.000, p95=18459.000, min=18156.000, max=18459.000, n=80

### Self-Consistency Voting

- selected SQL executed: 5/5 (100.00%)
- examples without valid vote: 0/5 (0.00%)
- selected vote count histogram: `{'16': 2, '10': 1, '11': 1, '14': 1}`
- valid vote candidates histogram: `{'16': 3, '13': 1, '15': 1}`
- full consensus at expected k: `2` (40.00%)
- all expected candidates valid: `3` (60.00%)
- selected-vote confidence: avg=0.881, median=0.933, p90=1.000, p95=1.000, min=0.625, max=1.000, n=5
- selected pred error categories: `{'none': 5}`

### Timing

- exact_per_question_latency_available: `False`
- note: The submitted code does not persist per-question wall-clock latency. Only aggregate timing from passk_summary.json/pipeline.log can be reported.
- passk_timing_seconds: `{'generation': 489.74801898002625, 'evaluation': 0.25716114044189453, 'total': 490.0249788761139}`
- passk_total_seconds_per_question: `98.005`
- generation_seconds_per_candidate: `6.122`
- candidate_eval_seconds_per_candidate: `0.003`
