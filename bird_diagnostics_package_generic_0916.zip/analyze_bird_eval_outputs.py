#!/usr/bin/env python3
"""Summarize BIRD submission run artifacts without revealing DB content.

This script is intended for the BIRD team to run on completed evaluation output
directories. It reads existing JSON/JSONL artifacts produced by run.sh and
prints aggregate diagnostics only: counts, percentages, histograms, and timing
summaries. It intentionally does not print SQL strings, DB ids, questions,
schemas, execution rows, or database-derived values.

Typical use:

  python3 analyze_bird_eval_outputs.py \
    outputs/bird_test_sft_rl \
    outputs/bird_test_rl_only

If no directories are provided, the script looks for the two standard run roots
under outputs/.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

BIRD_MARKER = "\t----- bird -----\t"
DEFAULT_RUN_ROOTS = ("outputs/bird_test_sft_rl", "outputs/bird_test_rl_only")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Aggregate non-sensitive diagnostics from BIRD run outputs."
    )
    parser.add_argument(
        "run_roots",
        nargs="*",
        help=(
            "Run output roots, e.g. outputs/bird_test_sft_rl. If omitted, the "
            "script tries outputs/bird_test_sft_rl and outputs/bird_test_rl_only."
        ),
    )
    parser.add_argument(
        "--expected-generations",
        type=int,
        default=16,
        help="Expected pass@k samples per question; used for coverage percentages.",
    )
    parser.add_argument(
        "--expected-questions",
        type=int,
        default=None,
        help="Optional expected number of test questions. Inferred when possible.",
    )
    parser.add_argument(
        "--output-prefix",
        default="bird_output_diagnostics",
        help="Prefix for the machine-readable JSON and markdown reports.",
    )
    parser.add_argument(
        "--include-file-inventory",
        action="store_true",
        help="Include a non-sensitive inventory of which expected artifact files exist.",
    )
    return parser.parse_args()


def read_json(path: Path) -> Optional[Any]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return None
    except json.JSONDecodeError as exc:
        return {"_read_error": f"json_decode_error: {exc}"}


def iter_jsonl(path: Optional[Path]) -> Iterator[Dict[str, Any]]:
    if not path or not path.exists():
        return
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                yield {"_read_error": "json_decode_error", "_line_no": line_no}
                continue
            if isinstance(row, dict):
                yield row


def count_jsonl(path: Optional[Path]) -> int:
    return sum(1 for _ in iter_jsonl(path))


def pct(numerator: int | float, denominator: int | float) -> Optional[float]:
    if not denominator:
        return None
    return 100.0 * float(numerator) / float(denominator)


def safe_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_float(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        result = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(result) or math.isinf(result):
        return None
    return result


def summarize_numbers(values: Sequence[float]) -> Dict[str, Any]:
    clean = [v for v in values if isinstance(v, (int, float)) and not math.isnan(v)]
    if not clean:
        return {"count": 0}
    sorted_values = sorted(float(v) for v in clean)

    def percentile(q: float) -> float:
        if len(sorted_values) == 1:
            return sorted_values[0]
        pos = (len(sorted_values) - 1) * q
        lo = math.floor(pos)
        hi = math.ceil(pos)
        if lo == hi:
            return sorted_values[lo]
        frac = pos - lo
        return sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac

    return {
        "count": len(sorted_values),
        "mean": statistics.fmean(sorted_values),
        "median": percentile(0.50),
        "p90": percentile(0.90),
        "p95": percentile(0.95),
        "max": sorted_values[-1],
        "min": sorted_values[0],
    }


def render_number_summary(summary: Dict[str, Any]) -> str:
    if not summary or summary.get("count", 0) == 0:
        return "n/a (n=0)"
    return (
        f"avg={summary['mean']:.3f}, median={summary['median']:.3f}, "
        f"p90={summary['p90']:.3f}, p95={summary['p95']:.3f}, "
        f"min={summary['min']:.3f}, max={summary['max']:.3f}, n={summary['count']}"
    )


def counter_to_sorted_dict(counter: Counter) -> Dict[str, int]:
    return {
        str(key): int(value)
        for key, value in sorted(counter.items(), key=lambda item: (-item[1], str(item[0])))
    }


def classify_error(message: Any) -> str:
    text = str(message or "").strip().lower()
    if not text:
        return "none"
    if "empty sql" in text:
        return "empty_sql"
    if "timeout" in text or "interrupted" in text:
        return "timeout_or_interrupted"
    if "syntax error" in text:
        return "sqlite_syntax_error"
    if "no such table" in text:
        return "sqlite_no_such_table"
    if "no such column" in text:
        return "sqlite_no_such_column"
    if "ambiguous column" in text:
        return "sqlite_ambiguous_column"
    if "misuse of aggregate" in text:
        return "sqlite_aggregate_error"
    if "no valid non-empty vote" in text:
        return "no_valid_non_empty_vote"
    if "generation_error" in text or "exception" in text or "traceback" in text:
        return "generation_or_runtime_error"
    return "other"


def classify_status(status: Any) -> str:
    text = str(status or "").strip().lower()
    if not text:
        return "unknown"
    if text in {"ok", "pred_ok", "mismatch"}:
        return text
    if "empty sql" in text:
        return "pred_error_empty_sql"
    if "timeout" in text or "interrupted" in text:
        return "pred_error_timeout_or_interrupted"
    if "pred_error" in text:
        return f"pred_error_{classify_error(text)}"
    if "gold_error" in text:
        return f"gold_error_{classify_error(text)}"
    if "no valid non-empty vote" in text:
        return "no_valid_non_empty_vote"
    if "error" in text:
        return "error_other"
    return "other"


TOOL_ERROR_RE = re.compile(
    r'"error"\s*:\s*(?:"(?P<quoted>[^"]+)"|(?P<bare>true|false|null|\d+))',
    flags=re.IGNORECASE,
)


def extract_tool_error_categories(text: Any) -> List[str]:
    if not isinstance(text, str) or not text:
        return []
    categories = []
    for match in TOOL_ERROR_RE.finditer(text):
        raw = match.group("quoted") or match.group("bare") or ""
        if raw.lower() in {"false", "null", "0"}:
            continue
        categories.append(classify_error(raw))
    return categories


def official_prediction_sql_empty(value: Any) -> bool:
    if not isinstance(value, str):
        return True
    sql_part = value.split(BIRD_MARKER, 1)[0]
    return not sql_part.strip()


def discover_file(root: Path, names: Sequence[str]) -> Optional[Path]:
    for name in names:
        candidate = root / name
        if candidate.exists():
            return candidate
    return None


def discover_run_artifacts(root: Path) -> Dict[str, Optional[Path]]:
    passk_candidates = discover_file(
        root,
        (
            "passk/merged/passk_candidates.jsonl",
            "passk/passk_candidates.jsonl",
            "passk_candidates.jsonl",
        ),
    )
    if passk_candidates is None:
        shard_paths = sorted((root / "passk").glob("shard-*-of-*/passk_candidates.jsonl"))
        # Keep None here if merged output exists nowhere; shard files are listed
        # separately and summarized together.
    else:
        shard_paths = []

    return {
        "root": root,
        "pipeline_log": discover_file(root, ("pipeline.log",)),
        "run_manifest": discover_file(root, ("run_manifest.tsv",)),
        "tool_jsonl": discover_file(root, ("bird_test-schema-tool.jsonl",)),
        "schema_jsonl": discover_file(root, ("bird_test-schema.jsonl",)),
        "predict_json": discover_file(
            root,
            (
                "self_consistency/predict_test.json",
                "predict_test.json",
            ),
        ),
        "self_consistency_results": discover_file(
            root,
            (
                "self_consistency/self_consistency_results.jsonl",
                "self_consistency_results.jsonl",
            ),
        ),
        "eval_results_samples": discover_file(
            root,
            (
                "self_consistency/eval_results_samples.jsonl",
                "eval_results_samples.jsonl",
            ),
        ),
        "self_consistency_summary": discover_file(
            root,
            (
                "self_consistency/self_consistency_summary.json",
                "self_consistency_summary.json",
            ),
        ),
        "passk_candidates": passk_candidates,
        "passk_summary": discover_file(
            root,
            (
                "passk/merged/passk_summary.json",
                "passk/passk_summary.json",
                "passk_summary.json",
            ),
        ),
        "passk_shard_candidates": shard_paths,
    }


def get_candidate_rows(artifacts: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], str]:
    path = artifacts.get("passk_candidates")
    if path:
        return list(iter_jsonl(path)), str(path)
    shard_paths = artifacts.get("passk_shard_candidates") or []
    rows: List[Dict[str, Any]] = []
    for shard_path in shard_paths:
        rows.extend(iter_jsonl(shard_path))
    if rows:
        return rows, " + ".join(str(path) for path in shard_paths)
    path = artifacts.get("eval_results_samples")
    if path:
        return list(iter_jsonl(path)), str(path)
    return [], ""


def candidate_sample_id(row: Dict[str, Any]) -> int:
    return safe_int(row.get("sample_id", row.get("sample_idx", 0)))


def summarize_candidates(
    rows: Sequence[Dict[str, Any]],
    expected_generations: int,
    expected_questions: Optional[int],
) -> Dict[str, Any]:
    by_idx: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    stop_reasons = Counter()
    pred_errors = Counter()
    generation_errors = Counter()
    status_counts = Counter()
    tool_order_counts = Counter()
    tool_error_categories = Counter()
    tool_error_candidate_count = 0
    tool_calls: List[float] = []
    tool_rounds: List[float] = []
    completion_tokens: List[float] = []
    prompt_tokens: List[float] = []
    sql_lengths: List[float] = []
    executed = 0
    extracted = 0
    read_errors = 0

    for row in rows:
        if row.get("_read_error"):
            read_errors += 1
            continue
        idx = safe_int(row.get("idx", row.get("source_idx", -1)), -1)
        if idx >= 0:
            by_idx[idx].append(row)
        pred_sql = row.get("pred_sql", "")
        if isinstance(pred_sql, str) and pred_sql.strip():
            extracted += 1
            sql_lengths.append(float(len(pred_sql)))
        if bool(row.get("pred_executed")):
            executed += 1
        stop_reasons[str(row.get("stop_reason") or "unknown")] += 1
        status_counts[classify_status(row.get("status"))] += 1
        pred_errors[classify_error(row.get("pred_error"))] += 1
        if row.get("generation_error") or row.get("error_message"):
            generation_errors[classify_error(row.get("generation_error") or row.get("error_message"))] += 1
        tool_calls.append(float(safe_int(row.get("tool_call_count"), 0)))
        tool_rounds.append(float(safe_int(row.get("tool_rounds"), 0)))
        for field, target in (
            ("completion_token_count", completion_tokens),
            ("prompt_tokens", prompt_tokens),
        ):
            value = safe_float(row.get(field))
            if value is not None:
                target.append(value)
        order = row.get("tool_order")
        if isinstance(order, list):
            tool_order_counts[" -> ".join(str(x) for x in order) or "<none>"] += 1
        elif isinstance(order, str) and order:
            tool_order_counts[order] += 1
        categories = extract_tool_error_categories(row.get("prediction_text"))
        if categories:
            tool_error_candidate_count += 1
            tool_error_categories.update(categories)

    candidate_count = len(rows) - read_errors
    unique_questions = len(by_idx)
    inferred_questions = expected_questions or unique_questions
    expected_candidates = inferred_questions * expected_generations if inferred_questions else None
    candidates_per_question = Counter(len(v) for v in by_idx.values())
    missing_candidate_slots = (
        max(0, expected_candidates - candidate_count)
        if expected_candidates is not None
        else None
    )

    duplicate_candidate_keys = 0
    missing_sample_slots = 0
    duplicate_sample_slots = 0
    for idx_rows in by_idx.values():
        samples = [candidate_sample_id(row) for row in idx_rows]
        duplicate_sample_slots += len(samples) - len(set(samples))
        if expected_generations:
            missing_sample_slots += len(set(range(expected_generations)) - set(samples))
        duplicate_candidate_keys += sum(count - 1 for count in Counter(samples).values() if count > 1)

    return {
        "total_candidates": candidate_count,
        "read_errors": read_errors,
        "unique_questions_with_candidates": unique_questions,
        "expected_questions": inferred_questions,
        "expected_generations": expected_generations,
        "expected_candidate_slots": expected_candidates,
        "missing_candidate_slots": missing_candidate_slots,
        "candidate_slot_coverage_pct": (
            pct(candidate_count, expected_candidates) if expected_candidates else None
        ),
        "candidates_per_question_histogram": counter_to_sorted_dict(candidates_per_question),
        "missing_sample_slots_from_0_to_k_minus_1": missing_sample_slots,
        "duplicate_idx_sample_keys": duplicate_candidate_keys,
        "duplicate_sample_slots": duplicate_sample_slots,
        "pred_sql_extracted": extracted,
        "pred_sql_extracted_pct": pct(extracted, candidate_count),
        "pred_sql_empty_or_missing": candidate_count - extracted,
        "pred_executed": executed,
        "pred_executed_pct": pct(executed, candidate_count),
        "pred_execution_failed": candidate_count - executed,
        "pred_error_categories": counter_to_sorted_dict(pred_errors),
        "status_counts": counter_to_sorted_dict(status_counts),
        "stop_reason_counts": counter_to_sorted_dict(stop_reasons),
        "generation_error_categories": counter_to_sorted_dict(generation_errors),
        "tool_call_count": summarize_numbers(tool_calls),
        "tool_round_count": summarize_numbers(tool_rounds),
        "tool_round_histogram": counter_to_sorted_dict(Counter(int(v) for v in tool_rounds)),
        "tool_call_histogram": counter_to_sorted_dict(Counter(int(v) for v in tool_calls)),
        "tool_order_counts_top20": dict(list(counter_to_sorted_dict(tool_order_counts).items())[:20]),
        "candidates_with_tool_error_marker": tool_error_candidate_count,
        "candidates_with_tool_error_marker_pct": pct(tool_error_candidate_count, candidate_count),
        "tool_error_marker_categories": counter_to_sorted_dict(tool_error_categories),
        "completion_tokens": summarize_numbers(completion_tokens),
        "prompt_tokens": summarize_numbers(prompt_tokens),
        "sql_length_chars": summarize_numbers(sql_lengths),
    }


def summarize_self_consistency(rows: Sequence[Dict[str, Any]], expected_generations: int) -> Dict[str, Any]:
    selected_count = 0
    selected_executed = 0
    selected_extracted = 0
    no_valid_vote = 0
    selected_vote_counts = Counter()
    valid_vote_counts = Counter()
    ignored_empty_total = 0
    status_counts = Counter()
    pred_errors = Counter()
    confidence_values: List[float] = []
    full_consensus = 0
    all_valid_candidates = 0

    for row in rows:
        if row.get("_read_error"):
            continue
        selected_count += 1
        if row.get("pred_executed"):
            selected_executed += 1
        if row.get("pred_sql_extracted") or (isinstance(row.get("pred_sql"), str) and row["pred_sql"].strip()):
            selected_extracted += 1
        vote_count = safe_int(row.get("selected_vote_count"), 0)
        valid_votes = safe_int(row.get("valid_vote_candidates"), 0)
        ignored_empty = safe_int(row.get("ignored_empty_results"), 0)
        ignored_empty_total += ignored_empty
        selected_vote_counts[vote_count] += 1
        valid_vote_counts[valid_votes] += 1
        if valid_votes == 0 or vote_count == 0:
            no_valid_vote += 1
        if valid_votes:
            confidence_values.append(vote_count / valid_votes)
        if valid_votes == expected_generations:
            all_valid_candidates += 1
        if vote_count == expected_generations and valid_votes == expected_generations:
            full_consensus += 1
        status_counts[classify_status(row.get("status"))] += 1
        pred_errors[classify_error(row.get("pred_error"))] += 1

    return {
        "selected_questions": selected_count,
        "selected_pred_sql_extracted": selected_extracted,
        "selected_pred_sql_extracted_pct": pct(selected_extracted, selected_count),
        "selected_pred_executed": selected_executed,
        "selected_pred_executed_pct": pct(selected_executed, selected_count),
        "examples_without_valid_vote": no_valid_vote,
        "examples_without_valid_vote_pct": pct(no_valid_vote, selected_count),
        "ignored_empty_results_total": ignored_empty_total,
        "selected_vote_count_histogram": counter_to_sorted_dict(selected_vote_counts),
        "valid_vote_candidates_histogram": counter_to_sorted_dict(valid_vote_counts),
        "full_consensus_all_16_or_expected": full_consensus,
        "full_consensus_pct": pct(full_consensus, selected_count),
        "all_expected_candidates_valid": all_valid_candidates,
        "all_expected_candidates_valid_pct": pct(all_valid_candidates, selected_count),
        "selected_vote_confidence": summarize_numbers(confidence_values),
        "status_counts": counter_to_sorted_dict(status_counts),
        "pred_error_categories": counter_to_sorted_dict(pred_errors),
    }


def summarize_predictions(path: Optional[Path], expected_questions: Optional[int]) -> Dict[str, Any]:
    payload = read_json(path) if path else None
    if payload is None:
        return {"present": False}
    if isinstance(payload, dict) and "_read_error" in payload:
        return {"present": True, "read_error": payload["_read_error"]}
    if not isinstance(payload, dict):
        return {"present": True, "read_error": "prediction file is not a JSON object"}

    total = len(payload)
    malformed = sum(1 for value in payload.values() if not isinstance(value, str) or BIRD_MARKER not in value)
    empty_sql = sum(1 for value in payload.values() if official_prediction_sql_empty(value))
    duplicate_numeric_ids = total - len({safe_int(key, -1) for key in payload.keys()})
    missing_vs_expected = None
    if expected_questions is not None:
        missing_vs_expected = max(0, expected_questions - total)
    return {
        "present": True,
        "prediction_entries": total,
        "expected_questions": expected_questions,
        "missing_vs_expected": missing_vs_expected,
        "malformed_bird_format": malformed,
        "empty_sql_entries": empty_sql,
        "empty_sql_pct": pct(empty_sql, total),
        "duplicate_numeric_question_ids": duplicate_numeric_ids,
    }


def summarize_timing(artifacts: Dict[str, Any], candidate_count: int, question_count: int) -> Dict[str, Any]:
    timing: Dict[str, Any] = {
        "exact_per_question_latency_available": False,
        "note": (
            "The submitted code does not persist per-question wall-clock latency. "
            "Only aggregate timing from passk_summary.json/pipeline.log can be reported."
        ),
    }
    passk_summary = read_json(artifacts.get("passk_summary")) if artifacts.get("passk_summary") else None
    if isinstance(passk_summary, dict):
        seconds = passk_summary.get("timing_seconds") or {}
        if isinstance(seconds, dict):
            timing["passk_timing_seconds"] = seconds
            total = safe_float(seconds.get("total"))
            generation = safe_float(seconds.get("generation"))
            evaluation = safe_float(seconds.get("evaluation"))
            if total is not None and question_count:
                timing["passk_total_seconds_per_question"] = total / question_count
            if generation is not None and candidate_count:
                timing["generation_seconds_per_candidate"] = generation / candidate_count
            if evaluation is not None and candidate_count:
                timing["candidate_eval_seconds_per_candidate"] = evaluation / candidate_count
    return timing


def summarize_manifest(path: Optional[Path]) -> Dict[str, Any]:
    if not path or not path.exists():
        return {"present": False}
    stages = []
    try:
        with path.open("r", encoding="utf-8") as handle:
            header = next(handle, "")
            for line in handle:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 5:
                    stages.append(
                        {
                            "stage": parts[0],
                            "rows": parts[2],
                            "status": parts[3],
                            "finished_at": parts[4],
                        }
                    )
    except OSError as exc:
        return {"present": True, "read_error": str(exc)}
    return {"present": True, "stages": stages}


def infer_expected_questions(
    artifacts: Dict[str, Any],
    explicit_expected: Optional[int],
    prediction_summary: Optional[Dict[str, Any]] = None,
) -> Optional[int]:
    if explicit_expected is not None:
        return explicit_expected
    for key in ("tool_jsonl", "schema_jsonl"):
        path = artifacts.get(key)
        if path and path.exists():
            count = count_jsonl(path)
            if count:
                return count
    if prediction_summary and prediction_summary.get("prediction_entries"):
        return int(prediction_summary["prediction_entries"])
    summary = read_json(artifacts.get("self_consistency_summary")) if artifacts.get("self_consistency_summary") else None
    if isinstance(summary, dict):
        total = summary.get("total") or {}
        if isinstance(total, dict) and total.get("count"):
            return safe_int(total["count"])
    return None


def summarize_run(
    root: Path,
    expected_generations: int,
    expected_questions: Optional[int],
    include_file_inventory: bool,
) -> Dict[str, Any]:
    artifacts = discover_run_artifacts(root)
    prediction_summary_initial = summarize_predictions(artifacts.get("predict_json"), expected_questions)
    inferred_questions = infer_expected_questions(artifacts, expected_questions, prediction_summary_initial)
    prediction_summary = summarize_predictions(artifacts.get("predict_json"), inferred_questions)
    candidate_rows, candidate_source = get_candidate_rows(artifacts)
    sc_rows = list(iter_jsonl(artifacts.get("self_consistency_results")))

    candidates = summarize_candidates(candidate_rows, expected_generations, inferred_questions)
    self_consistency = summarize_self_consistency(sc_rows, expected_generations)
    timing = summarize_timing(
        artifacts,
        candidate_count=safe_int(candidates.get("total_candidates")),
        question_count=safe_int(candidates.get("expected_questions")),
    )
    manifest = summarize_manifest(artifacts.get("run_manifest"))

    result = {
        "run_root": str(root),
        "candidate_source": candidate_source or None,
        "prediction_file": str(artifacts["predict_json"]) if artifacts.get("predict_json") else None,
        "expected_questions": inferred_questions,
        "expected_generations": expected_generations,
        "predictions": prediction_summary,
        "passk_or_sample_candidates": candidates,
        "self_consistency": self_consistency,
        "timing": timing,
        "manifest": manifest,
    }
    if include_file_inventory:
        result["file_inventory"] = {
            key: (
                [str(item) for item in value]
                if isinstance(value, list)
                else (str(value) if isinstance(value, Path) else value)
            )
            for key, value in artifacts.items()
            if key != "root"
        }
    return result


def format_pct(value: Any) -> str:
    if value is None:
        return "n/a"
    try:
        return f"{float(value):.2f}%"
    except (TypeError, ValueError):
        return "n/a"


def add_count_pct_line(lines: List[str], label: str, count: Any, denom: Any, pct_value: Any) -> None:
    lines.append(f"- {label}: {count}/{denom} ({format_pct(pct_value)})")


def render_run_markdown(summary: Dict[str, Any]) -> str:
    c = summary["passk_or_sample_candidates"]
    sc = summary["self_consistency"]
    pred = summary["predictions"]
    timing = summary["timing"]
    lines = [
        f"## Run: {Path(summary['run_root']).name}",
        "",
        f"- run_root: `{summary['run_root']}`",
        f"- candidate_source: `{summary.get('candidate_source') or 'not found'}`",
        f"- expected_questions: `{summary.get('expected_questions')}`",
        f"- expected_generations: `{summary.get('expected_generations')}`",
        "",
        "### Final Prediction File",
        "",
    ]
    if pred.get("present"):
        lines.extend(
            [
                f"- entries: `{pred.get('prediction_entries')}`",
                f"- missing_vs_expected: `{pred.get('missing_vs_expected')}`",
                f"- malformed_bird_format: `{pred.get('malformed_bird_format')}`",
                f"- empty_sql_entries: `{pred.get('empty_sql_entries')}` ({format_pct(pred.get('empty_sql_pct'))})",
            ]
        )
    else:
        lines.append("- prediction file: `not found`")

    lines.extend(["", "### Candidate Generation And Execution", ""])
    add_count_pct_line(
        lines,
        "candidate slot coverage",
        c.get("total_candidates"),
        c.get("expected_candidate_slots"),
        c.get("candidate_slot_coverage_pct"),
    )
    add_count_pct_line(
        lines,
        "SQL extracted",
        c.get("pred_sql_extracted"),
        c.get("total_candidates"),
        c.get("pred_sql_extracted_pct"),
    )
    add_count_pct_line(
        lines,
        "candidate SQL executed",
        c.get("pred_executed"),
        c.get("total_candidates"),
        c.get("pred_executed_pct"),
    )
    lines.extend(
        [
            f"- missing candidate slots: `{c.get('missing_candidate_slots')}`",
            f"- duplicate idx/sample keys: `{c.get('duplicate_idx_sample_keys')}`",
            f"- candidates per question histogram: `{c.get('candidates_per_question_histogram')}`",
            f"- stop reason counts: `{c.get('stop_reason_counts')}`",
            f"- candidate pred error categories: `{c.get('pred_error_categories')}`",
            f"- status counts: `{c.get('status_counts')}`",
            f"- tool rounds: {render_number_summary(c.get('tool_round_count', {}))}",
            f"- tool calls: {render_number_summary(c.get('tool_call_count', {}))}",
            f"- tool round histogram: `{c.get('tool_round_histogram')}`",
            f"- tool call histogram: `{c.get('tool_call_histogram')}`",
            f"- candidates with tool-error marker: `{c.get('candidates_with_tool_error_marker')}` ({format_pct(c.get('candidates_with_tool_error_marker_pct'))})",
            f"- tool-error marker categories: `{c.get('tool_error_marker_categories')}`",
            f"- completion tokens: {render_number_summary(c.get('completion_tokens', {}))}",
            f"- prompt tokens: {render_number_summary(c.get('prompt_tokens', {}))}",
            "",
            "### Self-Consistency Voting",
            "",
        ]
    )
    add_count_pct_line(
        lines,
        "selected SQL executed",
        sc.get("selected_pred_executed"),
        sc.get("selected_questions"),
        sc.get("selected_pred_executed_pct"),
    )
    add_count_pct_line(
        lines,
        "examples without valid vote",
        sc.get("examples_without_valid_vote"),
        sc.get("selected_questions"),
        sc.get("examples_without_valid_vote_pct"),
    )
    lines.extend(
        [
            f"- selected vote count histogram: `{sc.get('selected_vote_count_histogram')}`",
            f"- valid vote candidates histogram: `{sc.get('valid_vote_candidates_histogram')}`",
            f"- full consensus at expected k: `{sc.get('full_consensus_all_16_or_expected')}` ({format_pct(sc.get('full_consensus_pct'))})",
            f"- all expected candidates valid: `{sc.get('all_expected_candidates_valid')}` ({format_pct(sc.get('all_expected_candidates_valid_pct'))})",
            f"- selected-vote confidence: {render_number_summary(sc.get('selected_vote_confidence', {}))}",
            f"- selected pred error categories: `{sc.get('pred_error_categories')}`",
            "",
            "### Timing",
            "",
            f"- exact_per_question_latency_available: `{timing.get('exact_per_question_latency_available')}`",
            f"- note: {timing.get('note')}",
        ]
    )
    if timing.get("passk_timing_seconds"):
        lines.append(f"- passk_timing_seconds: `{timing.get('passk_timing_seconds')}`")
    for key in ("passk_total_seconds_per_question", "generation_seconds_per_candidate", "candidate_eval_seconds_per_candidate"):
        if key in timing:
            lines.append(f"- {key}: `{timing[key]:.3f}`")
    return "\n".join(lines)


def render_markdown(all_summaries: Sequence[Dict[str, Any]]) -> str:
    lines = [
        "# BIRD Evaluation Output Diagnostics",
        "",
        "This report contains aggregate diagnostics only. It intentionally omits SQL strings, DB ids, questions, schemas, result rows, and database-derived values.",
        "",
    ]
    for summary in all_summaries:
        lines.append(render_run_markdown(summary))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main() -> None:
    args = parse_args()
    roots = [Path(path) for path in args.run_roots] if args.run_roots else [Path(p) for p in DEFAULT_RUN_ROOTS]
    existing_roots = [path for path in roots if path.exists()]
    if not existing_roots:
        raise SystemExit(
            "No run roots found. Pass one or more output directories, e.g. "
            "python3 analyze_bird_eval_outputs.py outputs/bird_test_sft_rl outputs/bird_test_rl_only"
        )

    summaries = [
        summarize_run(
            root=root,
            expected_generations=args.expected_generations,
            expected_questions=args.expected_questions,
            include_file_inventory=args.include_file_inventory,
        )
        for root in existing_roots
    ]

    json_path = Path(f"{args.output_prefix}.json")
    md_path = Path(f"{args.output_prefix}.md")
    with json_path.open("w", encoding="utf-8") as handle:
        json.dump({"runs": summaries}, handle, indent=2, ensure_ascii=False)
    md_path.write_text(render_markdown(summaries), encoding="utf-8")

    print(render_markdown(summaries))
    print(f"Wrote JSON summary: {json_path}")
    print(f"Wrote markdown summary: {md_path}")


if __name__ == "__main__":
    main()
